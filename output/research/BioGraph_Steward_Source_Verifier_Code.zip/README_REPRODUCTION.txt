BioGraph Steward: source-verifier research code snapshot
17 November 2026

PURPOSE AND LAYOUT
This optional analysis code is separate from the production app and its default
graph. It makes the original partial-input source-pair evaluation, fixed learned
follow-up, corrected-input controller/scorer and source qualification auditable. It is not a
standalone dataset, model, clinical tool, new app default or a complete one-command
reproduction package. This snapshot contains no scientific outcome files.

All source files retain their original repository-relative names and original
bytes. Extract into a NEW, matching BioGraph Steward checkout, from that checkout's
root. Do not extract over an existing research run. The extra root files are this
README and MANIFEST_CODE.json; that manifest lists every original member and hash.
Nothing is installed, fetched, fitted, scored or inferred by opening the ZIP.

WHAT IS INCLUDED
- The current native INDRA author-method adapter and durable two-arm runner.
- The frozen strict source-pair label/scoring helpers, connected-group statistics,
  fixed learned-combination recipe and aggregate-only publication checks.
- Our label-blind reference qualification/recovery scripts, without their inputs.
- Invented-data fixture source, never actual curator examples or label rows.
- The current master/primary/secondary V2 protocols and separately frozen learned
  follow-up protocol, unchanged. Paths in those files are relative provenance
  references; a referenced artifact is not necessarily redistributed here.
- The author source/example-bank SHA256 manifest and attribution notice only.
- The corrected-input bridge, durable runner, scorer and invented fixtures.
- The research Qwen Converse provider client and invented fixtures.
- The exact frozen corrected_input_v1 master and scoring candidate metadata.
- Our core model_transport.py at the exact implementation pin below.

NOT INCLUDED
Third-party source code or example-bank content; reference captures; curator tags
or per-case gold labels; case, grouping, exposure or admission row inventories;
predictions, model replies or traces; trained fits or encoders; model weights or
tokenizers; native ontology/Gilda/ProtMapper caches or resource inventories;
credential values or account configuration files; cloud/deployment operators; old failed-run
code or superseded protocols. Missing inputs must not be replaced with fabricated
rows, missing-as-negative labels, altered hashes or silently weakened guards.

UPSTREAM SOURCE REQUIRED SEPARATELY
The exact author revision is:
https://github.com/gyorilab/indra-belief-model/tree/74e0ffe9ea21f6f11e906cee89a2091f45be2f7d
The adapter expects the author's package beneath:
runs/final_delivery_20261117/method_qualification/adapter/upstream/
Its upstream_manifest.json lists 31 original source/metadata/example-bank members
and their raw hashes/URLs. Obtain those originals under the upstream terms and
verify every listed member; do not omit the published adaptive example bank.
Qualification scripts also expect the matching author's original scripts beneath
runs/final_delivery_20261117/reference_qualification/official_source/.
Those third-party files are deliberately not copied into this ZIP. The archive also preserves biograph_steward/model_transport.py, frozen raw SHA256:
5f8e2474c6921061b5cc598d1ac1f53f13ca4995fc60cad91e8150a59dd4be94

OPTIONAL RUNTIME AND NATIVE RESOURCES
The qualified analysis used Python3.12.14, INDRA1.24.0, Gilda1.6.1,
ProtMapper0.0.29, NumPy2.3.5, SciPy1.18.1 and scikit-learn1.9.1.
The qualification scripts also import requests and simplejson. Their exact
installed dependencies and byte inventories belong to the separate captured
runtime, not this source-only archive. No new package installation was performed
while creating this ZIP. Preserve third-party dependency notices and terms.

The supported INDRA native bootstrap is documented at:
https://indra.readthedocs.io/en/latest/modules/ontology/bio_ontology.html#generating-and-caching-the-bioontology
The official command is: python -m indra.ontology.bio build
Configure INDRA_RESOURCES before importing INDRA and PYSTOW_HOME before importing
Gilda. The frozen runner requires the qualified owned paths shown in its protocols,
BioOntology1.34, the exact separately captured cache/resource inventory, and every
member hash. Do not substitute a newly built pickle and claim byte-identical replay:
cache bytes and dependency vintages need their own pinning and prospective protocol.
The example native bootstrap above is documentation, not executed by this archive.

The original model run used NVIDIA Llama-3.1-Nemotron-Nano-8B-v1 revision
54641c1611fcff44fa4865626462445e0a153fc7, vLLM0.8.5 V0, 16,384 context tokens.
https://huggingface.co/nvidia/Llama-3.1-Nemotron-Nano-8B-v1/tree/54641c1611fcff44fa4865626462445e0a153fc7
No model is included or automatically downloaded. The adapter defaults to no live
inference; actual calls require an explicit enabled client, exact full-message
server tokenization and separately frozen protocol. The original loopback port is
an operator-specific serving route, not a hosted endpoint supplied by this ZIP.

CORRECTED-INPUT OPERATOR CHECKPOINT
This increment preserves every one of the prior 24 source/protocol members byte
for byte. It adds the frozen corrected-input implementation and master/scoring
specifications without altering them or redistributing scientific outcomes.
Master: runs/final_delivery_20261117/protocols/corrected_input_v1.json
SHA256: 0e7bef90ab9acce4a8e710b3c009b5d6531d228cd5e6a2e09a0edec89878eabc
Scoring: runs/final_delivery_20261117/protocols/corrected_input_scoring.candidate.json
SHA256: 0980011d1ad47555769c28f6db7d1ff1c1bcdd1c4399a4baa89ff1e42697eff0
The scoring filename retains its original candidate suffix. The master binds
that exact specification. Do not replace it while continuing the same run.

The added bridge preserves qualified available Evidence metadata and native
claim fields. The runner has separate preflight/run operations, durable intent
and response journals, bounded provider budgets and no automatic retry. The
scorer retains common-policy and focal-input views rather than silently replacing
the partial-input baseline. Inspect its frozen gates before executing it.
The added Qwen Converse class is a research model-provider client. It creates
no cloud infrastructure and is separate from the production app's saved replay.

One frozen admission/recovery module is deliberately OMITTED from this source
archive because it contains identity-specific curator-split constants:
runs/final_delivery_20261117/reference_qualification/evidence_metadata_audit/build_full_input.py
12,129 bytes, SHA256: 23b813ce249aa71a8183b30422928c2f9329ec88350726730223b68c2b12a95e
It remains unchanged privately and must be supplied separately to an authorized
operator when rebuilding admitted full-Evidence frames. This archive does not
claim to contain every preprocessing source or a substitute implementation.
No identity literals from that module are copied here.

The exact checkpoint additionally requires separately licensed raw recovery
captures, prior admission/group/exposure inventories, cached partial-input
prediction envelopes, completion receipts, native-resource inventories and
optional runtime dependencies. Those inputs are referenced by hashes and paths
in the frozen metadata but are NOT included. Outcomes, label rows, raw Evidence,
curation events, request payloads, journals, provider replies, fitted models and
readiness/dependency capture files are excluded. Referenced filenames do not
mean those artifacts are supplied in this archive.

Frozen source preserves descriptive original local paths, profile names,
serving endpoints and the local AWS CLI binary path. They are operator bindings,
not credentials or a portable environment. The Converse client needs a valid
user-configured AWS model-service session and an AWS CLI executable available
at the configured path. Never paste credentials into code or a protocol. A new
installation may need explicit path/profile/runtime adaptation, fresh hashes
and a NEW prospectively frozen protocol. Do not modify these archived bytes and
claim the original checkpoint still passes its hash guards. Neither unzipping
nor packaging runs a model, AWS request or scientific fixture.

The production application and the separately supplied APP/PSEN real-data
example are the user launch routes. That example is portable saved replay. This
research ZIP is an auditable code-only adjunct, not a one-command reference
benchmark, a complete historical checkpoint or an automatic Pharos pruner.
Current app source assertions lack the full native INDRA inputs for this verifier.
Scientific results and their adverse controls are published separately. This
code snapshot does not declare a corrected-input improvement or new accuracy.

REFERENCE DATA AND REPLAY BOUNDARIES
Primary author release locator:
https://raw.githubusercontent.com/gyorilab/indra-belief-model/74e0ffe9ea21f6f11e906cee89a2091f45be2f7d/data/benchmark/representative_indra_curations_400.jsonl
Secondary author release locator:
https://raw.githubusercontent.com/gyorilab/indra-belief-model/74e0ffe9ea21f6f11e906cee89a2091f45be2f7d/data/benchmark/external_gold_v1.jsonl
Author dataset description:
https://github.com/gyorilab/indra-belief-model/blob/74e0ffe9ea21f6f11e906cee89a2091f45be2f7d/data/benchmark/README.md
Native statement recovery route, when available: https://db.indra.bio/
Related 2023 publication/corpus: https://doi.org/10.15252/msb.202211325 and
https://zenodo.org/records/7559353
Curation definitions: https://indra.readthedocs.io/en/latest/tutorials/html_curation.html

The exact frozen reference captures, prior-exposure quarantine, source-group
inventories, native claim recovery and authorization receipts must be supplied
separately under their applicable terms. Current release availability or reuse
permission is not guaranteed by these locators. The original 2023 corpus's
CC-BY-NC-SA4.0 terms do not automatically license a later dataset. The 2026 author
releases had no explicit dataset-specific redistribution grant identified during
qualification, so their rows are not republished here. Protocol pins document what
was used; they do not convey permission or supply the missing files.

For a new prospective assessment, prepare its licensed inputs and native resource
pins, quarantine any prior exposure, and freeze a NEW protocol before inference or
labels. For the original paired comparison, both complete prediction frames and
completion receipts were sealed before labels. The separate learned follow-up
uses primary only for fitting and reserves secondary for its frozen transfer test.
Missing source/label records must fail or abstain according to the frozen policy,
never become invented negatives. No prompts, thresholds or labels may be changed
while continuing an already frozen comparison.

FIXTURES AND ENTRY POINTS
The test_adapter.py and test_runner.py files use invented data. The synthetic
scoring/materializer/follow-up/publication fixtures also invent their rows and
labels; apparent PRIVATE_CASE/SECRET/example.invalid strings in those tests are
intentional fake privacy sentinels, not project records or credentials. Some
fixtures require the separately obtained pinned upstream package and optional
analysis dependencies. No fixtures were executed during source packaging.

run_pair_comparison.py has separate --phase preflight and --phase run operations.
It requires explicit --protocol, --protocol-sha256 and --output arguments. A full
preflight measures every unchanged request before generation. New-run markers,
fsynced intents, hard budgets, no automatic retries/resumption, source bindings
and complete-frame seals are retained in this exact code snapshot. Scoring and
publication are separate explicit operations; inspect each helper's authorization
arguments before using it. The frame qualification/recovery scripts are audited
research utilities, not safe-to-run substitutes for separately licensed inputs.

METHOD CREDIT AND LICENSE SCOPE
Our adapter preserves the author's two published base/disconfirm policies, native
renderer/parser and 14 type-selected examples, with only the documented Nano chat
wire placement adaptation. It does not use the author's RF/direct-binding filter
or transfer a fitted Gemma probability calibration. The follow-up's fixed sklearn
recipe and metadata-only control are separate from that author method.

Project-authored source follows the BioGraph Steward repository's applicable code
license. Upstream code, models and datasets retain their own terms. The pinned
author pyproject declares MIT but had no standalone LICENSE file; see the included
ATTRIBUTION.md. This ZIP grants no blanket MIT license to third-party source,
model weights, source passages, curation rows, datasets or native resource caches.
Neither source-code availability nor passing fixtures establishes scientific
accuracy, complete-graph biological correctness or transferable prediction gains.
