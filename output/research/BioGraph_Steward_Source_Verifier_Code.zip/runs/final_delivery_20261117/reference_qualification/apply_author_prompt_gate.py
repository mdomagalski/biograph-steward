"""Use the unmodified author's overlap guard on label-free admitted cases."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from collections import Counter

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[2]
UPSTREAM = ROOT / "runs/final_delivery_20261117/method_qualification/adapter/upstream"
sys.path.insert(0, str(UPSTREAM / "src"))
from indra.statements import stmts_from_json

spec = importlib.util.spec_from_file_location(
    "check_contamination", OUT / "official_source/scripts/check_contamination.py")
cc = importlib.util.module_from_spec(spec)
sys.modules["check_contamination"] = cc
spec.loader.exec_module(cc)
cc.ROOT = UPSTREAM
curation_spec = importlib.util.spec_from_file_location(
    "indra_belief.curation", OUT / "official_source/src/indra_belief/curation.py")
curation_module = importlib.util.module_from_spec(curation_spec)
sys.modules["indra_belief.curation"] = curation_module
curation_spec.loader.exec_module(curation_module)
spec2 = importlib.util.spec_from_file_location(
    "author_curation_builder", OUT / "official_source/scripts/build_curation_eval.py")
builder = importlib.util.module_from_spec(spec2)
spec2.loader.exec_module(builder)
from indra_belief.scorers.monolithic import scorer

examples = cc.load_all_examples()
assert len(examples) == 56
pairs, norms = builder.fewshot_filters()
cases = [json.loads(x) for x in (OUT / "native_pairs_before_prompt_exclusion.jsonl").read_text().splitlines()]
flat = []
retained, excluded = [], []
for row in cases:
    st = stmts_from_json([row["statement"]], on_missing_support="ignore")[0]
    agents = st.agent_list()
    subject = agents[0].name if agents and agents[0] is not None else "?"
    obj = agents[1].name if len(agents) > 1 and agents[1] is not None else "?"
    probe = {"evidence_text": row["evidence"]["text"], "subject": subject, "object": obj}
    flat.append({"case_id": row["case_id"], **probe})
    if builder.is_contaminated(probe, pairs, norms):
        excluded.append({"case_id": row["case_id"], "reason": "author_fewshot_universe_overlap"})
    else:
        retained.append(row)
p = OUT / "source_pairs_v1.jsonl"
if p.exists():
    raise RuntimeError("Refuse to overwrite an already emitted reference frame")
p.write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in retained))
f = OUT / "guard_input_label_free.jsonl"
f.write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in flat
                     if x["case_id"] in {c["case_id"] for c in retained}))
assert cc.find_contamination(examples=examples, eval_paths=[f]) == []
types = sorted({x["statement"]["type"] for x in retained})
selected = {t: [hashlib.sha256(json.dumps(x, sort_keys=True).encode()).hexdigest()
                for x in scorer._select_examples(t)] for t in types}
assert all(len(x) == 14 for x in selected.values())
manifest = {
    "status": "label_blind_source_frame_ready_pending_root_protocol",
    "input_admitted_pairs": len(cases), "prompt_overlap_exclusions": len(excluded),
    "final_pairs": len(retained), "labels_used": False, "predictions_used": False,
    "all_base_and_type_bank_examples_checked": len(examples),
    "author_overlap_policy": "Exact/substrings/50-character source-text overlap and exact native first-two-agent name pair, from unmodified build_curation_eval.is_contaminated and check_contamination.find_contamination.",
    "family_policy": "Prior exact native entity/type family hashes excluded using the existing project grouping convention; this is not exhaustive homology-family or unknown pretraining exclusion.",
    "case_file": str(p.relative_to(ROOT)), "case_bytes": p.stat().st_size,
    "case_sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
    "case_ids": [x["case_id"] for x in retained],
    "excluded": excluded, "source_type_counts": dict(Counter(x["statement"]["type"] for x in retained)),
    "selected_example_hashes_by_type": selected,
    "author_guard_code_sha256": hashlib.sha256((OUT / "official_source/scripts/check_contamination.py").read_bytes()).hexdigest(),
    "author_admission_code_sha256": hashlib.sha256((OUT / "official_source/scripts/build_curation_eval.py").read_bytes()).hexdigest(),
    "example_bank_sha256": hashlib.sha256((UPSTREAM / "src/indra_belief/data/example_bank.json").read_bytes()).hexdigest(),
    "curation_label_rule_not_changed": "Released strict per-pair correctness, not the prior author-positive full-statement endpoint.",
    "license_scope": "Code package declaresMIT; original2023Zenodo corpusCC-BY-NC-SA4.0; no explicitdataset-specific grant found for2026curations. Raw2026cases remainprivate for bounded research analysis; no redistribution grant inferred.",
}
(OUT / "source_pairs_v1.manifest.json").write_text(json.dumps(manifest, sort_keys=True, indent=2) + "\n")
print(json.dumps({k:manifest[k] for k in [
    "status", "input_admitted_pairs", "prompt_overlap_exclusions", "final_pairs",
    "case_file", "case_bytes", "case_sha256", "source_type_counts",
    "all_base_and_type_bank_examples_checked", "labels_used", "predictions_used"]}, indent=2))
