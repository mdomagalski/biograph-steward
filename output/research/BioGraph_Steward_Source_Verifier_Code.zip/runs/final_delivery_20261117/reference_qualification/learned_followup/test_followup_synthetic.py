"""Invented inputs and mocked supervised fits; no real reference access."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
from unittest.mock import patch
import ast

import numpy as np
from sklearn.exceptions import ConvergenceWarning
from sklearn.preprocessing import OneHotEncoder

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
from test_combined_score_synthetic import make_frame, jsonl, sealed, pin
import pair_reference_tools as metric
import followup


class FakePipeline:
    fits=[]
    def __init__(self):
        self.encoder=OneHotEncoder(handle_unknown="ignore",drop=None)
    def fit(self,X,Y):
        # Only unsupervised encoding is really fitted. No classifier is trained.
        self.fits.append((deepcopy(X),list(Y)))
        self.encoder.fit(X)
        width=len(self.encoder.get_feature_names_out())
        self.named_steps={"encoder":self.encoder,"classifier":SimpleNamespace(
            classes_=np.array([0,1]),coef_=np.zeros((1,width)),intercept_=np.zeros(1),n_iter_=np.array([1]))}
        return self
    def predict(self,X):
        self.encoder.transform(X)  # Unknown source/type categories must succeed.
        return np.ones(len(X),dtype=int)


class NonConverging:
    calls=0
    def fit(self,X,Y):
        self.__class__.calls+=1
        raise ConvergenceWarning("Invented convergence failure")


def fix_frame(spec,name):
    cases=metric._read_jsonl(spec["cases"])
    for c in cases:
        c["evidence"]["source_api"]="fixture_train_source" if name=="primary" else "fixture_unknown_source"
        c["statement"]["type"]="fixture_train_type" if name=="primary" else "fixture_unknown_type"
        c["poison_nonfeature"]="DO_NOT_FEATURE_CASE_OR_PASSAGE"
    jsonl(spec["cases"],cases);spec["cases_sha256"]=metric.sha256(spec["cases"])
    indexed={c["case_id"]:c for c in cases}
    parent=Path(spec["completion_receipt"]).parent
    completion=json.loads(Path(spec["completion_receipt"]).read_text());completion.pop("content_sha256")
    completion["source_cases_sha256"]=spec["cases_sha256"];completion["outputs"]=[]
    for arm in ("base","disconfirm","retain_all"):
        p=parent/(arm+".json");value=json.loads(p.read_text());value.pop("content_sha256")
        value["source_cases_sha256"]=spec["cases_sha256"]
        for r in value["rows"]:
            r["input_sha256"]=metric.canonical_sha256(indexed[r["case_id"]])
            if "result" in r:
                r["result"]["source_case_sha256"]=r["input_sha256"]
                r["result"]["native_result"]={"confidence":"medium","score":.999,
                    "raw_text":"DO_NOT_FEATURE_RAW_REPLY","justification":"DO_NOT_FEATURE_JUSTIFICATION"}
        sealed(p,value);completion["outputs"].append(pin(p))
    sealed(Path(spec["completion_receipt"]),completion)
    return spec


def run():
    # Read the pinned author's static category declaration, not any run output.
    # HERE is reference_qualification/learned_followup; use the sibling path.
    author=HERE.parent.parent/"method_qualification/adapter/upstream/src/indra_belief/verdict.py"
    tree=ast.parse(author.read_text());declared={}
    for node in tree.body:
        if isinstance(node,ast.Assign):
            for target in node.targets:
                if isinstance(target,ast.Name) and target.id=="VALID_CONFIDENCES":
                    declared["categories"]=ast.literal_eval(node.value.args[0])
                if isinstance(target,ast.Name) and target.id=="DEFAULT_CONFIDENCE":
                    declared["default"]=ast.literal_eval(node.value)
    assert declared=={"categories":{"high","medium","low"},"default":"medium"}
    params=followup.make_pipeline().get_params()
    assert params["encoder__handle_unknown"]=="ignore" and params["encoder__drop"] is None
    assert params["classifier__C"]==1 and params["classifier__l1_ratio"]==0
    assert params["classifier__solver"]=="lbfgs" and params["classifier__max_iter"]==1000
    assert params["classifier__class_weight"]=="balanced"
    with tempfile.TemporaryDirectory(prefix="followup-fixture-",dir=HERE) as directory:
        tmp=Path(directory)
        frames={name:fix_frame(make_frame(tmp,name),name) for name in followup.FRAMES}
        p={"format":followup.FORMAT,"parameters":followup.PARAMETERS,"feature_order":list(followup.FEATURES),
            "source_frames_sha256":{n:frames[n]["cases_sha256"] for n in followup.FRAMES},
            "original_protocols_sha256":{n:frames[n]["protocol_sha256"] for n in followup.FRAMES},
            "code_sha256":{"fitter":metric.sha256(HERE/"followup.py"),
                "metric_helper":followup.METRIC_SHA,"original_intake":followup.INTAKE_SHA}}
        protocol=tmp/"followup.json";protocol.write_text(json.dumps(p,sort_keys=True))
        common={"protocol_path":protocol,"expected_protocol_sha256":metric.sha256(protocol),"frames":frames}
        original_constant=metric.RAW_RELEASE_SHA256
        metric.RAW_RELEASE_SHA256=metric.sha256(frames["primary"]["raw_labels"])
        original_open=Path.open
        secondary_label=Path(frames["secondary"]["raw_labels"]).resolve()
        def no_secondary_open(path,*args,**kwargs):
            if path.resolve()==secondary_label:raise AssertionError("Secondary label source was opened")
            return original_open(path,*args,**kwargs)
        try:
            original_prepared,_=followup.load_inputs_without_labels(frames)
            original_rows=deepcopy(original_prepared["primary"]["original_rows"])
            case=next(iter(original_prepared["primary"]["cases"].values()));cid=case["case_id"]
            original_rows["base"][cid]["result"]["native_result"]["confidence"]=None
            assert followup.feature_row(case,original_rows,cid)[3]==followup.ABSENT
            original_rows["base"][cid]["result"]["native_result"]["confidence"]="invented-invalid"
            try:followup.feature_row(case,original_rows,cid)
            except ValueError:pass
            else:raise AssertionError("Unknown parsed confidence was accepted")
            with patch.object(Path,"open",no_secondary_open),patch.object(followup,"feature_row",side_effect=ValueError("Invented feature contract failure")),patch.object(metric,"materialize_labels") as materialize:
                try:followup.fit_and_seal(**common,output_dir=tmp/"must_not_open_gold",root_fit_go=True)
                except ValueError:pass
                else:raise AssertionError("Feature contract failure was ignored")
                materialize.assert_not_called()
                assert not (tmp/"must_not_open_gold").exists()
            with patch.object(Path,"open",no_secondary_open),patch.object(followup,"make_pipeline",FakePipeline):
                receipt=followup.fit_and_seal(**common,output_dir=tmp/"fit",root_fit_go=True)
            assert receipt["eligible_primary_rows"]==4 and receipt["eligible_secondary_rows"]==3
            assert receipt["secondary_total_rows"]==4 and receipt["secondary_labels_accessed"] is False
            assert len(FakePipeline.fits)==2
            assert all("fixture_unknown_source" not in str(x) and "fixture_unknown_type" not in str(x)
                for x,y in FakePipeline.fits)
            assert [len(x[0]) for x,y in FakePipeline.fits]==[2,6]
            assert all("DO_NOT_FEATURE" not in str(x) and "primary0" not in str(x) for x,y in FakePipeline.fits)
            for arm in followup.ARMS:
                envelope=json.loads((tmp/"fit"/(arm+".json")).read_text());followup.verify_seal(envelope)
                assert len(envelope["rows"])==4
                row=next(r for r in envelope["rows"] if r["case_id"]=="secondary1")
                assert row["proposal"]=="abstain" and row["status"]=="shared_noneligible_abstention"
                model=json.loads((tmp/"fit"/(arm+"_model.json")).read_text())
                assert "fixture_unknown_source" not in str(model["model"]["encoder_categories"])
            with patch.object(Path,"open",no_secondary_open),patch.object(followup,"make_pipeline",NonConverging):
                failed=followup.fit_and_seal(**common,output_dir=tmp/"fail",root_fit_go=True)
            assert failed["fit_status"]=="fit_failed_all_secondary_abstain" and NonConverging.calls==1
            for arm in followup.ARMS:
                e=json.loads((tmp/"fail"/(arm+".json")).read_text())
                assert len(e["rows"])==4 and all(r["proposal"]=="abstain" for r in e["rows"])
        finally:
            metric.RAW_RELEASE_SHA256=original_constant
    for function,kwargs in [(followup.fit_and_seal,{"protocol_path":"NEVER_OPEN","expected_protocol_sha256":"x","frames":{},"output_dir":"NEVER_CREATE"}),
        (followup.score_secondary,{"protocol_path":"NEVER_OPEN","expected_protocol_sha256":"x","frames":{},
            "fit_completion":"NEVER_OPEN","labels_path":"NEVER_OPEN","expected_labels_sha256":"x","output_path":"NEVER_CREATE"})]:
        try:function(**kwargs)
        except ValueError:pass
        else:raise AssertionError("Missing separate root GO was accepted")
    result={"status":"passed","invented_inputs_only":True,"actual_reference_data_opened":False,
        "supervised_classifier_fit_mocked":True,"real_secondary_label_open_guard":"passed",
        "fixed_sklearn_recipe_parameters":"passed","feature_whitelist_and_primary_only_encoder":"passed",
        "balanced_class_weight_for_both_models":"passed","absent_confidence_explicit_unknown_confidence_rejected":"passed",
        "official_author_confidence_contract":"passed","all_feature_preflight_before_primary_label_materialization":"passed",
        "unknown_secondary_source_type_categories":"passed","shared_noneligible_full_denominator":"passed",
        "nonconvergence_abstains_both_arms_without_retry":"passed","separate_root_stage_GOs":"passed",
        "fitter_sha256":metric.sha256(HERE/"followup.py")}
    (HERE/"synthetic_fixture_receipt.json").write_text(json.dumps(result,indent=2,sort_keys=True)+"\n")
    return result


if __name__=="__main__":print(json.dumps(run(),indent=2,sort_keys=True))
