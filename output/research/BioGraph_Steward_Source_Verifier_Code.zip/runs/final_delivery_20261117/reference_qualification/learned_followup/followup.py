"""Private, separately frozen primary-fit / secondary-test combination.

No code executes on import. Fitting requires the parent's explicit GO after
both original prediction frames complete. This module never opens the raw
secondary label source. Secondary evaluation requires a second explicit GO,
after fitted encoders/models and both secondary prediction files are sealed.
"""
from collections import Counter
import importlib.metadata
import json
from pathlib import Path
import sys
import warnings

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import combined_score as intake
import pair_reference_tools as metric

FORMAT="biograph-steward.learned-source-combination-followup.v1"
FEATURES=("source_api","native_claim_type","base_decision","base_confidence",
          "disconfirm_decision","disconfirm_confidence")
ARMS=("metadata_only","combined")
FRAMES=("primary","secondary")
PARAMETERS={"sklearn":"1.9.1","C":1.0,"solver":"lbfgs","max_iter":1000,
    "class_weight":"balanced","l1_ratio":0.0,"random_state":20261117,
    "encoder_handle_unknown":"ignore","encoder_drop":None,
    "threshold":"native_predict_default","calibration":False,"search":False}
COMPARISONS=(("combined","base"),("combined","disconfirm"),("combined","metadata_only"))
METRIC_SHA="85524d12d0d7734ddaccefcecf04f8a2d6912bdf0c6a475467fcfc66b694a7c2"
INTAKE_SHA="528dd8864f8e68ca4fa9188231e7a60a4bf4f0b09053791c4ca107208e0223a3"
ABSENT="__ABSENT__"


def need(value,message):
    if not value:raise ValueError("Learned follow-up: "+message)


def write_new(path,value):
    value=dict(value);value["content_sha256"]=metric.canonical_sha256(value)
    with Path(path).open("x") as stream:
        stream.write(json.dumps(value,sort_keys=True,ensure_ascii=False)+"\n")
        stream.flush()
        import os
        os.fsync(stream.fileno())
    return {"path":str(path),"bytes":Path(path).stat().st_size,"sha256":metric.sha256(path)}


def verify_seal(value):
    need(isinstance(value,dict) and value.get("content_sha256")==metric.canonical_sha256(
        {k:v for k,v in value.items() if k!="content_sha256"}),"artifact seal differs")


def verify_pin(pin):
    need(isinstance(pin,dict) and set(pin)=={"path","bytes","sha256"},"invalid raw file pin")
    path=Path(pin["path"])
    need(path.is_file() and not path.is_symlink() and path.stat().st_size==pin["bytes"]
         and metric.sha256(path)==pin["sha256"],"raw file pin differs")
    return path


def verify_protocol(path,expected_sha,frames):
    need(metric.sha256(path)==expected_sha,"follow-up protocol raw hash differs")
    p=json.loads(Path(path).read_text())
    need(p.get("format")==FORMAT and p.get("parameters")==PARAMETERS,"fixed recipe differs")
    need(p.get("feature_order")==list(FEATURES),"fixed feature order differs")
    need(p.get("source_frames_sha256")=={f:frames[f]["cases_sha256"] for f in FRAMES}
         and p.get("original_protocols_sha256")=={f:frames[f]["protocol_sha256"] for f in FRAMES},
         "follow-up source/original protocol bindings differ")
    need(p.get("code_sha256")=={"fitter":metric.sha256(Path(__file__)),
         "metric_helper":METRIC_SHA,"original_intake":INTAKE_SHA},"frozen implementation differs")
    need(metric.sha256(HERE.parent/"pair_reference_tools.py")==METRIC_SHA
         and metric.sha256(HERE.parent/"combined_score.py")==INTAKE_SHA,"frozen dependency differs")
    need(importlib.metadata.version("scikit-learn")==PARAMETERS["sklearn"],"sklearn version differs")
    return p


def load_inputs_without_labels(frames):
    """Reuse strict prediction intake; never open either raw label source."""
    need(set(frames)==set(FRAMES),"both original frames are required")
    prepared,receipts={},{}
    for name in FRAMES:
        f=frames[name]
        need(metric.sha256(f["protocol"])==f["protocol_sha256"],"original protocol changed")
        need(metric.sha256(f["cases"])==f["cases_sha256"]
             and metric.sha256(f["groups"])==f["groups_sha256"],"source/group frame changed")
        rows=metric._read_jsonl(f["cases"]);cases=metric.index_cases(rows)
        need(not any(set(c)&{"gold","label","target","curator_label"} for c in rows),
             "source frame contains outcome fields")
        groups={}
        for g in metric._read_jsonl(f["groups"]):
            cid=g["case_id"];need(cid in cases and cid not in groups,"group IDs differ")
            groups[cid]=g["group_id"]
        need(set(groups)==set(cases),"group frame incomplete")
        completion=json.loads(Path(f["completion_receipt"]).read_text());verify_seal(completion)
        need(completion.get("status")=="completed_sealed_before_scoring"
             and completion.get("protocol_sha256")==f["protocol_sha256"]
             and completion.get("source_cases_sha256")==f["cases_sha256"]
             and completion.get("source_rows")==len(cases)
             and completion.get("all_model_arm_rows_present") is True
             and completion.get("completed_arm_rows")==dict.fromkeys((*intake.ARM_IDS,"retain_all"),len(cases))
             and completion.get("labels_accessed") is False,"original run is not completely sealed before labels")
        need(completion.get("retries")==0 and completion.get("repairs")==0
             and completion.get("resumed") is False,"original one-pass policy differs")
        outputs={}
        for pin in completion.get("outputs",[]):
            path=verify_pin(pin);arm=path.stem
            need(arm in (*intake.ARM_IDS,"retain_all") and arm not in outputs,"output arm differs")
            outputs[arm]=path
        need(set(outputs)==set((*intake.ARM_IDS,"retain_all")),"original output arm missing")
        for key in ("preflight_receipt","run_started","execution_events"):verify_pin(completion[key])
        decisions,original_rows={},{}
        for arm in (*intake.ARM_IDS,"retain_all"):
            if arm in intake.ARM_IDS:
                need(Path(f["predictions"][arm]).resolve()==outputs[arm].resolve(),"original output path differs")
            decisions[arm],_=intake.intake_envelope(outputs[arm],cases=cases,
                frame_sha256=f["cases_sha256"],protocol_sha256=f["protocol_sha256"],arm_id=arm)
            original_rows[arm]={r["case_id"]:r for r in json.loads(outputs[arm].read_text())["rows"]}
        prepared[name]={"cases":cases,"groups":groups,"decisions":decisions,"original_rows":original_rows}
        receipts[name]={"source_cases_sha256":f["cases_sha256"],"completion":{
            "path":str(f["completion_receipt"]),"bytes":Path(f["completion_receipt"]).stat().st_size,
            "sha256":metric.sha256(f["completion_receipt"])},"pairs":len(cases)}
    return prepared,receipts


def eligible(rows,cid):
    return all(rows[arm][cid].get("status")=="completed"
        and rows[arm][cid].get("proposal") in {"support","reject"}
        and rows[arm][cid].get("result",{}).get("verdict") in {"correct","incorrect"}
        for arm in intake.ARM_IDS)


def feature_row(case,rows,cid):
    """Only six declared categorical fields; no reply parsing or identifiers."""
    source=case["evidence"].get("source_api")
    source=source if isinstance(source,str) and source else ABSENT
    kind=case["statement"].get("type")
    need(isinstance(kind,str) and bool(kind),"native claim type missing")
    values=[source,kind]
    for arm in intake.ARM_IDS:
        row=rows[arm][cid];decision=row.get("proposal")
        need(decision in metric.DECISIONS,"invalid original categorical decision")
        native=row.get("result",{}).get("native_result")
        need(native is None or isinstance(native,dict),"native parser result has unexpected shape")
        confidence=native.get("confidence") if native is not None else None
        need(confidence is None or confidence in {"high","medium","low"},"unknown parsed confidence category")
        values.extend((decision,confidence if confidence is not None else ABSENT))
    return values


def make_pipeline():
    from sklearn.pipeline import Pipeline
    from sklearn.preprocessing import OneHotEncoder
    from sklearn.linear_model import LogisticRegression
    return Pipeline([("encoder",OneHotEncoder(handle_unknown="ignore",drop=None)),
        ("classifier",LogisticRegression(C=1.0,solver="lbfgs",max_iter=1000,
            class_weight="balanced",l1_ratio=0.0,random_state=20261117))])


def serialize_model(model,features):
    import numpy as np
    encoder,clf=model.named_steps["encoder"],model.named_steps["classifier"]
    need(list(clf.classes_)==[0,1] and np.isfinite(clf.coef_).all()
         and np.isfinite(clf.intercept_).all(),"fitted classifier state is invalid")
    return {"feature_order":list(features),"encoder_categories":[[str(x) for x in c] for c in encoder.categories_],
        "encoded_feature_names":[str(x) for x in encoder.get_feature_names_out(features)],
        "coef":clf.coef_.tolist(),"intercept":clf.intercept_.tolist(),"classes":[0,1],
        "iterations":[int(x) for x in clf.n_iter_],"parameters":PARAMETERS,
        "probability_calibration_claim":False}


def fit_and_seal(*,protocol_path,expected_protocol_sha256,frames,output_dir,root_fit_go=False):
    need(root_fit_go is True,"root fit GO required before real input access")
    verify_protocol(protocol_path,expected_protocol_sha256,frames)
    prepared,input_receipts=load_inputs_without_labels(frames)
    # Validate every potentially fitted/applied feature while both gold sources
    # remain closed. A contract problem must never be discovered after labels.
    train,test=prepared["primary"],prepared["secondary"]
    train_ids=[cid for cid in train["cases"] if eligible(train["original_rows"],cid)]
    test_ids=[cid for cid in test["cases"] if eligible(test["original_rows"],cid)]
    X=[feature_row(train["cases"][cid],train["original_rows"],cid) for cid in train_ids]
    Z=[feature_row(test["cases"][cid],test["original_rows"],cid) for cid in test_ids]
    need(all(len(row)==len(FEATURES) and all(isinstance(value,str) for value in row)
             for row in (*X,*Z)),"pre-label categorical feature matrix shape differs")
    feature_preflight={"feature_order":list(FEATURES),"eligible_primary_rows":len(train_ids),
        "eligible_secondary_rows":len(test_ids),"primary_feature_matrix_sha256":metric.canonical_sha256(X),
        "secondary_feature_matrix_sha256":metric.canonical_sha256(Z),
        "both_metadata_only_views_have_two_columns":all(len(row[:2])==2 for row in (*X,*Z)),
        "both_reference_label_sources_unopened":True}
    output=Path(output_dir);output.mkdir(parents=True,exist_ok=False)
    write_new(output/"before_primary_labels.json",{"followup_protocol_sha256":expected_protocol_sha256,
        "both_original_frames_sealed":True,"secondary_label_source_opened":False,"inputs":input_receipts,
        "feature_preflight":feature_preflight})
    f=frames["primary"]
    label_receipt=metric.materialize_labels(raw_path=f["raw_labels"],frame_path=f["cases"],
        output_path=output/"primary_training_labels_private.jsonl",expected_frame_sha256=f["cases_sha256"],
        protocol_path=protocol_path,expected_protocol_sha256=expected_protocol_sha256,label_access_authorized=True)
    labels={r["case_id"]:r["gold"] for r in metric._read_jsonl(output/"primary_training_labels_private.jsonl")}
    Y=[1 if labels[cid]=="supported" else 0 for cid in train_ids]
    models,model_pins,generated={},[],{}
    fit_status,error="fitted",None
    try:
        from sklearn.exceptions import ConvergenceWarning
        need(len(train_ids)>0 and set(Y)=={0,1},"eligible training frame lacks both classes")
        with warnings.catch_warnings():
            warnings.simplefilter("error",ConvergenceWarning)
            for arm in ARMS:
                use=[row[:2] for row in X] if arm=="metadata_only" else X
                query=[row[:2] for row in Z] if arm=="metadata_only" else Z
                model=make_pipeline();model.fit(use,Y)
                predictions=model.predict(query).tolist() if query else []
                need(len(predictions)==len(test_ids) and all(v in (0,1) for v in predictions),"native classifier prediction is invalid")
                models[arm]=serialize_model(model,FEATURES[:2] if arm=="metadata_only" else FEATURES)
                generated[arm]=dict(zip(test_ids,predictions))
    except Exception as exc:
        fit_status,error="fit_failed_all_secondary_abstain",type(exc).__name__
        models,generated={},{}
    for arm in ARMS:
        payload={"arm_id":arm,"followup_protocol_sha256":expected_protocol_sha256,
            "fit_status":fit_status,"error_type":error,"eligible_training_rows":len(train_ids),
            "eligible_training_case_ids_private":train_ids,
            "training_frame_sha256":frames["primary"]["cases_sha256"],
            "secondary_labels_accessed":False,"model":models.get(arm)}
        model_pins.append(write_new(output/(arm+"_model.json"),payload))
    output_pins=[]
    for arm in ARMS:
        rows=[]
        for cid,case in test["cases"].items():
            value=generated.get(arm,{}).get(cid)
            rows.append({"case_id":cid,"input_sha256":metric.canonical_sha256(case),"arm_id":arm,
                "proposal":"abstain" if value is None else "support" if value==1 else "reject",
                "status":("fit_failure_abstention" if fit_status!="fitted" else "shared_noneligible_abstention")
                    if value is None else "fixed_classifier_prediction"})
        output_pins.append(write_new(output/(arm+".json"),{"format":FORMAT+".predictions",
            "arm_id":arm,"followup_protocol_sha256":expected_protocol_sha256,
            "source_cases_sha256":frames["secondary"]["cases_sha256"],"rows":rows,
            "secondary_labels_accessed":False}))
    # Reverify frozen prediction/source identities; neither reference source is read.
    verify_protocol(protocol_path,expected_protocol_sha256,frames)
    _,after=load_inputs_without_labels(frames)
    need(after==input_receipts,"original inputs changed during fit")
    receipt={"status":"secondary_models_and_predictions_sealed_before_secondary_labels",
        "fit_status":fit_status,"error_type":error,"followup_protocol_sha256":expected_protocol_sha256,
        "primary_training_label_receipt":label_receipt,"eligible_primary_rows":len(train_ids),
        "primary_total_rows":len(train["cases"]),"eligible_secondary_rows":len(test_ids),
        "secondary_total_rows":len(test["cases"]),"secondary_labels_accessed":False,
        "model_files":model_pins,"prediction_files":output_pins,"input_receipts":input_receipts,
        "no_retries_or_search":True,"no_new_model_calls":True}
    write_new(output/"completion.json",receipt)
    return receipt


def score_secondary(*,protocol_path,expected_protocol_sha256,frames,fit_completion,
                    labels_path,expected_labels_sha256,output_path,root_score_go=False):
    need(root_score_go is True,"separate root scoring GO required before secondary labels")
    verify_protocol(protocol_path,expected_protocol_sha256,frames)
    receipt=json.loads(Path(fit_completion).read_text());verify_seal(receipt)
    need(receipt.get("status")=="secondary_models_and_predictions_sealed_before_secondary_labels"
         and receipt.get("followup_protocol_sha256")==expected_protocol_sha256
         and receipt.get("secondary_labels_accessed") is False,"pre-label fit/prediction seal missing")
    for pin in receipt["model_files"]:verify_pin(pin)
    prepared,_=load_inputs_without_labels(frames);test=prepared["secondary"]
    decisions={arm:values for arm,values in test["decisions"].items()}
    for pin in receipt["prediction_files"]:
        path=verify_pin(pin);envelope=json.loads(path.read_text());verify_seal(envelope);arm=envelope["arm_id"]
        need(arm in ARMS and arm not in decisions and envelope.get("followup_protocol_sha256")==expected_protocol_sha256
             and envelope.get("source_cases_sha256")==frames["secondary"]["cases_sha256"],"learned prediction binding differs")
        values={}
        for row in envelope["rows"]:
            cid=row["case_id"]
            need(cid in test["cases"] and cid not in values
                 and row["input_sha256"]==metric.canonical_sha256(test["cases"][cid])
                 and row["proposal"] in metric.DECISIONS,"learned row binding differs")
            values[cid]=row["proposal"]
        need(set(values)==set(test["cases"]),"learned arm frame incomplete")
        decisions[arm]=values
    need(set(decisions)==set((*intake.ARM_IDS,"retain_all",*ARMS)),"all five arms required")
    need(metric.sha256(labels_path)==expected_labels_sha256,"released secondary label ledger changed")
    rows=metric._read_jsonl(labels_path);labels={r["case_id"]:r["gold"] for r in rows}
    need(len(labels)==len(rows) and set(labels)==set(test["cases"]),"secondary label frame differs")
    for row in rows:
        case=test["cases"][row["case_id"]]
        need(row.get("statement_payload_sha256")==case["statement_payload_sha256"]
             and row.get("matches_hash")==case["matches_hash"]
             and row.get("source_hash")==case["source_hash"],"secondary source/claim label binding differs")
    methods={arm:metric.metrics(labels,value) for arm,value in decisions.items()}
    bootstrap=metric.paired_group_bootstrap(labels,decisions,test["groups"],COMPARISONS)
    success=all(r["difference"]>0 and r["percentile_95_interval"][0]>0 for r in bootstrap["comparisons"])
    report={"format":FORMAT+".assessment","followup_protocol_sha256":expected_protocol_sha256,
        "secondary_pairs":len(labels),"groups":len(set(test["groups"].values())),"metrics":methods,
        "paired_group_bootstrap":bootstrap,"prespecified_success_over_all_three":success,
        "fit_completion_sha256":metric.sha256(fit_completion),"secondary_label_ledger_sha256":expected_labels_sha256,
        "scope":"Selected held-out curator-reference transfer, conditional on this fixed primary fit. No calibrated probability, biological truth, app feature or automatic graph-pruning claim.",
        "training_hyperparameters_searched":False,"graph_changed":False}
    write_new(output_path,report);return report
