"""Invented-only label-join fixtures. Never opens a real reference source."""
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile

import pair_reference_tools as primary


def jsonl(path, rows):
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows))


def run():
    path = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("external_label_tools",
        path / "secondary_external154/external_label_tools.py")
    external = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(external)
    with tempfile.TemporaryDirectory(prefix="label-fixture-", dir=path) as directory:
        tmp = Path(directory)
        protocol = tmp / "protocol.json"
        protocol.write_text('{"purpose":"invented synthetic fixture only"}\n')
        frame = tmp / "frame.jsonl"
        cases = [{"case_id": "fixture-" + str(i), "matches_hash": str(i),
                  "source_hash": str(i + 10), "statement": {"type": "Fixture"},
                  "evidence": {"text": "Invented fixture only."},
                  "statement_payload_sha256": "f" * 64} for i in (1, 2)]
        jsonl(frame, cases)
        common = {"frame_path": frame, "expected_frame_sha256": primary.sha256(frame),
                  "protocol_path": protocol, "expected_protocol_sha256": primary.sha256(protocol),
                  "label_access_authorized": True}
        source = tmp / "primary.jsonl"
        jsonl(source, [{"matches_hash": "1", "source_hash": "11", "tag": "correct"},
                       {"matches_hash": "2", "source_hash": "12", "tag": "hypothesis"},
                       {"matches_hash": "999", "source_hash": "999", "tag": ["do-not-index"]}])
        original = primary.RAW_RELEASE_SHA256
        primary.RAW_RELEASE_SHA256 = primary.sha256(source)
        try:
            target = tmp / "primary-labels.jsonl"
            primary.materialize_labels(raw_path=source, output_path=target, **common)
            values = primary._read_jsonl(target)
            assert [row["gold"] for row in values] == ["supported", "unsupported"]
            try:
                primary.materialize_labels(raw_path=source, output_path=target,
                    **{**common, "label_access_authorized": False})
            except ValueError:
                pass
            else:
                raise AssertionError("Unauthorized fixture label access was accepted")
        finally:
            primary.RAW_RELEASE_SHA256 = original
        source = tmp / "external.jsonl"
        jsonl(source, [{"matches_hash": "1", "source_hash": "11", "tag": "correct",
                        "all_tags": ["correct"], "gold": "correct"},
                       {"matches_hash": "2", "source_hash": "12", "tag": "grounding",
                        "all_tags": ["correct", "grounding"], "gold": "incorrect"},
                       {"matches_hash": "999", "source_hash": "999",
                        "all_tags": ["do-not-index"], "gold": {"malformed": True}}])
        original = external.EXTERNAL_RELEASE_SHA256
        external.EXTERNAL_RELEASE_SHA256 = primary.sha256(source)
        try:
            target = tmp / "external-labels.jsonl"
            external.materialize_external_labels(raw_path=source, output_path=target, **common)
            values = primary._read_jsonl(target)
            assert [row["gold"] for row in values] == ["supported", "unsupported"]
        finally:
            external.EXTERNAL_RELEASE_SHA256 = original
    result = {"invented_primary_correct_only_endpoint": "passed",
              "invented_secondary_any_incorrect_endpoint": "passed",
              "unselected_malformed_outcomes_not_inspected": "passed",
              "explicit_authorization_required": "passed",
              "real_reference_labels_opened": False,
              "primary_helper_sha256": primary.sha256(path / "pair_reference_tools.py"),
              "external_helper_sha256": primary.sha256(path / "secondary_external154/external_label_tools.py")}
    (path / "materializer_synthetic_fixtures.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n")
    return result


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
