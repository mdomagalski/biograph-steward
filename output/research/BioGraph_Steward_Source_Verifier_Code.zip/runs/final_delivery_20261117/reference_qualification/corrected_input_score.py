"""Private sealed-output intake for the prespecified consumed-reference diagnostic.

Import and synthetic_check do not open reference data. run_assessment requires
separate ROOT scoring GO after all four full-frame prediction envelopes seal.
No fitting, source relabelling, case selection by outcomes or graph changes.
"""
from collections import Counter
from copy import deepcopy
import json
from pathlib import Path

import pair_reference_tools as metric

METRIC_SHA = '85524d12d0d7734ddaccefcecf04f8a2d6912bdf0c6a475467fcfc66b694a7c2'
ARMS = ('nano_partial_cached', 'nano_full', 'qwen_partial', 'qwen_full')
CONTRASTS = (('nano_full', 'nano_partial_cached'), ('qwen_full', 'qwen_partial'),
             ('qwen_partial', 'nano_partial_cached'), ('qwen_full', 'nano_full'))
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]


def need(value, message):
    metric._need(value, message)


def sealed(path):
    d = json.loads(Path(path).read_text())
    need(isinstance(d, dict), 'Sealed artifact must be an object')
    body = deepcopy(d)
    seal = body.pop('content_sha256', None)
    need(isinstance(seal, str) and metric.canonical_sha256(body) == seal,
         'Artifact content seal differs: ' + str(path))
    return d


def raw_pin(path):
    p = Path(path)
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': metric.sha256(p)}


def resolve_pin(pin):
    p = Path(pin['path'])
    if not p.is_absolute():
        p = ROOT / p
    need(p.is_file() and p.stat().st_size == pin['bytes'] and metric.sha256(p) == pin['sha256'],
         'Pinned input differs: ' + str(p))
    return p


def indexed(rows, expected_ids, *, name):
    out = {}
    for r in rows:
        need(isinstance(r, dict), name + ': non-object row')
        cid = r.get('case_id')
        need(cid in expected_ids and cid not in out, name + ': extra/duplicate row')
        out[cid] = r
    need(set(out) == set(expected_ids), name + ': missing row; no partial-frame repair')
    return out


def validate_native_result(row):
    r = row.get('result')
    need(isinstance(r, dict) and r.get('source_case_sha256') == row['input_sha256'],
         'Native result full-case binding differs')
    need(r.get('status') == row['status'] and r.get('original_case_unchanged') is True,
         'Native result status or unchanged source assertion differs')
    if row['proposal'] == 'abstain':
        need(r.get('status') == 'abstain' and r.get('verdict') is None,
             'Abstention disagrees with native result')
    else:
        need(r.get('status') == 'completed' and r.get('verdict') ==
             ('correct' if row['proposal'] == 'support' else 'incorrect'),
             'Decision disagrees with native categorical verdict')


def preflight(*, runtime_protocol, expected_runtime_sha256, scoring_spec,
              expected_scoring_sha256, execution_dir):
    """Verify all source and completion seals without reading labels' fields."""
    need(metric.sha256(HERE / 'pair_reference_tools.py') == METRIC_SHA, 'Frozen metrics changed')
    need(metric.sha256(runtime_protocol) == expected_runtime_sha256, 'Runtime protocol pin differs')
    need(metric.sha256(scoring_spec) == expected_scoring_sha256, 'Scoring specification pin differs')
    p = json.loads(Path(runtime_protocol).read_text())
    s = json.loads(Path(scoring_spec).read_text())
    need(p.get('status') == 'ROOT_FROZEN_CORRECTED_INPUT_DIAGNOSTIC', 'Runtime protocol not ROOT-frozen')
    need(s.get('format') == 'biograph-steward.corrected-input-2x2-scoring.v1', 'Unknown scoring specification')
    need(s.get('arms') == list(ARMS) and s.get('prespecified_contrasts') == [list(c) for c in CONTRASTS],
         'Prespecified arms/contrasts changed')
    need(s['focal_diagnostic_contrast']['positive_arm'] == 'qwen_full' and
         s['focal_diagnostic_contrast']['reference_arm'] == 'nano_full', 'Focal contrast changed')
    paths = {name: resolve_pin(pin) for name, pin in s['inputs'].items()}
    need(p['source_cases']['sha256'] == s['inputs']['full_evidence_cases']['sha256'] and
         p['cached_nano_partial']['sha256'] == s['inputs']['cached_nano_partial']['sha256'] and
         p['partial_cases']['sha256'] == s['inputs']['partial_released_cases']['sha256'],
         'Runtime and scoring source/cached bindings differ')
    rows = metric._read_jsonl(paths['full_evidence_cases'])
    cases = indexed(rows, {r['case_id'] for r in rows}, name='cases')
    need(len(rows) == len(cases) == s['cohort']['pairs'] == p['expected_case_count'] == 145,
         'Full145 denominator changed')
    partial_rows = metric._read_jsonl(paths['partial_released_cases'])
    partial = indexed(partial_rows, cases, name='partial cases')
    need([r['case_id'] for r in rows] == [r['case_id'] for r in partial_rows], 'Partial/full order differs')
    for cid, case in cases.items():
        need(case['original_partial_case_sha256'] == metric.canonical_sha256(partial[cid]) and
             case['statement'] == partial[cid]['statement'], 'Original native claim binding changed')
    groups_raw = indexed(metric._read_jsonl(paths['groups']), cases, name='groups')
    groups = {cid: row['group_id'] for cid, row in groups_raw.items()}
    need(all(isinstance(g, str) and g for g in groups.values()) and
         len(set(groups.values())) == s['cohort']['connected_source_groups'] == 87,
         'Connected-source groups changed')
    out = Path(execution_dir)
    completion = sealed(out / 'completion.json')
    need(completion.get('status') == 'completed_sealed_before_scoring' and
         completion.get('protocol_sha256') == expected_runtime_sha256 and
         completion.get('source_cases_sha256') == s['inputs']['full_evidence_cases']['sha256'] and
         completion.get('source_rows') == 145 and completion.get('all_model_arm_rows_present') is True and
         completion.get('completed_arm_rows') == dict.fromkeys(ARMS, 145) and
         completion.get('labels_accessed') is False and completion.get('retries') == 0 and
         completion.get('repairs') == 0 and completion.get('resumed') is False and
         completion.get('live_graph_changes') is False,
         'Whole-frame completion receipt does not establish the frozen one-pass study')
    need(0 <= completion['new_model_requests'] <= 435, 'Request budget violated')
    need(len(completion['outputs']) == 4, 'Completion omits outputs')
    output_pins = {}
    for pin in completion['outputs']:
        path = resolve_pin(pin)
        need(path.name in {a + '.json' for a in ARMS} and path.parent.resolve() == out.resolve() and
             path.name not in output_pins, 'Unexpected/duplicate completed output')
        output_pins[path.name] = pin
    prepath = resolve_pin(completion['preflight'])
    need(prepath.resolve() == (out/'preflight.json').resolve(), 'Completion preflight path differs')
    pre = sealed(prepath)
    need(pre.get('status') == 'passed' and pre.get('source_rows') == 145 and
         pre.get('protocol_sha256') == expected_runtime_sha256 and
         pre.get('source_cases_sha256') == s['inputs']['full_evidence_cases']['sha256'] and
         pre.get('actual_generation_requests') == 0, 'Valid generation-free preflight required')
    mask_path = resolve_pin(pre['technical_mask'])
    mask = indexed(metric._read_jsonl(mask_path), cases, name='pre-generation technical mask')
    for cid, row in mask.items():
        need(row['input_sha256'] == metric.canonical_sha256(cases[cid]) and set(row['eligible']) == set(ARMS)
             and all(type(x) is bool for x in row['eligible'].values()) and
             row['joint_eligible'] is all(row['eligible'].values()), 'Technical-mask binding changed')
    need(sum(r['joint_eligible'] for r in mask.values()) == pre['all_four_joint_eligible'], 'Mask count differs')
    equivalent_path = resolve_pin(pre['payload_equivalence'])
    equivalent = json.loads(equivalent_path.read_text())
    eqseen = set()
    for row in equivalent['rows']:
        k = (row.get('case_id'), row.get('model'))
        need(k[0] in cases and k[1] in ('nano','qwen') and k not in eqseen and
             row.get('status') in ('identical','changed','noncallable'), 'Invalid payload-equivalence audit')
        eqseen.add(k)
    need(len(eqseen) == 290 and dict(Counter(r['model']+':'+r['status'] for r in equivalent['rows']))
         == equivalent['counts'], 'Payload-equivalence census differs')
    original = sealed(paths['cached_nano_partial'])
    original_rows = indexed(original['rows'], cases, name='cached original rows')
    decisions, pins = {}, {}
    for arm in ARMS:
        path = out/(arm+'.json')
        env = sealed(path)
        need(env.get('format') == 'biograph-steward.original-evidence-predictions.v1' and
             env.get('arm_id') == arm and env.get('protocol_sha256') == expected_runtime_sha256 and
             env.get('source_cases_sha256') == s['inputs']['full_evidence_cases']['sha256'],
             'Prediction envelope frame/protocol/arm differs')
        rr = indexed(env['rows'], cases, name=arm)
        decisions[arm] = {}
        for cid, row in rr.items():
            need(row['arm_id'] == arm and row['input_sha256'] == metric.canonical_sha256(cases[cid]) and
                 row['source_case_sha256'] == row['input_sha256'] and row['proposal'] in metric.DECISIONS,
                 'Prediction full-case binding or decision differs')
            if arm == 'nano_partial_cached':
                need(row['cached_original_row'] == original_rows[cid] and
                     row['cached_original_row_sha256'] == metric.canonical_sha256(original_rows[cid]) and
                     row['original_partial_case_sha256'] == cases[cid]['original_partial_case_sha256'] and
                     row['proposal'] == original_rows[cid]['proposal'] and
                     row['status'] == original_rows[cid]['status'] and row['new_model_requests'] == 0,
                     'Cached original outcome was changed or rebound')
            else:
                validate_native_result(row)
                if not mask[cid]['eligible'][arm]:
                    need(row['proposal'] == 'abstain', 'Preflight-ineligible fresh case did not abstain')
            decisions[arm][cid] = row['proposal']
        pins[arm] = {**raw_pin(path), 'content_sha256':env['content_sha256']}
    # The raw-label file has only been hash-pinned so far; no gold fields read.
    return {'cases':cases,'groups':groups,'mask':mask,'predictions':decisions,'spec':s,
            'label_path':paths['unchanged_curator_labels_private'],
            'evidence':{'completion':raw_pin(out/'completion.json'),'preflight':raw_pin(prepath),
             'predictions':pins,'technical_mask':raw_pin(mask_path),'payload_equivalence':raw_pin(equivalent_path),
             'payload_equivalence_counts':equivalent['counts'],'runtime_protocol':raw_pin(runtime_protocol),
             'scoring_specification':raw_pin(scoring_spec)}}


def measured(labels, predictions, groups):
    result = {'pairs':len(labels),'groups':len(set(groups.values())),
              'reference_class_counts':dict(Counter(labels.values()))}
    if len(set(labels.values())) != 2 or len(set(groups.values())) < 2:
        return {**result,'status':'unavailable_insufficient_reference_classes_or_groups'}
    arms = {a: metric.metrics(labels, decisions) for a,decisions in predictions.items()}
    for m in arms.values():
        m['sensitivity'] = metric._ratio(m['counts']['support_supported'],m['counts']['supported'])
        m['specificity'] = m['error_recall']
    bootstrap = metric.paired_group_bootstrap(labels,predictions,groups,CONTRASTS)
    focal = next(x for x in bootstrap['comparisons'] if
                 (x['candidate'],x['comparator']) == ('qwen_full','nano_full'))
    gates = {'positive_BA_interval': focal['difference'] > 0 and focal['percentile_95_interval'][0] > 0,
             'supported_rejections_no_worse': arms['qwen_full']['counts']['reject_supported'] <=
                 arms['nano_full']['counts']['reject_supported'],
             'coverage_no_lower': arms['qwen_full']['coverage'] >= arms['nano_full']['coverage']}
    return {**result,'status':'evaluated','arms':arms,'paired_uncertainty':bootstrap,
            'focal_practical_improvement_gate':{'contrast':'qwen_full minus nano_full',
              'components':gates,'passes_all':all(gates.values()),
              'production_promotion_allowed':False}}


def run_assessment(*, runtime_protocol, expected_runtime_sha256, scoring_spec,
                   expected_scoring_sha256, execution_dir, output_path, root_score_go=False):
    need(root_score_go is True, 'Separate ROOT scoring GO is required')
    output = Path(output_path)
    need(not output.exists(), 'Never replace prior diagnostic results')
    verified = preflight(runtime_protocol=runtime_protocol,expected_runtime_sha256=expected_runtime_sha256,
                         scoring_spec=scoring_spec,expected_scoring_sha256=expected_scoring_sha256,
                         execution_dir=execution_dir)
    rows = indexed(metric._read_jsonl(verified['label_path']),verified['cases'],name='unchanged curator labels')
    labels = {cid:row['gold'] for cid,row in rows.items()}
    need(set(labels.values()) == {'supported','unsupported'} and Counter(labels.values()) ==
         {'supported':72,'unsupported':73}, 'Original reference label classes changed')
    all_n = measured(labels,verified['predictions'],verified['groups'])
    ids = {cid for cid,row in verified['mask'].items() if row['joint_eligible']}
    secondary = measured({i:labels[i] for i in ids},
        {a:{i:d[i] for i in ids} for a,d in verified['predictions'].items()},
        {i:verified['groups'][i] for i in ids})
    result = {'format':'biograph-steward.corrected-input-diagnostic-assessment.v1',
        'scope':'Consumed-reference paired model/input diagnostic. Not an independent test, biological truth estimate, causal capacity study or automatic graph pruning.',
        'all_N_primary':all_n,'pre_generation_common_technical_mask_secondary':secondary,
        'intake':verified['evidence'],'unchanged_curator_label_sha256':metric.sha256(verified['label_path']),
        'new_models_fitted':False,'new_reference_labels_assigned':False,'graph_or_review_states_changed':False,
        'cached_original_outcomes_changed':False,'pointwise_intervals_not_simultaneous':True}
    result['content_sha256'] = metric.canonical_sha256(result)
    output.parent.mkdir(parents=True,exist_ok=True)
    with output.open('x') as stream:json.dump(result,stream,sort_keys=True,indent=2);stream.write('\n')
    return result


def synthetic_check():
    metric.synthetic_check()
    cases = {'a':{'case_id':'a'},'b':{'case_id':'b'}}
    need(len(indexed(list(cases.values()),cases,name='synthetic')) == 2,'Index fixture failed')
    for malformed in ([cases['a']],list(cases.values())+[cases['a']]):
        try:indexed(malformed,cases,name='synthetic')
        except ValueError:pass
        else:raise AssertionError('Partial/duplicated frame accepted')
    try:run_assessment(runtime_protocol='',expected_runtime_sha256='',scoring_spec='',
        expected_scoring_sha256='',execution_dir='',output_path='',root_score_go=False)
    except ValueError:pass
    else:raise AssertionError('Scored without ROOT authorization')
    labels={'a':'supported','b':'supported','c':'unsupported','d':'unsupported'}
    pred={'a':'support','b':'abstain','c':'reject','d':'support'}
    m=metric.metrics(labels,pred)
    need(m['counts']['pairs']==4 and m['counts']['abstentions']==1 and
         m['balanced_accuracy_abstention_zero']==.5,'Full-frame abstention fixture failed')
    invalid={**labels,'a':'unknown'}
    try:metric.metrics(invalid,pred)
    except ValueError:pass
    else:raise AssertionError('Unknown gold accepted')
    # Only invented inputs exercise the paired contrast sign and focal gate.
    all_support=dict.fromkeys(labels,'support')
    perfect={cid:('support' if gold=='supported' else 'reject') for cid,gold in labels.items()}
    mock=measured(labels,{'nano_partial_cached':all_support,'nano_full':all_support,
        'qwen_partial':all_support,'qwen_full':perfect},{cid:'group_'+cid for cid in labels})
    focal=mock['paired_uncertainty']['comparisons'][-1]
    need(focal['candidate']=='qwen_full' and focal['comparator']=='nano_full' and
         focal['difference']==.5 and focal['percentile_95_interval']==[.5,.5] and
         mock['focal_practical_improvement_gate']['passes_all'] is True,
         'Focal contrast sign/interval/gate fixture failed')
    same=measured(labels,dict.fromkeys(ARMS,all_support),{cid:'group_'+cid for cid in labels})
    need(same['focal_practical_improvement_gate']['passes_all'] is False,
         'Zero gain incorrectly passed focal gate')
    row={'input_sha256':'x','proposal':'abstain','status':'abstain',
         'result':{'source_case_sha256':'x','status':'abstain','verdict':None,
                   'original_case_unchanged':True}}
    validate_native_result(row)
    row['result']['verdict']='incorrect'
    try:validate_native_result(row)
    except ValueError:pass
    else:raise AssertionError('Malformed abstention accepted')
    return {'synthetic_intake_and_metric_checks':'passed','real_labels_or_predictions_read':False}


if __name__ == '__main__':
    print(json.dumps(synthetic_check(),sort_keys=True))
