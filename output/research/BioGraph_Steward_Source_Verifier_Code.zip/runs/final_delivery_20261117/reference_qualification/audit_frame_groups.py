"""Reproduce label-blind whole-group quarantine and score grouping."""
from collections import Counter
import hashlib
import json
from pathlib import Path

import simplejson
from indra.statements import stmts_from_json

OUT = Path(__file__).resolve().parent


def digest(value):
    return hashlib.sha256(simplejson.dumps(value, sort_keys=True,
        separators=(",", ":"), ensure_ascii=False, use_decimal=True,
        allow_nan=False).encode()).hexdigest()


def tokens(row):
    statement = stmts_from_json([row["statement"]], on_missing_support="ignore")[0]
    family = "native_entity_type_family:" + digest({"type": row["statement"]["type"],
        "entity_keys": [a.entity_matches_key() if a is not None else None
                        for a in statement.agent_list(deep_sorted=True)]})
    pmid = str(row.get("pmid") or "").strip()
    return {"claim:" + str(row["matches_hash"]),
            "source:" + str(row["source_hash"]), family} | (
                {"PMID:" + pmid} if pmid and pmid.isdecimal() else set())


def run():
    raw = [json.loads(line) for line in (OUT /
        "private_original/representative_indra_curations_400.jsonl").read_text().splitlines()]
    cases = [json.loads(line) for line in (OUT / "source_pairs_v1.jsonl").read_text().splitlines()]
    exposed = json.loads((OUT / "metadata_label_exposure_exclusions.json").read_text())
    seed_ids = {"indra-pair:" + str(x["matches_hash"]) + ":" + str(x["source_hash"])
                for x in exposed["pairs"]}
    row_tokens = {"indra-pair:" + str(r["matches_hash"]) + ":" + str(r["source_hash"]): tokens(r)
                  for r in raw}
    closed = set(seed_ids)
    while True:
        exposure_tokens = set().union(*(row_tokens[cid] for cid in closed))
        expanded = {cid for cid, value in row_tokens.items() if value & exposure_tokens}
        if expanded <= closed:
            break
        closed |= expanded
    assert len(closed) == 11 and closed == seed_ids, "Unaccounted exposure family remains"
    assert not (closed & {c["case_id"] for c in cases}), "Exposed group entered primary frame"
    parent = {case["case_id"]: case["case_id"] for case in cases}

    def find(cid):
        while parent[cid] != cid:
            parent[cid] = parent[parent[cid]]
            cid = parent[cid]
        return cid

    seen = {}
    for case in cases:
        cid = case["case_id"]
        for token in row_tokens[cid]:
            if token in seen:
                parent[find(cid)] = find(seen[token])
            else:
                seen[token] = cid
    groups = Counter(find(c["case_id"]) for c in cases)
    counts = {key: len({case[key] for case in cases})
              for key in ("matches_hash", "source_hash", "native_entity_type_family")}
    counts["pmid"] = len({case["evidence"]["pmid"] for case in cases})
    report = {"pairs": len(cases), "unique": counts,
        "connected_group_count": len(groups),
        "connected_group_size_counts": dict(Counter(groups.values())),
        "metadata_exposed_pairs": len(seed_ids),
        "metadata_exposure_transitive_claim_source_publication_nativefamily_closure": len(closed),
        "extra_closure_cases": len(closed - seed_ids), "label_values_used": False}
    (OUT / "grouping_and_quarantine_audit.json").write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n")
    (OUT / "group_membership_v1.jsonl").write_text("".join(json.dumps({
        "case_id": case["case_id"],
        "group_id": "group:" + hashlib.sha256(find(case["case_id"]).encode()).hexdigest()[:24]},
        sort_keys=True) + "\n" for case in cases))
    return report


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
