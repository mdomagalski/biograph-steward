"""Separate sealed-label intake for the optional external-curator endpoint.

Importing this module opens no source records. Only the parent may authorize
materialization after separately freezing this secondary protocol and sealing
all predictions. This is not the primary first-write 403-case label rule.
"""
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from pair_reference_tools import CURATION_TAGS, _need, _read_jsonl, index_cases, sha256

EXTERNAL_RELEASE_SHA256 = "64cbf8b2e293dcaeddaca5d01088cbdff315dee234efecd430366fb82d0c74ac"


def materialize_external_labels(*, raw_path, frame_path, output_path,
        expected_frame_sha256, protocol_path, expected_protocol_sha256,
        label_access_authorized=False):
    _need(label_access_authorized is True, "Separate secondary protocol authorization required")
    _need(sha256(raw_path) == EXTERNAL_RELEASE_SHA256, "Pinned external source release changed")
    _need(sha256(frame_path) == expected_frame_sha256, "Secondary frame changed")
    _need(sha256(protocol_path) == expected_protocol_sha256, "Secondary protocol changed")
    output = Path(output_path)
    _need(not output.exists(), "Refuse to replace an existing external label ledger")
    cases = index_cases(_read_jsonl(frame_path))
    selected = {(str(case["matches_hash"]), str(case["source_hash"])): cid
                for cid, case in cases.items()}
    _need(len(selected) == len(cases), "Duplicate external source pairs")
    labels = {}
    for row in _read_jsonl(raw_path):
        pair = (str(row["matches_hash"]), str(row["source_hash"]))
        if pair not in selected:
            continue  # Excluded outcomes are neither inspected nor validated.
        cid = selected[pair]
        _need(cid not in labels, "Duplicate released canonical external pair")
        tags = row.get("all_tags")
        _need(isinstance(tags, list) and bool(tags), "Missing external curator tags")
        _need(all(isinstance(tag, str) and tag in CURATION_TAGS for tag in tags),
              "An external tag is outside the official vocabulary")
        # Exact upstream aggregate_gold over already filtered NON-PAIR tags.
        # One objection makes the extraction incorrect; no majority vote.
        correct = all(tag == "correct" for tag in tags)
        _need(row.get("gold") == ("correct" if correct else "incorrect"),
              "Released external aggregate disagrees with its non-pair tags")
        _need((row.get("tag") == "correct") == correct,
              "Released representative tag disagrees with external aggregate")
        labels[cid] = {"case_id": cid,
                       "gold": "supported" if correct else "unsupported",
                       "curator_tags": tags,
                       "matches_hash": pair[0], "source_hash": pair[1],
                       "statement_payload_sha256": cases[cid]["statement_payload_sha256"]}
    _need(set(labels) == set(cases), "Selected external labels are incomplete")
    output.write_text("".join(json.dumps(labels[cid], sort_keys=True) + "\n"
                              for cid in cases))
    return {"pairs": len(labels), "labels_sha256": sha256(output),
            "frame_sha256": expected_frame_sha256,
            "protocol_sha256": expected_protocol_sha256,
            "tag_rule": "Any-incorrect-wins on released non-original-pair curator tags; no majority vote.",
            "reference_scope": "Selected human-curator sentence/claim annotations. Curator expertise and independent adjudication are not assumed."}
