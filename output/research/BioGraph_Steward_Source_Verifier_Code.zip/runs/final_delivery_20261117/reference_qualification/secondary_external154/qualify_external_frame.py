"""Label-blind native qualification of the optional external curator frame."""
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

import simplejson
from indra.statements import stmts_from_json

OUT = Path(__file__).resolve().parent
QUAL = OUT.parent
ROOT = QUAL.parents[2]
UPSTREAM = ROOT / "runs/final_delivery_20261117/method_qualification/adapter/upstream"
PRIOR = ROOT / "runs/indra_claim_qualification_20261113/data_capture/blind_join"
VERSION = "v2"
sys.path.insert(0, str(UPSTREAM / "src"))


def digest(value):
    return hashlib.sha256(simplejson.dumps(value, sort_keys=True,
        separators=(",", ":"), ensure_ascii=False, use_decimal=True,
        allow_nan=False).encode()).hexdigest()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_jsonl(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line]


def case_id(row):
    return "indra-pair:" + str(row["matches_hash"]) + ":" + str(row["source_hash"])


def family(statement):
    st = stmts_from_json([statement], on_missing_support="ignore")[0]
    return "native_entity_type_family:" + digest({"type": statement["type"],
        "entity_keys": [a.entity_matches_key() if a is not None else None
                        for a in st.agent_list(deep_sorted=True)]})


def tokens(row, family_token=None):
    result = {"claim:" + str(row["matches_hash"]), "source:" + str(row["source_hash"])}
    pmid = str(row.get("pmid") or "").strip()
    if pmid.isdecimal() and int(pmid) > 0:
        result.add("PMID:" + pmid)
    if family_token:
        result.add(family_token)
    return result


def load_guard():
    spec = importlib.util.spec_from_file_location("check_contamination",
        QUAL / "official_source/scripts/check_contamination.py")
    cc = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = cc
    spec.loader.exec_module(cc)
    cc.ROOT = UPSTREAM
    spec = importlib.util.spec_from_file_location("indra_belief.curation",
        QUAL / "official_source/src/indra_belief/curation.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    spec = importlib.util.spec_from_file_location("author_external_guard",
        QUAL / "official_source/scripts/build_curation_eval.py")
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    return cc, builder


def run():
    raw_path = QUAL / "private_original/external_gold_v1.jsonl"
    raw = read_jsonl(raw_path)
    before = json.loads((OUT / "pre_recovery_admission_ledger.json").read_text())
    assert len(raw) == len(before) == 154
    prior = json.loads((PRIOR / "pair_join_inventory.json").read_text())["pairs"]
    forbidden = {"claim:" + str(row["pa_hash"]) for row in prior}
    forbidden |= {"source:" + str(row["source_hash"]) for row in prior}
    forbidden |= {"PMID:" + x for x in json.loads((PRIOR /
        "source_publication_ids.json").read_text())["all_explicit_PMIDs"]}
    forbidden |= {token for row in prior for token in row["candidate_exposure_group_tokens"]
                  if token.startswith("native_entity_type_family:")}
    primary = read_jsonl(QUAL / "source_pairs_v1.jsonl")
    for row in primary:
        forbidden |= tokens({**row, "pmid": row["evidence"]["pmid"]},
                            row["native_entity_type_family"])
    metadata = json.loads((QUAL / "metadata_label_exposure_exclusions.json").read_text())
    exposed = {(str(row["matches_hash"]), str(row["source_hash"])) for row in metadata["pairs"]}
    for row in read_jsonl(QUAL / "private_original/representative_indra_curations_400.jsonl"):
        if (str(row["matches_hash"]), str(row["source_hash"])) in exposed:
            forbidden |= tokens(row, family(row["statement"]))
    cc, builder = load_guard()
    examples = cc.load_all_examples()
    assert len(examples) == 56
    example_pairs, example_texts = builder.fewshot_filters()
    all_tokens, records, reasons, probes = {}, {}, {}, {}
    native_shapes = Counter()
    for index, row in enumerate(raw):
        cid = case_id(row)
        reasons[cid] = list(before[index]["reasons"])
        path = OUT / "native_by_hash" / (str(row["matches_hash"]) + ".json")
        if not path.exists():
            all_tokens[cid] = tokens(row)
            if before[index]["eligible_for_native_recovery"]:
                reasons[cid].append("native_recovery_unavailable")
            continue
        statement = json.loads(path.read_text())
        st = stmts_from_json([statement], on_missing_support="ignore")[0]
        assert str(st.get_hash(refresh=True)) == str(row["matches_hash"])
        assert st.__class__.__name__ == row["stmt_type"]
        fam = family(statement)
        all_tokens[cid] = tokens(row, fam)
        if all_tokens[cid] & forbidden:
            reasons[cid].append("prior_primary_or_exposed_connected_identity")
        agents = st.agent_list()
        probe = {"case_id": cid, "evidence_text": row["evidence_text"],
                 "subject": agents[0].name if agents and agents[0] is not None else "?",
                 "object": agents[1].name if len(agents) > 1 and agents[1] is not None else "?"}
        probes[cid] = probe
        if builder.is_contaminated(probe, example_pairs, example_texts):
            reasons[cid].append("author_fewshot_universe_overlap")
        pmid = str(row.get("pmid") or "").strip()
        if not isinstance(row.get("evidence_text"), str) or not row["evidence_text"].strip():
            reasons[cid].append("missing_evidence_text")
        records[cid] = {"case_id": cid, "original_row_index": index,
            "matches_hash": str(row["matches_hash"]), "source_hash": str(row["source_hash"]),
            "statement": statement, "statement_payload_sha256": digest(statement),
            "evidence": {"text": row["evidence_text"], "source_api": row.get("source_api"),
                         "pmid": pmid, "original_source_hash": str(row["source_hash"])},
            "native_entity_type_family": fam,
            "native_statement_source": "Public INDRA curation/list exact matches_hash pa_json",
            "native_evidence_annotations_available": False,
            "native_evidence_epistemics_available": False, "raw_source_id_available": False,
            "source_hash_must_not_be_regenerated_as_original_identity": True,
            "published_row_statement_fields_preserved": False,
            "recovered_full_native_statement_fields_preserved": True}
        for agent in st.agent_list(deep_sorted=True):
            if agent is None:
                continue
            native_shapes["agents"] += 1
            native_shapes["agents_with_nonTEXT_grounding"] += bool(set(agent.db_refs or {}) - {"TEXT", "TEXT_NORM"})
            native_shapes["agents_with_conditions"] += any(bool(getattr(agent, k, None)) for k in
                ("mods", "mutations", "activity", "bound_conditions", "location"))
        native_shapes["complex_with_more_than_two_members"] += statement.get("type") == "Complex" and len(statement.get("members", [])) > 2
        native_shapes["statements_with_site"] += bool(statement.get("position") or statement.get("residue"))
    # Leakage seeds close over every recovered/available pair's publication,
    # source, native claim and exact entity/type family. Missing-source quality
    # failures do not by themselves assert exposure of other source sentences.
    leakage = {cid for cid, why in reasons.items() if any(
        word in reason for reason in why for word in ("prior_", "primary_", "metadata_", "fewshot_"))}
    seed_count = len(leakage)
    while True:
        exposure_tokens = set().union(*(all_tokens[cid] for cid in leakage)) if leakage else set()
        extra = {cid for cid, value in all_tokens.items() if value & exposure_tokens} - leakage
        if not extra:
            break
        for cid in extra:
            reasons[cid].append("exposure_connected_group_closure")
        leakage |= extra
    retained = [records[case_id(row)] for row in raw
                if case_id(row) in records and not reasons[case_id(row)]]
    frame = OUT / ("external_source_pairs_" + VERSION + ".jsonl")
    assert not frame.exists(), "Refuse to overwrite an existing secondary frame"
    frame.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in retained))
    probe_path = OUT / "external_guard_input_label_free.jsonl"
    probe_path.write_text("".join(json.dumps(probes[row["case_id"]], sort_keys=True) + "\n" for row in retained))
    assert cc.find_contamination(examples=examples, eval_paths=[probe_path]) == []
    # The optional frame is disjoint from primary/prior/exposed source groups.
    assert not any(all_tokens[row["case_id"]] & forbidden for row in retained)
    parent = {row["case_id"]: row["case_id"] for row in retained}

    def find(cid):
        while parent[cid] != cid:
            parent[cid] = parent[parent[cid]]
            cid = parent[cid]
        return cid

    seen = {}
    for row in retained:
        cid = row["case_id"]
        for token in all_tokens[cid]:
            if token in seen:
                parent[find(cid)] = find(seen[token])
            else:
                seen[token] = cid
    groups = Counter(find(row["case_id"]) for row in retained)
    membership = OUT / ("external_group_membership_" + VERSION + ".jsonl")
    membership.write_text("".join(json.dumps({"case_id": row["case_id"],
        "group_id": "external-group:" + hashlib.sha256(find(row["case_id"]).encode()).hexdigest()[:24]},
        sort_keys=True) + "\n" for row in retained))
    ledger = OUT / ("external_admission_ledger_" + VERSION + ".json")
    ledger.write_text(json.dumps([{"case_id": case_id(row), "reasons": reasons[case_id(row)],
        "admitted": not reasons[case_id(row)] and case_id(row) in records} for row in raw],
        indent=2, sort_keys=True) + "\n")
    summary = {"status": "secondary_native_frame_ready_pending_root_protocol",
        "raw_reference_pairs": len(raw), "pairs_native_recovered": len(records),
        "pairs_admitted": len(retained), "labels_indexed": False,
        "predictions_opened": False, "method_expressiveness_filter": False,
        "source_case_sha256": sha(frame), "source_case_bytes": frame.stat().st_size,
        "source_case_path": str(frame.relative_to(ROOT)),
        "original_release_sha256": sha(raw_path),
        "source_type_counts": dict(Counter(row["statement"]["type"] for row in retained)),
        "native_shape_counts_before_exposure_exclusion": dict(native_shapes),
        "exclusion_reasons_nonexclusive": dict(Counter(r for why in reasons.values() for r in why)),
        "exposure_seed_pairs": seed_count, "exposure_closure_pairs": len(leakage),
        "groups": len(groups), "group_size_counts": dict(Counter(groups.values())),
        "group_membership_sha256": sha(membership),
        "author_examples_checked": len(examples),
        "author_examples_identifier_limit": "Released examples provide claim, evidence and source-bank name, not PMID or original statement/source hashes. Text/name matches seed whole available source-group exclusion; unavailable identifiers are not invented.",
        "endpoint": "Optional secondary strict per-pair external-curator reference; forced-balanced source selection, not prevalence. Not used to tune the primary comparison.",
        "source_completeness": "Complete native pa_json claim recovered from the author public route; original full Evidence metadata remains unavailable and the released sentence/source_api/pmid fields are used identically for both arms.",
        "terms": "Raw cases remain private; no explicit dataset-specific redistribution grant located."}
    (OUT / ("external_source_pairs_" + VERSION + ".manifest.json")).write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    return summary


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
