"""Bounded label-blind use of the author's public per-hash recovery route.

The upstream external_gold_to_statements_grounded.py specifies this endpoint
and pa_json field. Unlike upstream fetch_curations, HTTP 4xx is explicitly a
failed recovery. Response files remain private and no curator tag is indexed.
"""
import asyncio
from collections import Counter
import hashlib
import json
from pathlib import Path
import time

import requests
from indra.statements import stmts_from_json

OUT = Path(__file__).resolve().parent
STRIP = {"belief", "evidence", "id", "supported_by", "supports"}


def sha(value):
    return hashlib.sha256(value).hexdigest()


async def run(limit=0):
    candidates = json.loads((OUT / "pre_recovery_candidates.json").read_text())
    hashes = sorted({row["matches_hash"] for row in candidates})
    if limit:
        hashes = hashes[:limit]
    (OUT / "private_http").mkdir(exist_ok=True)
    (OUT / "native_by_hash").mkdir(exist_ok=True)
    results = []
    sem = asyncio.Semaphore(8)

    async def one(client, mh):
        path = OUT / "private_http" / (mh + ".json")
        body = None
        record = {"matches_hash": mh, "http_status": None,
                  "recovered_native": False, "labels_indexed": False}
        async with sem:
            if path.exists():
                body = path.read_bytes()
                record["http_status"] = 200
                record["cache_reused"] = True
            else:
                for attempt in range(3):
                    try:
                        response = await asyncio.to_thread(requests.get,
                            "https://db.indra.bio/curation/list/" + mh, timeout=20,
                            headers={"User-Agent": "biograph-steward-reference-qualification/1"})
                        record["http_status"] = response.status_code
                        if response.status_code == 200:
                            body = response.content
                            path.write_bytes(body)
                            break
                        if 400 <= response.status_code < 500:
                            record["failure"] = "explicit_http_client_error"
                            break
                    except requests.RequestException as exc:
                        record["failure"] = exc.__class__.__name__
                    if attempt < 2:
                        await asyncio.sleep(.5 * 2 ** attempt)
            if body is None:
                results.append(record)
                return
            record["response_bytes"] = len(body)
            record["response_sha256"] = sha(body)
            payload = json.loads(body)
            record["response_type"] = type(payload).__name__
            if not isinstance(payload, list):
                record["failure"] = "unexpected_response_shape"
                results.append(record)
                return
            native = []
            for curation in payload:
                # Deliberately do not access tag, gold, comments or curator.
                if not isinstance(curation, dict):
                    continue
                pa = curation.get("pa_json")
                if isinstance(pa, str):
                    pa = json.loads(pa)
                if not isinstance(pa, dict):
                    continue
                try:
                    statement = stmts_from_json([pa], on_missing_support="ignore")[0]
                    if str(statement.get_hash(refresh=True)) != mh:
                        continue
                except Exception:
                    continue
                clean = {k: v for k, v in pa.items() if k not in STRIP}
                native.append(clean)
            record["native_candidates"] = len(native)
            if not native:
                record["failure"] = "no_exact_native_pa_json"
            else:
                keys = {json.dumps(x, sort_keys=True, ensure_ascii=False,
                                  separators=(",", ":")) for x in native}
                record["distinct_full_native_claim_payloads"] = len(keys)
                if len(keys) != 1:
                    record["failure"] = "conflicting_full_native_pa_json"
                else:
                    data = (next(iter(keys)) + "\n").encode()
                    (OUT / "native_by_hash" / (mh + ".json")).write_bytes(data)
                    record["native_sha256"] = sha(data)
                    record["recovered_native"] = True
            results.append(record)

    await asyncio.gather(*(one(None, mh) for mh in hashes))
    results.sort(key=lambda x: x["matches_hash"])
    report = {"endpoint": "https://db.indra.bio/curation/list/<matches_hash>",
              "started_at_unix": started, "elapsed_seconds": time.time() - started,
              "hashes_requested": len(hashes),
              "hashes_recovered": sum(row["recovered_native"] for row in results),
              "http_status_counts": dict(Counter(row["http_status"] for row in results)),
              "failure_counts": dict(Counter(row.get("failure") for row in results
                                              if not row["recovered_native"])),
              "labels_indexed": False, "results": results}
    (OUT / ("recovery_probe.json" if limit else "recovery_report.json")).write_text(
        json.dumps(report, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "results"}, indent=2))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=0)
    args = parser.parse_args()
    started = time.time()
    asyncio.run(run(args.limit))
