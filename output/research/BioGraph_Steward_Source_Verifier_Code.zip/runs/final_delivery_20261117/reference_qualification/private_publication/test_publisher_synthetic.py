"""Aggregate privacy and adverse-control fixtures using invented data only."""
from copy import deepcopy
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent))
import combined_score as score
import pair_reference_tools as metric
import publish_aggregate as publisher


def fixture():
    gold={"PRIVATE_CASE_A":"supported","PRIVATE_CASE_B":"supported",
          "PRIVATE_CASE_C":"unsupported","PRIVATE_CASE_D":"unsupported"}
    groups={cid:"PRIVATE_GROUP_"+cid for cid in gold}
    frames,protocols,pre={}, {}, {}
    for name in publisher.FRAMES:
        predictions={"retain_all":dict.fromkeys(gold,"support"),
            "base":{cid:"support" if g=="supported" else "reject" for cid,g in gold.items()},
            "disconfirm":dict.fromkeys(gold,"reject" if name=="primary" else "abstain")}
        frames[name]={"metrics":{arm:metric.metrics(gold,d) for arm,d in predictions.items()},
            "paired_group_bootstrap":metric.paired_group_bootstrap(gold,predictions,groups,score.COMPARISONS),
            "review_policy_appendix":score.agreement_reject_only(gold,predictions),
            "private_model_response":"NEVER_PUBLISH_RESPONSE"}
        pre[name]={"pairs":4,"groups":4,"cases_sha256":"a"*64,"groups_sha256":"b"*64,
            "raw_reference_sha256":"c"*64,"case_ids":["PRIVATE_CASE_A"],
            "raw_reference_path_private":"/Users/SECRET/reference.jsonl","curator":"secret@example.invalid"}
        protocols[name]={"expected_case_count":4,"parameters":{
            "model_id":"nvidia/Llama-3.1-Nemotron-Nano-8B-v1","model_revision":publisher.MODEL_REVISION,
            "temperature":.1,"max_output_tokens":1024},"source_cases":{"sha256":"a"*64},
            **{key:{"sha256":"d"*64,"path":"/Users/SECRET/"+key}
               for key in ("adapter","runner","upstream_manifest","readiness")}}
    report={"format":"biograph-steward.released-sentence-native-claim-comparison.v1",
        "all_frame_denominators_preserved":True,"thresholds_or_prompts_fit":False,"graph_changed":False,
        "metric_helper_sha256":publisher.METRIC_HELPER_SHA,"external_label_helper_sha256":publisher.EXTERNAL_HELPER_SHA,
        "frames":frames,"preflight":{"all_four_prediction_envelopes_verified":True,
            "both_completion_receipts_verified":True,"frames":pre},
        "protocols_sha256":dict.fromkeys(publisher.FRAMES,"e"*64),
        "raw_label":"NEVER_PUBLISH_GOLD","evidence_text":"NEVER_PUBLISH_PASSAGE"}
    report["content_sha256"]=publisher.digest(report)
    return report,protocols


def run():
    report,protocols=fixture()
    aggregate=publisher.make_aggregate(report,protocols,assessment_sha256="f"*64,master_sha256="1"*64)
    note=publisher.render_note(aggregate);html=publisher.render_html(aggregate)
    combined=json.dumps(aggregate)+note+html
    for private in ("PRIVATE_CASE_","PRIVATE_GROUP_","/Users/SECRET","secret@example.invalid",
                    "NEVER_PUBLISH_RESPONSE","NEVER_PUBLISH_GOLD","NEVER_PUBLISH_PASSAGE"):
        assert private not in combined, private
    for name in publisher.FRAMES:
        assert set(aggregate["frames"][name]["methods"])==set(publisher.ARMS)
        assert aggregate["frames"][name]["methods"]["disconfirm"]["counts"]["pairs"]==4
    contrast=aggregate["frames"]["primary"]["uncertainty"]["comparisons"][0]
    assert contrast["difference"]==-.5 and contrast["percentile_95_interval"]==[-.5,-.5]
    assert aggregate["frames"]["primary"]["methods"]["disconfirm"]["false_exclusion_rate"]==1
    assert aggregate["frames"]["secondary"]["methods"]["disconfirm"]["coverage"]==0
    bad=deepcopy(report);bad["frames"]["primary"]["metrics"].pop("base");bad.pop("content_sha256");bad["content_sha256"]=publisher.digest(bad)
    try:publisher.make_aggregate(bad,protocols,assessment_sha256="f"*64,master_sha256="1"*64)
    except ValueError:pass
    else:raise AssertionError("Missing adverse control accepted")
    bad=deepcopy(report);bad["frames"]["primary"]["metrics"]["disconfirm"]["false_exclusion_rate"]=0
    bad.pop("content_sha256");bad["content_sha256"]=publisher.digest(bad)
    try:publisher.make_aggregate(bad,protocols,assessment_sha256="f"*64,master_sha256="1"*64)
    except ValueError:pass
    else:raise AssertionError("Suppressed false exclusions accepted")
    try:publisher.publish_completed(assessment_path=Path("DO_NOT_OPEN"),protocol_paths={},master_path="DO_NOT_OPEN",output_dir="DO_NOT_CREATE")
    except ValueError:pass
    else:raise AssertionError("Missing parent publication GO accepted")
    preview=HERE/"synthetic_preview"
    preview.mkdir(exist_ok=True)
    (preview/"aggregate.json").write_text(json.dumps(aggregate,indent=2,sort_keys=True)+"\n")
    (preview/"report.html").write_text(html)
    (preview/"note.md").write_text(note)
    receipt={"status":"passed","synthetic_only":True,"actual_reference_labels_or_predictions_opened":False,
        "private_fields_dropped":True,"all_arms_and_negative_contrasts_preserved":True,
        "false_exclusions_and_abstention_denominators_preserved":True,"missing_controls_rejected":True,
        "suppressed_adverse_metric_rejected":True,"root_GO_required_before_file_access":True,
        "publisher_sha256":publisher.sha(HERE/"publish_aggregate.py")}
    (HERE/"synthetic_fixture_receipt.json").write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
    return receipt


if __name__=="__main__":print(json.dumps(run(),indent=2,sort_keys=True))
