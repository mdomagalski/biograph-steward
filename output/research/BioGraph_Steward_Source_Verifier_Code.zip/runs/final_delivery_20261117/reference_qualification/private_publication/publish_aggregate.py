"""Allowlisted publication of the frozen source-verifier comparison.

Adapted from tools/mechanistic_review/publish.py: validate aggregate arithmetic,
retain every prespecified arm and contrast, and emit no individual records.
This module never performs inference, joins labels or changes a graph. The
file-writing entry point requires a parent completion/publication GO.
"""
from datetime import datetime, timezone
from html import escape
import hashlib
import json
import math
from pathlib import Path
import re

ARMS = ("retain_all", "base", "disconfirm")
FRAMES = ("primary", "secondary")
NAMES = {"retain_all": "Retain all", "base": "Official base", "disconfirm": "Official disconfirm"}
COUNTS = ("pairs", "supported", "unsupported", "support_supported", "support_unsupported",
    "reject_supported", "reject_unsupported", "abstain_supported", "abstain_unsupported",
    "support_decisions", "reject_decisions", "abstentions", "correct_explicit_decisions")
METRICS = ("balanced_accuracy_abstention_zero", "explicit_decision_accuracy", "coverage",
    "support_precision", "error_precision", "error_recall", "error_F1", "false_support_rate",
    "false_exclusion_rate", "retained_supported_fraction")
POLICY_COUNTS = ("pairs", "reference_supported", "reference_unsupported", "flagged",
    "flagged_reference_unsupported", "false_exclusions_reference_supported", "retained",
    "retained_reference_supported", "retained_reference_unsupported")
POLICY_METRICS = ("conditional_flag_precision", "unsupported_flag_recall", "supported_false_exclusion_fraction",
    "retain_all_reference_label_precision", "retained_reference_label_precision",
    "retained_reference_label_precision_change_vs_retain_all")
CONTRASTS = (("disconfirm", "base"), ("disconfirm", "retain_all"), ("base", "retain_all"))
METRIC_HELPER_SHA = "85524d12d0d7734ddaccefcecf04f8a2d6912bdf0c6a475467fcfc66b694a7c2"
EXTERNAL_HELPER_SHA = "ee8e14274147def89bd69ba77e4d0fe8a5f70d89ac4bea52d1bfe95c4dea6af4"
UPSTREAM = "74e0ffe9ea21f6f11e906cee89a2091f45be2f7d"
MODEL_REVISION = "54641c1611fcff44fa4865626462445e0a153fc7"
SOURCES = {
    "author_code": "https://github.com/gyorilab/indra-belief-model/tree/" + UPSTREAM,
    "reference_description": "https://github.com/gyorilab/indra-belief-model/blob/" + UPSTREAM + "/data/benchmark/README.md",
    "curation_guidelines": "https://indra.readthedocs.io/en/latest/tutorials/html_curation.html",
    "INDRA_2023_paper": "https://doi.org/10.15252/msb.202211325",
    "original_2023_corpus": "https://zenodo.org/records/7559353",
}


def need(value, message):
    if not value:
        raise ValueError("Aggregate publication: " + message)


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sealed(value):
    need(isinstance(value, dict) and value.get("content_sha256") == digest(
        {k: v for k, v in value.items() if k != "content_sha256"}), "assessment seal differs")


def hash_value(value):
    need(isinstance(value, str) and re.fullmatch("[0-9a-f]{64}", value), "invalid provenance hash")
    return value


def ratio(a, b):
    return a / b if b else None


def close(a, b):
    if a is None or b is None:
        return a is b
    return type(a) in (int,float) and type(b) in (int,float) and math.isfinite(a) and math.isfinite(b) and abs(a-b) < 1e-12


def metrics(row, n, supported, unsupported):
    c = row.get("counts", {})
    need(all(type(c.get(k)) is int and c[k] >= 0 for k in COUNTS), "method counts missing")
    need((c["pairs"], c["supported"], c["unsupported"]) == (n, supported, unsupported), "class denominators differ")
    for gold in ("supported", "unsupported"):
        need(sum(c[d + "_" + gold] for d in ("support", "reject", "abstain")) == c[gold], "class confusion counts differ")
    need(c["support_decisions"] == c["support_supported"] + c["support_unsupported"]
        and c["reject_decisions"] == c["reject_supported"] + c["reject_unsupported"]
        and c["abstentions"] == c["abstain_supported"] + c["abstain_unsupported"]
        and c["correct_explicit_decisions"] == c["support_supported"] + c["reject_unsupported"], "decision totals differ")
    a, b = ratio(c["support_supported"], supported), ratio(c["reject_unsupported"], unsupported)
    expected = {"balanced_accuracy_abstention_zero": (a+b)/2 if a is not None and b is not None else None,
        "explicit_decision_accuracy": ratio(c["correct_explicit_decisions"], n),
        "coverage": ratio(n-c["abstentions"], n),
        "support_precision": ratio(c["support_supported"], c["support_decisions"]),
        "error_precision": ratio(c["reject_unsupported"], c["reject_decisions"]),
        "error_recall": b,
        "error_F1": ratio(2*c["reject_unsupported"], c["reject_unsupported"]+c["reject_supported"]+unsupported),
        "false_support_rate": ratio(c["support_unsupported"], unsupported),
        "false_exclusion_rate": ratio(c["reject_supported"], supported),
        "retained_supported_fraction": ratio(supported-c["reject_supported"], n-c["reject_decisions"])}
    need(row.get("abstentions_receive_zero_primary_credit") is True, "abstention policy differs")
    need(all(close(row.get(k), v) for k, v in expected.items()), "metrics differ from counts")
    return {"counts": {k:c[k] for k in COUNTS}, **expected}


def interval(value, lower, upper):
    need(isinstance(value, list) and len(value) == 2 and all(type(x) in (int,float)
        and math.isfinite(x) and lower <= x <= upper for x in value) and value[0] <= value[1], "invalid interval")
    return list(value)


def uncertainty(value, methods, groups):
    need(value.get("metric") == "balanced_accuracy_abstention_zero" and value.get("draws") == 10000
        and value.get("seed") == 20261117 and value.get("groups") == groups
        and value.get("same_group_multiplicities_across_methods") is True, "bootstrap protocol differs")
    undefined = value.get("undefined_draws")
    need(type(undefined) is int and 0 <= undefined <= 10000, "bootstrap draw counts differ")
    need(set(value.get("arms", {})) == set(ARMS), "an arm interval is missing")
    arms = {}
    for name in ARMS:
        row = value["arms"][name]
        need(close(row.get("point"), methods[name]["balanced_accuracy_abstention_zero"]), "arm bootstrap point differs")
        arms[name] = {"point": row["point"], "percentile_95_interval": interval(row.get("percentile_95_interval"), 0, 1)}
    comparisons, seen = [], set()
    for row in value.get("comparisons", []):
        key = row.get("candidate"), row.get("comparator")
        need(key in CONTRASTS and key not in seen, "unknown or duplicated contrast")
        seen.add(key)
        point = methods[key[0]]["balanced_accuracy_abstention_zero"] - methods[key[1]]["balanced_accuracy_abstention_zero"]
        need(close(row.get("difference"), point) and row.get("defined_draws") == 10000-undefined, "contrast point/draw count differs")
        comparisons.append({"candidate":key[0], "comparator":key[1], "difference":point,
            "percentile_95_interval":interval(row.get("percentile_95_interval"),-1,1), "defined_draws":10000-undefined})
    need(seen == set(CONTRASTS), "a prespecified contrast is missing")
    return {"draws":10000,"seed":20261117,"groups":groups,"undefined_draws":undefined,
        "method":"paired_connected_source_group_percentile_bootstrap",
        "sample_multiplicities_sha256":hash_value(value.get("sample_multiplicities_sha256")),
        "arms":arms,"comparisons":comparisons,
        "scope":"Pointwise paired source-group percentile intervals, conditional on this selected reference. Not simultaneous intervals or biological replication."}


def policy(value, n, supported, unsupported):
    need(value.get("policy_id") == "agreement_reject_only", "review policy differs")
    need(all(type(value.get(k)) is int and value[k] >= 0 for k in POLICY_COUNTS), "review policy counts missing")
    need((value["pairs"],value["reference_supported"],value["reference_unsupported"]) == (n,supported,unsupported), "review policy frame differs")
    tp, fp, flagged = value["flagged_reference_unsupported"], value["false_exclusions_reference_supported"], value["flagged"]
    need(tp <= unsupported and fp <= supported and flagged == tp+fp
        and value["retained"] == n-flagged and value["retained_reference_supported"] == supported-fp
        and value["retained_reference_unsupported"] == unsupported-tp, "review policy confusion differs")
    before, after = ratio(supported,n), ratio(supported-fp,n-flagged)
    expected = {"conditional_flag_precision":ratio(tp,flagged), "unsupported_flag_recall":ratio(tp,unsupported),
        "supported_false_exclusion_fraction":ratio(fp,supported), "retain_all_reference_label_precision":before,
        "retained_reference_label_precision":after,
        "retained_reference_label_precision_change_vs_retain_all":after-before if after is not None else None}
    need(all(close(value.get(k),v) for k,v in expected.items()), "review policy metrics differ")
    need(value.get("unflagged_cases_are_not_model_supported") is True and value.get("same_model_correlated_votes") is True
        and value.get("automatic_graph_pruning") is False, "review-policy interpretation differs")
    return {"policy_id":"agreement_reject_only",**{k:value[k] for k in POLICY_COUNTS},**expected,
        "meaning":"Both arms reject: flag for review. Otherwise retain and leave unassessed. The same model supplies correlated judgments; these are not independent votes."}


def make_aggregate(report, protocols, *, assessment_sha256, master_sha256):
    sealed(report)
    need(report.get("format") == "biograph-steward.released-sentence-native-claim-comparison.v1"
        and report.get("all_frame_denominators_preserved") is True
        and report.get("thresholds_or_prompts_fit") is False and report.get("graph_changed") is False, "assessment scope differs")
    need(report.get("metric_helper_sha256") == METRIC_HELPER_SHA and report.get("external_label_helper_sha256") == EXTERNAL_HELPER_SHA,
        "frozen scoring implementation differs")
    need(set(report.get("frames",{})) == set(FRAMES) and set(protocols) == set(FRAMES), "both frames required")
    pre = report.get("preflight",{})
    need(pre.get("all_four_prediction_envelopes_verified") is True and pre.get("both_completion_receipts_verified") is True,
        "all completed sealed outputs are required")
    frames, public_protocols = {}, {}
    for name in FRAMES:
        row, f, protocol = report["frames"][name], pre["frames"][name], protocols[name]
        n, groups = f.get("pairs"), f.get("groups")
        need(type(n) is int and type(groups) is int and 0 < groups <= n, "frame counts invalid")
        need(set(row.get("metrics",{})) == set(ARMS), "all three arms required")
        counts = row["metrics"]["retain_all"]["counts"]
        supported, unsupported = counts.get("supported"),counts.get("unsupported")
        need(type(supported) is int and type(unsupported) is int and supported+unsupported == n, "reference class counts invalid")
        methods = {arm:metrics(row["metrics"][arm],n,supported,unsupported) for arm in ARMS}
        need(methods["retain_all"]["counts"]["support_decisions"] == n, "retain-all control modified")
        frames[name] = {"pairs":n,"connected_source_groups":groups,"reference_supported":supported,"reference_unsupported":unsupported,
            "methods":methods,"uncertainty":uncertainty(row["paired_group_bootstrap"],methods,groups),
            "agreement_review_policy":policy(row["review_policy_appendix"],n,supported,unsupported)}
        params = protocol.get("parameters",{})
        need(protocol.get("expected_case_count") == n and params.get("model_id") == "nvidia/Llama-3.1-Nemotron-Nano-8B-v1"
            and params.get("model_revision") == MODEL_REVISION and params.get("temperature") == .1
            and params.get("max_output_tokens") == 1024, "published method metadata differs")
        need(protocol["source_cases"]["sha256"] == f["cases_sha256"], "protocol frame pin differs")
        public_protocols[name] = {"protocol_sha256":hash_value(report["protocols_sha256"][name]),
            "source_frame_sha256":hash_value(f["cases_sha256"]), "source_release_sha256":hash_value(f["raw_reference_sha256"]),
            "groups_file_sha256":hash_value(f["groups_sha256"]),
            "adapter_sha256":hash_value(protocol["adapter"]["sha256"]),"runner_sha256":hash_value(protocol["runner"]["sha256"]),
            "upstream_manifest_sha256":hash_value(protocol["upstream_manifest"]["sha256"]),
            "runtime_readiness_sha256":hash_value(protocol["readiness"]["sha256"])}
    result = {"format":"biograph-steward.source-verifier-public-aggregate.v1","title":"Source-verifier comparison",
        "created_at":datetime.now(timezone.utc).isoformat(),"primary_hypothesis":"Official disconfirm improves explicit-decision balanced accuracy over official base on the primary frame; the same contrast is assessed separately on the external-curator frame.",
        "frames":frames,"public_protocols":public_protocols,
        "method":{"author_commit":UPSTREAM,"arms":list(ARMS),"model":"nvidia/Llama-3.1-Nemotron-Nano-8B-v1",
            "model_revision":MODEL_REVISION,"INDRA":"1.24.0","Gilda":"1.6.1","vLLM":"0.8.5",
            "temperature":.1,"max_output_tokens":1024,"context_tokens":16384,
            "examples_per_request":14,"author_example_universe_checked":56,
            "wire":"Unchanged author policy prefixed to the first example user message; all example content and order preserved.",
            "categorical_uncalibrated":True,"RF_calibration_used":False,"direct_binding_postfilter_used":False,
            "ordering_and_bootstrap_seed":20261117,"seed_is_not_an_inference_payload_parameter":True,
            "grounding_resource_sha256":{"grounding_terms.tsv.gz":"b53169c4735d049c0443ab04830b26372dcfeba47845c1fe97392b64f08f2bb8",
                "gilda_models.json.gz":"62c888eeabe4afb484d17d90cf3e8304c9c3a8f1c97b5b3fb7ab41a458340e1f"}},
        "definitions":{"supported":"The supplied source passage supports the native claim under that frame's released curator rule.",
            "primary_gold":"Only correct is supported, using the first qualifying submission per exact source pair. Later votes are not aggregated.",
            "secondary_gold":"Any incorrect non-original-pair curator tag makes the pair unsupported. No majority vote.",
            "balanced_accuracy":"Mean of correct explicit support/class-supported and correct explicit rejection/class-unsupported. Abstentions receive zero credit and stay in both class denominators.",
            "coverage":"Explicit support or rejection divided by all admitted pairs.",
            "false_support":"Explicit support of a curator-unsupported pair; denominator is every unsupported pair.",
            "false_exclusion":"Explicit rejection of a curator-supported pair; denominator is every supported pair.",
            "complex":"Uses native INDRA complex/co-complex semantics. Direct physical binding is not required or inferred."},
        "scope":["This is an evaluation-only comparison, not a deployed app feature. Zero current application source assertions have qualified native inputs for this verifier; it does not automatically prune Pharos or change the application graph.",
            "The primary reference is a selected completed curation snapshot with unproven sampling randomness. The external source forced class balance. Neither estimates population prevalence or whole-graph biological accuracy.",
            "The two frames use different released label policies and are reported separately. Human annotators are not all assumed to be independently adjudicated experts.",
            "The native claim preserves available conditions, sites and all complex members. Original Evidence annotations, epistemics and raw spans are unavailable; both arms receive the same released sentence and available source metadata.",
            "Prior project source/publication/claim/native-family exposure and the author example universe were screened where identifiers were available. Unknown model pretraining and exhaustive biological-family independence are not established.",
            "The same language model supplies both judgments. Agreement-only flags are conservative review proposals, not independent evidence or automatic biological pruning.",
            "The 2026 author method/reference artifacts are public releases, not a newly verified peer-reviewed method paper. The task builds on published INDRA source curation and the 2023 assembly work."],
        "attribution":{"sources":SOURCES,"code":"Author package declares MIT; native INDRA uses its own license. This does not relicense source records or article passages.",
            "data":"Original 2023 Zenodo corpus specifies CC-BY-NC-SA 4.0. No separate redistribution grant was located for the newer 2026 references; raw cases and labels remain private.",
            "publication":"Aggregate metrics, provenance hashes and public source links only."},
        "provenance":{"master_experiment_sha256":hash_value(master_sha256),"private_assessment_file_sha256":hash_value(assessment_sha256),
            "private_assessment_content_sha256":hash_value(report["content_sha256"]),"metric_helper_sha256":METRIC_HELPER_SHA,
            "external_label_helper_sha256":EXTERNAL_HELPER_SHA},
        "privacy":{"aggregate_only":True,"individual_identifiers_or_passages":False,"raw_labels_or_model_responses":False,"local_paths_or_credentials":False}}
    result["content_sha256"] = digest(result)
    return result


def pct(value):
    return "—" if value is None else f"{100*value:.1f}%"


def pp(value):
    return "—" if value is None else f"{100*value:+.1f} pp"


def render_note(a):
    lines = ["# Source-verifier comparison", "", a["primary_hypothesis"], ""]
    for frame in FRAMES:
        f = a["frames"][frame]
        lines += ["## " + ("Primary reference" if frame == "primary" else "External-curator reference"), "",
            f"{f['pairs']} pairs in {f['connected_source_groups']} connected source groups: {f['reference_supported']} supported and {f['reference_unsupported']} unsupported under the released curator rule.", "",
            "| Method | Balanced accuracy (95% interval) | Coverage | False support | False exclusion | Error precision | Error recall | Error F1 |", "|---|---:|---:|---:|---:|---:|---:|---:|"]
        for arm in ARMS:
            m=f["methods"][arm]; ci=f["uncertainty"]["arms"][arm]["percentile_95_interval"]
            lines.append("| " + " | ".join([NAMES[arm],pct(m["balanced_accuracy_abstention_zero"])+f" ({pct(ci[0])}–{pct(ci[1])})"] +
                [pct(m[k]) for k in ("coverage","false_support_rate","false_exclusion_rate","error_precision","error_recall","error_F1")]) + " |")
        lines += ["", "All class denominators include abstentions. An undefined precision is shown as —.", "",
            "| Prespecified contrast | Difference | Pointwise 95% interval |", "|---|---:|---:|"]
        for r in f["uncertainty"]["comparisons"]:
            ci=r["percentile_95_interval"]
            lines.append(f"| {NAMES[r['candidate']]} − {NAMES[r['comparator']]} | {pp(r['difference'])} | {pp(ci[0])} to {pp(ci[1])} |")
        p=f["agreement_review_policy"]
        lines += ["", f"Agreement-only review flags: {p['flagged']} pairs, including {p['flagged_reference_unsupported']} curator-unsupported pairs and {p['false_exclusions_reference_supported']} supported pairs. Flag precision: {pct(p['conditional_flag_precision'])}. Retained label precision: {pct(p['retained_reference_label_precision'])}, versus {pct(p['retain_all_reference_label_precision'])} for retaining all. Unflagged pairs remain unassessed.", ""]
    lines += ["## Interpretation and reproducibility", "", *["- "+s for s in a["scope"]], "",
        "The full aggregate JSON preserves all three arms, confusion counts, denominators, uncertainty and source/method hashes. Both frames and every completed prediction envelope were sealed before labels were accessed. No prompt, threshold or calibration was fitted to these outcomes.", "",
        "To reproduce: retrieve the pinned author source and reference versions, apply the recorded source/exposure admission rules, run the frozen base/disconfirm profiles on the same native claim and released evidence fields, then use the frozen scorer. Access to original data remains subject to its source terms. Individual cases and passages are not redistributed here.", "",
        "[Author implementation]("+SOURCES["author_code"]+") · [Reference descriptions]("+SOURCES["reference_description"]+") · [INDRA curation guidelines]("+SOURCES["curation_guidelines"]+") · [INDRA 2023]("+SOURCES["INDRA_2023_paper"]+")", ""]
    return "\n".join(lines)


def render_html(a):
    def table(headers, rows):
        return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+escape(str(x))+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
    sections=[]
    for name in FRAMES:
        f=a['frames'][name];rows=[];counts=[];contrasts=[]
        for arm in ARMS:
            m=f['methods'][arm];c=m['counts'];ci=f['uncertainty']['arms'][arm]['percentile_95_interval']
            rows.append([NAMES[arm],pct(m['balanced_accuracy_abstention_zero'])+f" ({pct(ci[0])}–{pct(ci[1])})"]+
                [pct(m[k]) for k in ('coverage','false_support_rate','false_exclusion_rate','error_precision','error_recall','error_F1')])
            counts.append([NAMES[arm]]+[c[k] for k in ('support_supported','support_unsupported','reject_supported','reject_unsupported','abstain_supported','abstain_unsupported')])
        for r in f['uncertainty']['comparisons']:
            ci=r['percentile_95_interval'];contrasts.append([NAMES[r['candidate']]+' − '+NAMES[r['comparator']],pp(r['difference']),pp(ci[0])+' to '+pp(ci[1])])
        p=f['agreement_review_policy']
        sections.append('<section><h2>'+('Primary reference' if name=='primary' else 'External-curator reference')+'</h2><p>'+escape(f"{f['pairs']} pairs in {f['connected_source_groups']} source groups. Curator labels: {f['reference_supported']} supported and {f['reference_unsupported']} unsupported.")+'</p>'+
            table(['Method','Balanced accuracy (95% interval)','Coverage','False support','False exclusion','Error precision','Error recall','Error F1'],rows)+
            '<p class="muted">All class denominators include abstentions. — means the precision is undefined.</p><h3>Full confusion counts</h3>'+
            table(['Method','Support / correct','Support / incorrect','Reject / correct','Reject / incorrect','Abstain / correct','Abstain / incorrect'],counts)+
            '<h3>Prespecified contrasts</h3>'+table(['Contrast','Difference','Pointwise 95% interval'],contrasts)+
            '<h3>Agreement-only review policy</h3><p>'+escape(f"{p['flagged']} flags: {p['flagged_reference_unsupported']} curator-unsupported pairs and {p['false_exclusions_reference_supported']} supported pairs. Conditional flag precision {pct(p['conditional_flag_precision'])}. Retained label precision {pct(p['retained_reference_label_precision'])}, compared with {pct(p['retain_all_reference_label_precision'])} for retaining all. Every unflagged pair remains unassessed.")+'</p></section>')
    refs=' · '.join('<a href="'+escape(url,quote=True)+'">'+escape(key.replace('_',' '))+'</a>' for key,url in SOURCES.items())
    return '<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Source-verifier comparison</title><style>body{font:16px/1.5 system-ui;max-width:1180px;margin:36px auto;padding:0 20px;color:#142b3d;background:#f6f9fc}section{background:white;padding:24px;margin:24px 0;border:1px solid #d8e2ec;border-radius:12px}h1,h2{line-height:1.15}h3{margin-bottom:8px}.scroll{overflow:auto}table{border-collapse:collapse;min-width:650px;width:100%;font-size:14px}th,td{text-align:left;padding:10px;border-bottom:1px solid #d8e2ec}th{background:#e9f1f7}a{color:#075e91}.muted{color:#53697c;font-size:14px}li{margin:10px 0}</style><main><h1>Source-verifier comparison</h1><p>'+escape(a['primary_hypothesis'])+'</p>'+''.join(sections)+'<section><h2>Scope and reproducibility</h2><ul>'+''.join('<li>'+escape(x)+'</li>' for x in a['scope'])+'</ul><p>Both frames and every completed prediction envelope were sealed before labels were accessed. The full aggregate JSON preserves all method counts, denominators, source and method hashes. No prompt, threshold or calibration was fitted to these outcomes.</p><p>'+refs+'</p><p>'+escape(a['attribution']['data'])+'</p></section></main></html>\n'


def publish_completed(*, assessment_path, protocol_paths, master_path, output_dir,
                      note_path=None, root_publication_go=False):
    need(root_publication_go is True, "root completion/publication GO required before assessment access")
    report=json.loads(Path(assessment_path).read_text()); protocols={}
    for frame in FRAMES:
        need(sha(protocol_paths[frame]) == report["protocols_sha256"][frame], "protocol raw-byte pin differs")
        protocols[frame]=json.loads(Path(protocol_paths[frame]).read_text())
    master=json.loads(Path(master_path).read_text())
    need(master.get("format") == "biograph-steward.overnight-final-source-verifier-experiment.v1"
        and all(master.get("protocols",{}).get(frame,{}).get("sha256") == report["protocols_sha256"][frame]
                for frame in FRAMES), "master experiment protocol references differ")
    a=make_aggregate(report,protocols,assessment_sha256=sha(assessment_path),master_sha256=sha(master_path))
    folder=Path(output_dir);folder.mkdir(parents=True,exist_ok=False)
    (folder/"aggregate.json").write_text(json.dumps(a,indent=2,sort_keys=True)+"\n")
    (folder/"protocol_metadata.json").write_text(json.dumps({"method":a["method"],"protocols":a["public_protocols"],"provenance":a["provenance"]},indent=2,sort_keys=True)+"\n")
    (folder/"report.html").write_text(render_html(a))
    if note_path is not None:
        target=Path(note_path);need(not target.exists(),"refuse to replace a public note");target.parent.mkdir(parents=True,exist_ok=True);target.write_text(render_note(a))
    return a
