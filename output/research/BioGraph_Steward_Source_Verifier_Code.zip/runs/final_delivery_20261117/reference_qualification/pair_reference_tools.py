"""Private, fixed-frame reference labels and paired source-claim measurements.

The label materializer must only be called after the parent has frozen the
protocol and explicitly authorized label access. Importing or testing this
module never opens a reference file. The source pair task is distinct from the
older 134-case whole-Statement experiment.

Metric and resampling structure follows tools/mechanistic_review/score.py, with
the new protocol's explicit-decision balanced accuracy: abstentions receive no
credit in either class. No threshold, prompt or calibration is learned here.
"""

from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import random


DECISIONS = frozenset(("support", "reject", "abstain"))
# Official CURATION_TAGS, pinned in the captured author curation.py. Unknown
# input tags are a source-format problem, rather than invented negative labels.
CURATION_TAGS = frozenset(("correct", "no_relation", "wrong_relation", "grounding",
    "polarity", "act_vs_amt", "hypothesis", "negative_result", "entity_boundaries",
    "agent_conditions", "mod_site", "other"))
RAW_RELEASE_SHA256 = "31f3bcd0cb7f4897ba9cd66da8c51da61d7899280201669a9585d9d6b6f69675"
SEED = 20261117
DRAWS = 10000


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
        separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def _need(condition, message):
    if not condition:
        raise ValueError(message)


def _read_jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line]


def index_cases(cases):
    indexed = {}
    for case in cases:
        cid = case.get("case_id")
        _need(isinstance(cid, str) and cid and cid not in indexed,
              "Missing or duplicated case ID")
        _need(isinstance(case.get("statement"), dict), "Native claim is missing")
        _need(isinstance(case.get("evidence"), dict), "Evidence source is missing")
        indexed[cid] = case
    _need(bool(indexed), "Empty primary frame")
    return indexed


def materialize_labels(*, raw_path, frame_path, output_path,
                       expected_frame_sha256, protocol_path,
                       expected_protocol_sha256, label_access_authorized=False):
    """Read only selected tags, preserving first-write upstream pair semantics.

    This operation is intentionally separate from scoring and requires an
    explicit caller authorization plus hashes of the already frozen protocol
    and label-free frame. It never reads excluded records' outcome fields.
    Missing selected tags fail rather than becoming negative labels.
    """
    _need(label_access_authorized is True, "Parent protocol authorization required")
    _need(sha256(raw_path) == RAW_RELEASE_SHA256, "Pinned original release changed")
    _need(sha256(frame_path) == expected_frame_sha256, "Frame content changed")
    _need(sha256(protocol_path) == expected_protocol_sha256, "Protocol content changed")
    out = Path(output_path)
    _need(not out.exists(), "Refuse to replace an existing label ledger")
    cases = index_cases(_read_jsonl(frame_path))
    selected = {(str(c["matches_hash"]), str(c["source_hash"])): cid
                for cid, c in cases.items()}
    _need(len(selected) == len(cases), "Duplicate source pair in primary frame")
    labels = {}
    for row in _read_jsonl(raw_path):
        pair = (str(row["matches_hash"]), str(row["source_hash"]))
        if pair not in selected:
            continue  # No excluded outcome field is inspected.
        cid = selected[pair]
        _need(cid not in labels, "Released canonical pair occurs more than once")
        tag = row.get("tag")
        _need(isinstance(tag, str) and tag in CURATION_TAGS,
              "Selected curator tag is missing or outside the official vocabulary")
        # Exact author is_gold_correct rule. The source is already canonical
        # first-write-wins; do not aggregate later votes or old endpoint tags.
        labels[cid] = {"case_id": cid,
                       "gold": "supported" if tag == "correct" else "unsupported",
                       "curator_tag": tag,
                       "matches_hash": pair[0], "source_hash": pair[1],
                       "statement_payload_sha256": cases[cid]["statement_payload_sha256"]}
    _need(set(labels) == set(cases), "Selected source labels are incomplete")
    out.write_text("".join(json.dumps(labels[cid], sort_keys=True) + "\n"
                           for cid in cases))
    return {"pairs": len(labels), "labels_sha256": sha256(out),
            "frame_sha256": expected_frame_sha256,
            "protocol_sha256": expected_protocol_sha256,
            "tag_rule": "Exactly correct is supported; every other supplied tag is unsupported.",
            "canonical_rule": "Released first qualifying submission per exact pair; no vote aggregation."}


def normalize_predictions(rows, expected_ids, *, cases=None, method_id=None):
    result = {}
    for row in rows:
        cid, decision = row.get("case_id"), row.get("decision")
        _need(cid in expected_ids and cid not in result, "Unexpected or duplicate prediction ID")
        _need(decision in DECISIONS, "Unknown decision; failures must explicitly abstain")
        if cases is not None:
            # The adapter's source_case_sha256 binds the full released case,
            # while input_sha256 separately binds its native pair request.
            _need(row.get("source_case_sha256") == canonical_sha256(cases[cid]),
                  "Prediction full-case input binding differs")
        if method_id is not None:
            _need(row.get("method_id") == method_id, "Prediction method ID differs")
        result[cid] = decision
    _need(set(result) == set(expected_ids), "Missing predictions must not disappear")
    return result


def _ratio(numerator, denominator):
    return numerator / denominator if denominator else None


def metrics(labels, decisions):
    _need(set(labels) == set(decisions), "Prediction/reference frames differ")
    c = Counter({"pairs": len(labels), "supported": 0, "unsupported": 0,
                 "support_supported": 0, "support_unsupported": 0,
                 "reject_supported": 0, "reject_unsupported": 0,
                 "abstain_supported": 0, "abstain_unsupported": 0})
    for cid, gold in labels.items():
        _need(gold in ("supported", "unsupported"), "Unknown labels are not negatives")
        decision = decisions[cid]
        _need(decision in DECISIONS, "Invalid decision")
        c[gold] += 1
        c[decision + "_" + gold] += 1
    correct_support = _ratio(c["support_supported"], c["supported"])
    correct_reject = _ratio(c["reject_unsupported"], c["unsupported"])
    support_n = c["support_supported"] + c["support_unsupported"]
    reject_n = c["reject_supported"] + c["reject_unsupported"]
    abstain_n = c["abstain_supported"] + c["abstain_unsupported"]
    retained_n = c["pairs"] - reject_n
    c.update({"support_decisions": support_n, "reject_decisions": reject_n,
              "abstentions": abstain_n,
              "correct_explicit_decisions": c["support_supported"] + c["reject_unsupported"]})
    return {"counts": dict(c),
            "balanced_accuracy_abstention_zero": ((correct_support + correct_reject) / 2
                if correct_support is not None and correct_reject is not None else None),
            "explicit_decision_accuracy": _ratio(c["support_supported"] + c["reject_unsupported"], c["pairs"]),
            "coverage": _ratio(c["pairs"] - abstain_n, c["pairs"]),
            "support_precision": _ratio(c["support_supported"], support_n),
            "error_precision": _ratio(c["reject_unsupported"], reject_n),
            "error_recall": correct_reject,
            "error_F1": _ratio(2 * c["reject_unsupported"],
                               2 * c["reject_unsupported"] + c["reject_supported"]
                               + c["unsupported"] - c["reject_unsupported"]),
            "false_support_rate": _ratio(c["support_unsupported"], c["unsupported"]),
            "false_exclusion_rate": _ratio(c["reject_supported"], c["supported"]),
            "retained_supported_fraction": _ratio(c["supported"] - c["reject_supported"], retained_n),
            "retained_supported_fraction_scope": "Secondary effective policy: abstentions remain retained. This is not resolved model accuracy or whole-graph biological accuracy.",
            "denominators": {"coverage": c["pairs"], "explicit_decision_accuracy": c["pairs"],
                             "false_support_rate": c["unsupported"],
                             "false_exclusion_rate": c["supported"],
                             "error_precision": reject_n, "error_recall": c["unsupported"],
                             "support_precision": support_n,
                             "retained_supported_fraction": retained_n},
            "abstentions_receive_zero_primary_credit": True}


def percentile(values, quantile):
    if not values:
        return None
    values = sorted(values)
    at = (len(values) - 1) * quantile
    lo, hi = math.floor(at), math.ceil(at)
    return values[lo] + (values[hi] - values[lo]) * (at - lo)


def paired_group_bootstrap(labels, predictions, groups, comparisons, *,
                           draws=DRAWS, seed=SEED):
    """Fixed paired cluster-percentile bootstrap, preserving all source cases."""
    _need(draws == DRAWS and seed == SEED, "Only frozen 10,000 draws/20261117 seed allowed")
    _need(set(groups) == set(labels), "Source groups must cover exactly the primary frame")
    for decisions in predictions.values():
        _need(set(decisions) == set(labels), "All methods must cover the same complete frame")
    members = defaultdict(list)
    for cid in sorted(labels):
        members[groups[cid]].append(cid)
    names = sorted(members)
    _need(len(names) > 1, "At least two source groups required for uncertainty")
    for candidate, comparator in comparisons:
        _need(candidate in predictions and comparator in predictions and candidate != comparator,
              "Comparison is missing a declared method")
    # Per group: class totals and correct explicit decisions. An abstention adds
    # its class denominator and zero correct decisions.
    group_counts = []
    for group in names:
        ids = members[group]
        n_pos = sum(labels[i] == "supported" for i in ids)
        n_neg = len(ids) - n_pos
        arms = {arm: (sum(labels[i] == "supported" and d[i] == "support" for i in ids),
                      sum(labels[i] == "unsupported" and d[i] == "reject" for i in ids))
                for arm, d in predictions.items()}
        group_counts.append((n_pos, n_neg, arms))
    rng = random.Random(seed)
    multiplicity_hash = hashlib.sha256()
    scores = {arm: [] for arm in predictions}
    diffs = {(a, b): [] for a, b in comparisons}
    undefined = 0
    for _ in range(draws):
        weights = Counter(rng.randrange(len(names)) for _ in names)
        multiplicity_hash.update(json.dumps(sorted(weights.items()), separators=(",", ":")).encode() + b"\n")
        pos = sum(group_counts[i][0] * w for i, w in weights.items())
        neg = sum(group_counts[i][1] * w for i, w in weights.items())
        if not pos or not neg:
            undefined += 1
            continue
        values = {}
        for arm in predictions:
            tp = sum(group_counts[i][2][arm][0] * w for i, w in weights.items())
            tn = sum(group_counts[i][2][arm][1] * w for i, w in weights.items())
            values[arm] = (tp / pos + tn / neg) / 2
            scores[arm].append(values[arm])
        for a, b in comparisons:
            diffs[(a, b)].append(values[a] - values[b])
    point = {arm: metrics(labels, d)["balanced_accuracy_abstention_zero"]
             for arm, d in predictions.items()}
    return {"method": "paired_connected_source_group_percentile_bootstrap",
            "metric": "balanced_accuracy_abstention_zero", "draws": draws, "seed": seed,
            "groups": len(names), "undefined_draws": undefined,
            "same_group_multiplicities_across_methods": True,
            "sample_multiplicities_sha256": multiplicity_hash.hexdigest(),
            "arms": {arm: {"point": point[arm], "percentile_95_interval": [percentile(v, .025), percentile(v, .975)]}
                     for arm, v in scores.items()},
            "comparisons": [{"candidate": a, "comparator": b,
                             "difference": point[a] - point[b],
                             "percentile_95_interval": [percentile(v, .025), percentile(v, .975)],
                             "defined_draws": len(v)} for (a, b), v in diffs.items()],
            "scope": "Conditional variability within this selected curator-reference corpus; not independent biological replication or a population accuracy interval."}


def synthetic_check():
    """Verify denominators without opening any real labels or predictions."""
    labels = {"a": "supported", "b": "supported", "c": "unsupported", "d": "unsupported"}
    d = {"a": "support", "b": "abstain", "c": "reject", "d": "support"}
    m = metrics(labels, d)
    assert m["balanced_accuracy_abstention_zero"] == .5
    assert m["explicit_decision_accuracy"] == .5
    assert m["coverage"] == .75
    assert m["error_precision"] == 1
    assert m["error_F1"] == 2 / 3
    assert m["false_support_rate"] == .5
    assert m["false_exclusion_rate"] == 0
    assert metrics(labels, dict.fromkeys(labels, "abstain"))["balanced_accuracy_abstention_zero"] == 0
    assert metrics(labels, dict.fromkeys(labels, "support"))["balanced_accuracy_abstention_zero"] == .5
    assert metrics(labels, dict.fromkeys(labels, "support"))["error_precision"] is None
    assert metrics(labels, dict.fromkeys(labels, "support"))["error_F1"] == 0
    for malformed in ({"a": "support"}, {**d, "e": "reject"}):
        try:
            metrics(labels, malformed)
        except ValueError:
            pass
        else:
            raise AssertionError("An incomplete/extra frame was accepted")
    return {"synthetic_metric_contract": "passed", "real_labels_opened": False}


if __name__ == "__main__":
    print(json.dumps(synthetic_check(), sort_keys=True))
