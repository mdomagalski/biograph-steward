"""Private scoring of two separately frozen sentence/native-claim frames.

No inference, threshold fitting, graph modification or automatic label access.
All four base/disconfirm prediction envelopes must seal and bind successfully
before either source label ledger is opened. The selected human-curator frames
are conditional reference tasks, not population or biological-truth estimates.
"""
from copy import deepcopy
import importlib.util
import json
from pathlib import Path

import pair_reference_tools as metric

HERE = Path(__file__).resolve().parent
METRIC_SHA256 = "85524d12d0d7734ddaccefcecf04f8a2d6912bdf0c6a475467fcfc66b694a7c2"
EXTERNAL_HELPER_SHA256 = "ee8e14274147def89bd69ba77e4d0fe8a5f70d89ac4bea52d1bfe95c4dea6af4"
ARM_IDS = ("base", "disconfirm")
ALL_ARM_IDS = (*ARM_IDS, "retain_all")
FRAME_IDS = ("primary", "secondary")
COMPARISONS = (("disconfirm", "base"), ("disconfirm", "retain_all"),
               ("base", "retain_all"))


def load_external_helper():
    path = HERE / "secondary_external154/external_label_tools.py"
    metric._need(metric.sha256(path) == EXTERNAL_HELPER_SHA256, "External label helper pin changed")
    spec = importlib.util.spec_from_file_location("frozen_external_label_tools", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def intake_envelope(path, *, cases, frame_sha256, protocol_sha256, arm_id):
    """Validate a sealed full frame, including explicit failure abstentions."""
    payload = json.loads(Path(path).read_text())
    metric._need(isinstance(payload, dict), "Prediction envelope must be an object")
    seal = payload.get("content_sha256")
    metric._need(isinstance(seal, str) and len(seal) == 64, "Prediction envelope lacks a seal")
    metric._need(metric.canonical_sha256({k: v for k, v in payload.items()
        if k != "content_sha256"}) == seal, "Prediction envelope seal differs")
    metric._need(payload.get("format") == "biograph-steward.official-pair-predictions.v1",
                 "Prediction envelope format differs")
    metric._need(payload.get("arm_id") == arm_id, "Wrong arm in prediction envelope")
    metric._need(payload.get("protocol_sha256") == protocol_sha256, "Prediction protocol pin differs")
    metric._need(payload.get("source_cases_sha256") == frame_sha256, "Prediction source frame pin differs")
    rows = payload.get("rows")
    metric._need(isinstance(rows, list), "Prediction rows are missing")
    normalized = {}
    statuses = {}
    for row in rows:
        metric._need(isinstance(row, dict), "Non-object prediction row")
        cid = row.get("case_id")
        metric._need(cid in cases and cid not in normalized, "Extra or duplicate prediction case")
        metric._need(row.get("input_sha256") == metric.canonical_sha256(cases[cid]),
                     "Prediction full-case binding differs")
        metric._need(row.get("arm_id") == arm_id, "Prediction row arm differs")
        decision = row.get("proposal")
        metric._need(decision in metric.DECISIONS, "Unknown prediction decision")
        if arm_id == "retain_all":
            metric._need(decision == "support" and row.get("status") == "constant_baseline"
                         and row.get("model_requests") == 0, "Constant baseline was modified")
        else:
            result = row.get("result")
            metric._need(isinstance(result, dict) and result.get("status") == row.get("status"),
                         "Proposal status differs from the native method result")
            metric._need(result.get("source_case_sha256") == row["input_sha256"],
                         "Native result has a different full-case binding")
            metric._need(result.get("original_case_unchanged") is True,
                         "Native result changed its original case")
            if decision == "abstain":
                metric._need(result.get("status") == "abstain" and result.get("verdict") is None,
                             "Abstention disagrees with native method result")
            else:
                metric._need(result.get("status") == "completed"
                             and result.get("verdict") == ("correct" if decision == "support" else "incorrect"),
                             "Resolved proposal disagrees with author categorical verdict")
        normalized[cid] = decision
        statuses[cid] = row.get("status")
    missing = sorted(set(cases) - set(normalized))
    # The runner must already write explicit technical, transport or declared
    # wall-budget abstentions. A malformed partial envelope is not repaired.
    metric._need(not missing, "Prediction envelope is partial; missing rows are not silently repaired")
    return normalized, {"path": str(path), "file_sha256": metric.sha256(path),
        "content_sha256": seal, "arm_id": arm_id, "sealed_rows": len(rows),
        "complete_denominator": len(cases), "missing_rows_abstained": len(missing),
        "missing_case_ids_private": missing,
        "source_cases_sha256": frame_sha256, "protocol_sha256": protocol_sha256}


def _tokens(case):
    values = {"claim:" + str(case["matches_hash"]),
              "source:" + str(case["source_hash"]),
              case["native_entity_type_family"]}
    pmid = str(case["evidence"].get("pmid") or "").strip()
    if pmid:
        values.add("PMID:" + pmid)
    return values


def agreement_reject_only(labels, predictions):
    """Prespecified conservative review flags, not factual support decisions."""
    metric._need(set(predictions) >= set(ARM_IDS), "Agreement policy needs both author arms")
    for arm in ARM_IDS:
        metric._need(set(predictions[arm]) == set(labels), "Agreement policy frames differ")
    flags = {cid for cid in labels if predictions["base"][cid] == "reject"
             and predictions["disconfirm"][cid] == "reject"}
    supported = sum(value == "supported" for value in labels.values())
    unsupported = sum(value == "unsupported" for value in labels.values())
    metric._need(supported + unsupported == len(labels), "Unknown agreement-policy label")
    flagged_supported = sum(labels[cid] == "supported" for cid in flags)
    flagged_unsupported = len(flags) - flagged_supported
    retained_supported, retained_unsupported = supported - flagged_supported, unsupported - flagged_unsupported
    retained = len(labels) - len(flags)
    retain_all_precision = metric._ratio(supported, len(labels))
    retained_precision = metric._ratio(retained_supported, retained)
    return {"policy_id": "agreement_reject_only",
        "rule": "Flag for review exactly when both official arms reject. Every other case remains retained and unassessed.",
        "pairs": len(labels), "reference_supported": supported, "reference_unsupported": unsupported,
        "flagged": len(flags), "flagged_reference_unsupported": flagged_unsupported,
        "false_exclusions_reference_supported": flagged_supported,
        "retained": retained, "retained_reference_supported": retained_supported,
        "retained_reference_unsupported": retained_unsupported,
        "conditional_flag_precision": metric._ratio(flagged_unsupported, len(flags)),
        "unsupported_flag_recall": metric._ratio(flagged_unsupported, unsupported),
        "supported_false_exclusion_fraction": metric._ratio(flagged_supported, supported),
        "retain_all_reference_label_precision": retain_all_precision,
        "retained_reference_label_precision": retained_precision,
        "retained_reference_label_precision_change_vs_retain_all": (
            retained_precision - retain_all_precision if retained_precision is not None else None),
        "unflagged_cases_are_not_model_supported": True,
        "same_model_correlated_votes": True, "automatic_graph_pruning": False,
        "scope": "Prespecified descriptive review-policy appendix on each selected curator frame. Separate from the primary explicit-decision balanced-accuracy contrast."}


def preflight_all(*, frames):
    """Validate all frames/envelopes without parsing any source label file."""
    metric._need(metric.sha256(HERE / "pair_reference_tools.py") == METRIC_SHA256,
                 "Frozen primary metric/label helper changed")
    metric._need(set(frames) == set(FRAME_IDS), "Both predeclared frames are required")
    external = load_external_helper()
    source_pins = {"primary": metric.RAW_RELEASE_SHA256,
                   "secondary": external.EXTERNAL_RELEASE_SHA256}
    prepared, receipts = {}, {}
    for frame_id in FRAME_IDS:
        spec = frames[frame_id]
        metric._need(metric.sha256(spec["protocol"]) == spec["protocol_sha256"],
                     "Frozen per-frame protocol changed")
        metric._need(metric.sha256(spec["cases"]) == spec["cases_sha256"], "Source case frame changed")
        metric._need(metric.sha256(spec["groups"]) == spec["groups_sha256"], "Connected group frame changed")
        # Byte hashes do not inspect outcome fields. Labels remain unopened.
        metric._need(spec["raw_labels_sha256"] == source_pins[frame_id]
                     and metric.sha256(spec["raw_labels"]) == source_pins[frame_id],
                     "Original reference source bytes changed")
        cases = metric.index_cases(metric._read_jsonl(spec["cases"]))
        groups = {}
        for row in metric._read_jsonl(spec["groups"]):
            cid = row.get("case_id")
            metric._need(cid in cases and cid not in groups and isinstance(row.get("group_id"), str)
                         and bool(row["group_id"]), "Group membership has missing/extra/duplicate IDs")
            groups[cid] = row["group_id"]
        metric._need(set(groups) == set(cases), "Groups omit a source case")
        metric._need(set(spec["predictions"]) == set(ARM_IDS), "Both sealed arms are required")
        completion = json.loads(Path(spec["completion_receipt"]).read_text())
        metric._need(isinstance(completion, dict), "Completion receipt must be an object")
        seal = completion.get("content_sha256")
        metric._need(isinstance(seal, str) and metric.canonical_sha256({k: v for k, v in completion.items()
            if k != "content_sha256"}) == seal, "Completion receipt seal differs")
        metric._need(completion.get("status") == "completed_sealed_before_scoring"
                     and completion.get("all_model_arm_rows_present") is True,
                     "Both methods need the native runner's complete sealed receipt")
        metric._need(completion.get("protocol_sha256") == spec["protocol_sha256"]
                     and completion.get("source_cases_sha256") == spec["cases_sha256"],
                     "Completion receipt protocol/source binding differs")
        metric._need(completion.get("source_rows") == len(cases), "Completion receipt frame count differs")
        metric._need(completion.get("completed_arm_rows") == dict.fromkeys(ALL_ARM_IDS, len(cases)),
                     "Completion receipt omits full-frame rows")
        metric._need(completion.get("labels_accessed") is False
                     and completion.get("retries") == 0 and completion.get("repairs") == 0
                     and completion.get("resumed") is False,
                     "Completion receipt violates frozen no-label/no-retry policy")
        metric._need(type(completion.get("model_requests")) is int
                     and 0 <= completion["model_requests"] <= 2 * len(cases)
                     and completion.get("max_model_requests") == 2 * len(cases),
                     "Completion receipt model-call budget differs")
        outputs = completion.get("outputs")
        metric._need(isinstance(outputs, list) and len(outputs) == 3,
                     "Completion receipt omits an output file")
        output_paths = {}
        for pin in outputs:
            metric._need(isinstance(pin, dict) and set(pin) == {"path", "bytes", "sha256"},
                         "Completion output pin shape differs")
            path = Path(pin["path"])
            metric._need(path.is_file() and not path.is_symlink()
                         and path.stat().st_size == pin["bytes"] and metric.sha256(path) == pin["sha256"],
                         "Completion output file changed")
            arm = path.stem
            metric._need(arm in ALL_ARM_IDS and arm not in output_paths, "Completion output arm is unknown/duplicated")
            output_paths[arm] = path
        for name in ("preflight_receipt", "run_started", "execution_events"):
            pin = completion.get(name)
            metric._need(isinstance(pin, dict) and set(pin) == {"path", "bytes", "sha256"},
                         "Completion execution provenance pin is missing")
            path = Path(pin["path"])
            metric._need(path.is_file() and not path.is_symlink()
                         and path.stat().st_size == pin["bytes"] and metric.sha256(path) == pin["sha256"],
                         "Completion execution provenance file changed")
        predictions, arm_receipts = {}, {}
        for arm in ALL_ARM_IDS:
            if arm in ARM_IDS:
                metric._need(Path(spec["predictions"][arm]).resolve() == output_paths[arm].resolve(),
                             "Supplied arm file differs from completion receipt")
            predictions[arm], arm_receipts[arm] = intake_envelope(output_paths[arm],
                cases=cases, frame_sha256=spec["cases_sha256"],
                protocol_sha256=spec["protocol_sha256"], arm_id=arm)
        prepared[frame_id] = {"cases": cases, "groups": groups, "predictions": predictions}
        receipts[frame_id] = {"pairs": len(cases), "groups": len(set(groups.values())),
            "protocol_path": str(spec["protocol"]), "protocol_sha256": spec["protocol_sha256"],
            "cases_path": str(spec["cases"]), "cases_sha256": spec["cases_sha256"],
            "groups_path": str(spec["groups"]), "groups_sha256": spec["groups_sha256"],
            "raw_reference_path_private": str(spec["raw_labels"]),
            "raw_reference_sha256": spec["raw_labels_sha256"], "arms": arm_receipts,
            "completion_receipt_path": str(spec["completion_receipt"]),
            "completion_receipt_sha256": metric.sha256(spec["completion_receipt"])}
    # The two reference endpoints remain disjoint source/claim/publication units.
    primary_tokens = set().union(*(_tokens(c) for c in prepared["primary"]["cases"].values()))
    secondary_tokens = set().union(*(_tokens(c) for c in prepared["secondary"]["cases"].values()))
    metric._need(not primary_tokens & secondary_tokens, "The primary and secondary exposure frames overlap")
    return prepared, {"all_four_prediction_envelopes_verified": True,
        "both_completion_receipts_verified": True, "labels_parsed": False,
        "missing_prediction_policy": "Runner must write explicit failure/declared-budget abstentions; partial envelopes fail intake.",
        "frames": receipts}


def run_comparison(*, frames, output_dir, label_access_authorized=False):
    """Parent-authorized scoring entry point; never runs automatically."""
    prepared, preflight = preflight_all(frames=frames)
    metric._need(label_access_authorized is True,
                 "Root explicit GO required after every prediction envelope is sealed")
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=False)
    (output / "pre_label_seal_verification.json").write_text(json.dumps(preflight, indent=2, sort_keys=True) + "\n")
    external = load_external_helper()
    reports = {}
    for frame_id in FRAME_IDS:
        spec, data = frames[frame_id], prepared[frame_id]
        label_path = output / (frame_id + "_labels_private.jsonl")
        kwargs = {"raw_path": spec["raw_labels"], "frame_path": spec["cases"],
                  "output_path": label_path, "expected_frame_sha256": spec["cases_sha256"],
                  "protocol_path": spec["protocol"], "expected_protocol_sha256": spec["protocol_sha256"],
                  "label_access_authorized": True}
        label_receipt = (metric.materialize_labels(**kwargs) if frame_id == "primary"
                         else external.materialize_external_labels(**kwargs))
        label_rows = metric._read_jsonl(label_path)
        labels = {row["case_id"]: row["gold"] for row in label_rows}
        metric._need(len(labels) == len(label_rows) and set(labels) == set(data["cases"]),
                     "Label ledger frame differs")
        for row in label_rows:
            metric._need(row["statement_payload_sha256"] == data["cases"][row["case_id"]]["statement_payload_sha256"],
                         "Label/native statement binding differs")
        metrics = {arm: metric.metrics(labels, values) for arm, values in data["predictions"].items()}
        bootstrap = metric.paired_group_bootstrap(labels, data["predictions"], data["groups"], COMPARISONS)
        reports[frame_id] = {"label_receipt": label_receipt, "metrics": metrics,
                            "paired_group_bootstrap": bootstrap,
                            "review_policy_appendix": agreement_reject_only(labels, data["predictions"]),
                            "gold_endpoint": ("Released canonical first qualifying submission; only correct is supported."
                                if frame_id == "primary" else
                                "Released external non-original-pair curator aggregate; any incorrect tag is unsupported.")}
    # Reverify frozen predictions, source bytes and protocol after scoring.
    _, after = preflight_all(frames=frames)
    metric._need(after == preflight, "Source or sealed prediction artifact changed during scoring")
    result = {"format": "biograph-steward.released-sentence-native-claim-comparison.v1",
        "protocols_sha256": {frame_id: frames[frame_id]["protocol_sha256"] for frame_id in FRAME_IDS},
        "preflight": preflight,
        "frames": reports, "all_frame_denominators_preserved": True,
        "metric_helper_sha256": METRIC_SHA256, "external_label_helper_sha256": EXTERNAL_HELPER_SHA256,
        "claims": "Conditional discrimination of selected human-curated sentence/native-claim pairs. No prevalence, whole-graph biological accuracy, clinical or independent biological-replication claim.",
        "thresholds_or_prompts_fit": False, "graph_changed": False}
    result["content_sha256"] = metric.canonical_sha256(result)
    (output / "assessment_private.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    return result
