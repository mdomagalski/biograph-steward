"""Invented-only full-envelope scoring and gate fixtures; no real labels."""
import json
from pathlib import Path
import tempfile

import combined_score as scorer
import pair_reference_tools as metric


def jsonl(path, rows):
    path.write_text("".join(json.dumps(row, sort_keys=True) + "\n" for row in rows))


def sealed(path, value):
    value = dict(value)
    value["content_sha256"] = metric.canonical_sha256(value)
    path.write_text(json.dumps(value, sort_keys=True) + "\n")


def pin(path):
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": metric.sha256(path)}


def make_frame(tmp, name):
    folder = tmp / name
    folder.mkdir()
    protocol = folder / "protocol.json"
    protocol.write_text(json.dumps({"invented_fixture": True, "frame": name}))
    cases = [{"case_id": name + str(i), "matches_hash": name + str(i),
              "source_hash": name + "source" + str(i),
              "native_entity_type_family": name + "family" + str(i),
              "statement": {"type": "InventedFixture"},
              "statement_payload_sha256": "f" * 64,
              "evidence": {"text": "Invented sentence only.", "pmid": name + str(i)}}
             for i in range(4)]
    frame = folder / "cases.jsonl"
    jsonl(frame, cases)
    groups = folder / "groups.jsonl"
    jsonl(groups, [{"case_id": c["case_id"], "group_id": c["case_id"]} for c in cases])
    raw = folder / "source.jsonl"
    rows = []
    for i, c in enumerate(cases):
        row = {"matches_hash": c["matches_hash"], "source_hash": c["source_hash"],
               "tag": "correct" if i < 2 else "grounding"}
        if name == "secondary":
            row.update(all_tags=[row["tag"]], gold="correct" if i < 2 else "incorrect")
        rows.append(row)
    jsonl(raw, rows)
    spec = {"cases": frame, "cases_sha256": metric.sha256(frame), "groups": groups,
            "groups_sha256": metric.sha256(groups), "raw_labels": raw,
            "raw_labels_sha256": metric.sha256(raw), "protocol": protocol,
            "protocol_sha256": metric.sha256(protocol), "predictions": {}}
    output_pins = []
    for arm in scorer.ALL_ARM_IDS:
        predictions = []
        for i, c in enumerate(cases):
            decision = "reject" if arm == "disconfirm" and i >= 2 else "support"
            # Explicit missing model response remains a full-frame abstention.
            if name == "secondary" and arm == "disconfirm" and i == 1:
                decision = "abstain"
            result = {"source_case_sha256": metric.canonical_sha256(c),
                      "original_case_unchanged": True,
                      "status": "abstain" if decision == "abstain" else "completed",
                      "verdict": None if decision == "abstain" else
                          "correct" if decision == "support" else "incorrect"}
            row = {"case_id": c["case_id"], "input_sha256": metric.canonical_sha256(c),
                   "arm_id": arm, "proposal": decision,
                   "status": "constant_baseline" if arm == "retain_all" else result["status"]}
            if arm == "retain_all":
                row["model_requests"] = 0
            else:
                row["result"] = result
            predictions.append(row)
        target = folder / (arm + ".json")
        sealed(target, {"format": "biograph-steward.official-pair-predictions.v1", "arm_id": arm,
            "protocol_sha256": spec["protocol_sha256"], "source_cases_sha256": spec["cases_sha256"],
            "rows": predictions})
        output_pins.append(pin(target))
        if arm in scorer.ARM_IDS:
            spec["predictions"][arm] = target
    provenance = {}
    for name2 in ("preflight_receipt", "run_started", "execution_events"):
        target = folder / (name2 + ".json")
        target.write_text('{"invented_fixture":true}\n')
        provenance[name2] = pin(target)
    completion = folder / "completion.json"
    sealed(completion, {"status": "completed_sealed_before_scoring",
        "protocol_sha256": spec["protocol_sha256"], "source_cases_sha256": spec["cases_sha256"],
        "source_rows": 4, "all_model_arm_rows_present": True,
        "completed_arm_rows": dict.fromkeys(scorer.ALL_ARM_IDS, 4),
        "outputs": output_pins, "model_requests": 8, "max_model_requests": 8,
        "labels_accessed": False, "retries": 0, "repairs": 0, "resumed": False, **provenance})
    spec["completion_receipt"] = completion
    return spec


def run():
    external = scorer.load_external_helper()
    original_loader, original_primary, original_external = (
        scorer.load_external_helper, metric.RAW_RELEASE_SHA256, external.EXTERNAL_RELEASE_SHA256)
    with tempfile.TemporaryDirectory(prefix="combined-fixture-", dir=Path(__file__).parent) as directory:
        tmp = Path(directory)
        frames = {name: make_frame(tmp, name) for name in scorer.FRAME_IDS}
        metric.RAW_RELEASE_SHA256 = frames["primary"]["raw_labels_sha256"]
        external.EXTERNAL_RELEASE_SHA256 = frames["secondary"]["raw_labels_sha256"]
        scorer.load_external_helper = lambda: external
        try:
            prepared, receipt = scorer.preflight_all(frames=frames)
            assert receipt["all_four_prediction_envelopes_verified"]
            assert receipt["both_completion_receipts_verified"]
            assert prepared["secondary"]["predictions"]["disconfirm"]["secondary1"] == "abstain"
            # Even a correctly resealed partial envelope is not a valid full run.
            spec = frames["secondary"]
            path = spec["predictions"]["disconfirm"]
            original = path.read_bytes()
            payload = json.loads(original)
            payload.pop("content_sha256")
            payload["rows"].pop()
            sealed(path, payload)
            try:
                scorer.preflight_all(frames=frames)
            except ValueError:
                pass
            else:
                raise AssertionError("Partial sealed prediction was accepted")
            path.write_bytes(original)
            result = scorer.run_comparison(frames=frames, output_dir=tmp / "scored",
                                           label_access_authorized=True)
            primary = result["frames"]["primary"]
            secondary = result["frames"]["secondary"]
            assert primary["metrics"]["disconfirm"]["balanced_accuracy_abstention_zero"] == 1
            assert primary["metrics"]["base"]["balanced_accuracy_abstention_zero"] == .5
            assert secondary["metrics"]["disconfirm"]["balanced_accuracy_abstention_zero"] == .75
            assert secondary["metrics"]["disconfirm"]["counts"]["pairs"] == 4
            assert secondary["metrics"]["disconfirm"]["coverage"] == .75
            contrast = primary["paired_group_bootstrap"]["comparisons"][0]
            assert contrast["candidate"] == "disconfirm" and contrast["comparator"] == "base"
            assert contrast["difference"] == .5 and contrast["percentile_95_interval"] == [.5, .5]
            assert primary["review_policy_appendix"]["flagged"] == 0
            assert primary["review_policy_appendix"]["conditional_flag_precision"] is None
            assert primary["review_policy_appendix"]["retained_reference_label_precision_change_vs_retain_all"] == 0
            gold = {"a": "supported", "b": "supported", "c": "unsupported", "d": "unsupported"}
            policy = scorer.agreement_reject_only(gold, {
                "base": {"a": "abstain", "b": "support", "c": "reject", "d": "abstain"},
                "disconfirm": {"a": "reject", "b": "support", "c": "reject", "d": "reject"}})
            assert policy["flagged"] == 1 and policy["flagged_reference_unsupported"] == 1
            assert policy["retained"] == 3 and policy["retained_reference_supported"] == 2
            assert policy["unflagged_cases_are_not_model_supported"] is True
            try:
                metric.metrics({"x": "unknown"}, {"x": "support"})
            except ValueError:
                pass
            else:
                raise AssertionError("Unknown source label was accepted")
        finally:
            scorer.load_external_helper = original_loader
            metric.RAW_RELEASE_SHA256 = original_primary
            external.EXTERNAL_RELEASE_SHA256 = original_external
    receipt = {"status": "passed", "real_reference_labels_or_predictions_opened": False,
        "separate_protocols_and_all_four_sealed_arms_before_labels": "passed",
        "actual_runner_completion_receipts_required": "passed",
        "partial_sealed_prediction_rejected": "passed", "unknown_label_rejected": "passed",
        "explicit_missing_response_abstention_keeps_denominator": "passed",
        "contrast_direction_and_paired_CI": "passed",
        "agreement_reject_only_requires_both_rejections_and_retains_unassessed": "passed",
        "metric_helper_sha256": metric.sha256(Path(metric.__file__)),
        "combined_score_sha256": metric.sha256(Path(scorer.__file__)),
        "external_label_helper_sha256": metric.sha256(Path(external.__file__))}
    (Path(__file__).parent / "combined_synthetic_fixtures.json").write_text(
        json.dumps(receipt, indent=2, sort_keys=True) + "\n")
    return receipt


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
