"""Label-blind admission audit of released native statement/evidence pairs.

Reads only non-outcome fields from the released records. It never indexes
gold/tag/all_tags, opens predictions, fits a model or contacts a model endpoint.
"""
import copy
from collections import Counter
import hashlib
import json
from pathlib import Path

import simplejson
from indra.statements import stmts_from_json

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
PRIOR = ROOT / "runs/indra_claim_qualification_20261113/data_capture/blind_join"


def digest(value):
    return hashlib.sha256(simplejson.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        use_decimal=True, allow_nan=False).encode()).hexdigest()


def file_pin(path):
    b = path.read_bytes()
    return {"path": str(path.relative_to(ROOT)), "bytes": len(b),
            "sha256": hashlib.sha256(b).hexdigest()}


def main():
    source = OUT / "private_original/representative_indra_curations_400.jsonl"
    rows = [json.loads(line) for line in source.read_text().splitlines() if line]
    old = json.loads((PRIOR / "pair_join_inventory.json").read_text())["pairs"]
    prior_statements = {str(x["pa_hash"]) for x in old}
    prior_sources = {str(x["source_hash"]) for x in old}
    prior_pmids = set(json.loads((PRIOR / "source_publication_ids.json").read_text())["all_explicit_PMIDs"])
    prior_families = {t for x in old for t in x["candidate_exposure_group_tokens"]
                      if t.startswith("native_entity_type_family:")}
    exclusions = json.loads((OUT / "metadata_label_exposure_exclusions.json").read_text())
    exposed = {(x["matches_hash"], x["source_hash"]) for x in exclusions["pairs"]}
    # Propagate the 11 known metadata exposures through publication, claim and
    # source identity before touching any new outcome. Same existing exposure
    # units are used for both prior-reference and new-reference quarantine.
    exposed_rows = [row for row in rows
                    if (str(row["matches_hash"]), str(row["source_hash"])) in exposed]
    exposed_statements = {str(row["matches_hash"]) for row in exposed_rows}
    exposed_sources = {str(row["source_hash"]) for row in exposed_rows}
    exposed_publications = {str(row.get("pmid") or "").strip() for row in exposed_rows}
    exposed_publications.discard("")
    cases, ledger, errors = [], [], []
    stats = Counter()
    aggregate = Counter()
    for index, row in enumerate(rows):
        # No gold, tag, all_tags, notes, curator or curation-date values are used.
        mh, sh = str(row["matches_hash"]), str(row["source_hash"])
        original = copy.deepcopy(row["statement"])
        source_hash = digest(original)
        native = stmts_from_json([copy.deepcopy(original)], on_missing_support="ignore")
        reasons = []
        if len(native) != 1:
            reasons.append("native_deserialization_cardinality")
            st = None
        else:
            st = native[0]
            nh = str(st.get_hash(refresh=True))
            if nh != mh:
                reasons.append("native_statement_hash_changed")
                errors.append({"row_index": index, "declared": mh, "native": nh})
            if st.__class__.__name__ != row["stmt_type"]:
                reasons.append("native_statement_type_changed")
        assert digest(original) == source_hash
        pmid = str(row.get("pmid") or "").strip()
        if not pmid or not pmid.isdecimal() or int(pmid) <= 0:
            reasons.append("missing_or_unqualified_publication_id")
        elif pmid in prior_pmids:
            reasons.append("prior_reference_publication")
        if mh in prior_statements:
            reasons.append("prior_reference_statement")
        if sh in prior_sources:
            reasons.append("prior_reference_source")
        if (mh, sh) in exposed:
            reasons.append("metadata_individual_label_exposure")
        if mh in exposed_statements:
            reasons.append("metadata_exposure_statement_group")
        if sh in exposed_sources:
            reasons.append("metadata_exposure_source_group")
        if pmid in exposed_publications:
            reasons.append("metadata_exposure_publication_group")
        family = None
        if st is not None:
            agents = st.agent_list(deep_sorted=True)
            entity_keys = [a.entity_matches_key() if a is not None else None for a in agents]
            family = "native_entity_type_family:" + digest(
                {"type": original["type"], "entity_keys": entity_keys})
            if family in prior_families:
                reasons.append("prior_exact_native_entity_type_family")
            for a in agents:
                if a is None:
                    aggregate["null_agents"] += 1
                    continue
                aggregate["agents"] += 1
                refs = a.db_refs or {}
                aggregate["agents_with_nonTEXT_grounding"] += bool(set(refs) - {"TEXT", "TEXT_NORM"})
                aggregate["agents_with_original_TEXT"] += bool(refs.get("TEXT"))
                aggregate["agents_with_conditions"] += any(
                    bool(getattr(a, key, None)) for key in
                    ["mods", "mutations", "activity", "bound_conditions", "location"])
        if not isinstance(row.get("evidence_text"), str) or not row["evidence_text"].strip():
            reasons.append("missing_source_text")
        if original.get("type") == "Complex":
            aggregate["complex_pairs"] += 1
            aggregate["complex_with_more_than_two_members"] += len(original.get("members", [])) > 2
        aggregate["native_statements_with_site"] += bool(original.get("position") or original.get("residue"))
        stats.update(reasons)
        record = {
            "case_id": "indra-pair:" + mh + ":" + sh,
            "original_row_index": index, "matches_hash": mh, "source_hash": sh,
            "statement": original, "statement_payload_sha256": source_hash,
            "evidence": {"text": row.get("evidence_text"), "source_api": row.get("source_api"),
                         "pmid": pmid, "original_source_hash": sh},
            "native_entity_type_family": family,
            "native_evidence_annotations_available": False,
            "native_evidence_epistemics_available": False,
            "raw_source_id_available": False,
            "source_hash_must_not_be_regenerated_as_original_identity": True,
            "published_row_statement_fields_preserved": True,
        }
        ledger.append({"case_id": record["case_id"], "original_row_index": index,
                       "eligible_before_prompt_exclusion": not reasons,
                       "reasons": sorted(set(reasons))})
        if not reasons:
            cases.append(record)
    case_path = OUT / "native_pairs_before_prompt_exclusion.jsonl"
    ledger_path = OUT / "native_admission_ledger.jsonl"
    case_path.write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in cases))
    ledger_path.write_text("".join(json.dumps(x, sort_keys=True) + "\n" for x in ledger))
    summary = {
        "status": "pending_author_prompt_overlap_gate", "original_pairs": len(rows),
        "admitted_before_prompt_gate": len(cases), "exclusion_reasons_nonexclusive": dict(stats),
        "native_hash_drift": len(errors), "native_hash_drift_detail_private": errors,
        "input_shape_counts": dict(aggregate), "new_individual_labels_opened": False,
        "no_label_values_used_for_admission": True,
        "original_statement_json_preserved": True,
        "flat_evidence_is_not_full_original_native_Evidence": True,
        "prior_exposure_scope": "All5709 original INDRA-reference pairs and3715 explicit publications plus exact native entity/type family tokens; does not cover every raw source ever cached elsewhere in the project or unknown model pretraining.",
        "source": file_pin(source),
        "prior_pair_inventory": file_pin(PRIOR / "pair_join_inventory.json"),
        "prior_publication_inventory": file_pin(PRIOR / "source_publication_ids.json"),
        "metadata_label_exclusions": file_pin(OUT / "metadata_label_exposure_exclusions.json"),
        "cases": file_pin(case_path), "ledger": file_pin(ledger_path),
        "scripts_do_not_refit_or_score": True,
    }
    (OUT / "native_admission_summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n")
    print(json.dumps({k: v for k, v in summary.items()
                      if k not in ["native_hash_drift_detail_private", "source", "cases", "ledger",
                                   "prior_pair_inventory", "prior_publication_inventory", "metadata_label_exclusions"]},
                     indent=2))


if __name__ == "__main__":
    main()
