"""Invented native claim/Evidence fixtures only; no model, network or gold."""
from copy import deepcopy
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import bridge as b


class Ontology:
    def __init__(self,mappings=None):self.mappings=mappings or {}
    def get_replacement(self,*args):return None
    def get_mappings(self,*args):return self.mappings.get(tuple(args),[])


class BridgeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.native=b.q.load_native()
        from indra.statements import Activation,Agent
        from indra_belief.data.entity import GroundedEntity
        cls.Entity=GroundedEntity
        statement=Activation(Agent('InventedA',db_refs={'HGNC':'1'}),Agent('InventedB',db_refs={'HGNC':'2'})).to_json()
        statement.pop('belief',None)
        cls.statement=statement

    def setUp(self):
        self.network=patch('socket.create_connection',side_effect=AssertionError('No network in invented tests'));self.network.start()
        self.resolver=patch.object(self.Entity,'resolve',side_effect=lambda name,raw_text=None:
            self.Entity(name=name,raw_text=raw_text,canonical=name,db='HGNC',db_id='1' if name=='InventedA' else '2'))
        self.resolver.start()
        self.ontology=patch('indra.ontology.bio.bio_ontology',Ontology());self.ontology.start()
        evidence={'text':'InventedA activates InventedB.','source_api':'invented_only','pmid':'00000000',
            'annotations':{'agents':{'raw_text':['InventedA','InventedB']},'found_by':'invented_fixture'},
            'epistemics':{'direct':False,'hedgings':['invented'], 'section_type':'results'},
            'source_hash':1234567000000000000,'text_refs':{'PMID':'00000000'}}
        self.case={'case_id':'invented-corrected-input','statement':deepcopy(self.statement),
            'statement_payload_sha256':b.digest(self.statement),'matches_hash':'INVENTED_MATCH','source_hash':'INVENTED_EXACT_ID',
            'evidence_available':True,'evidence':evidence,'original_evidence_object_sha256':b.digest(evidence),
            'released_evidence_fields':{'text':evidence['text'],'source_api':'invented_only','pmid':'00000000',
                'original_source_hash':'INVENTED_EXACT_ID'}}

    def tearDown(self):self.ontology.stop();self.resolver.stop();self.network.stop()

    def refresh(self):self.case['original_evidence_object_sha256']=b.digest(self.case['evidence'])

    def test_complete_original_evidence_survives_and_unrendered_metadata_is_not_new_filter(self):
        original=deepcopy(self.case);payloads=[]
        def respond(payload):
            payloads.append(payload)
            return {'model':self.native.MODEL,'choices':[{'finish_reason':'stop','message':{'role':'assistant',
                'content':'{"verdict":"correct","confidence":"medium"}'}}],
                'usage':{'prompt_tokens':2000,'completion_tokens':14}}
        client=self.native.NanoClient(transport=respond)
        result=b.review(self.case,'full',client=client,model_kind='nano')
        self.assertEqual(result['status'],'completed');self.assertEqual(result['model_requests'],1)
        self.assertEqual(self.case,original);self.assertTrue(result['original_evidence_object_preserved'])
        self.assertTrue(result['original_cached_source_hash_preserved'])
        self.assertNotIn('native_evidence_runtime_hash_is_released_identity',result)
        self.assertEqual(result['qualification']['original_cached_evidence_source_hash'],1234567000000000000)
        self.assertFalse(result['qualification']['refreshed_hash_matches_curation_identity'])
        self.assertEqual(len(result['native_result']['selected_example_ids']),14)
        self.assertIsNone(result['native_result']['score']);self.assertEqual(len(payloads),1)

    def test_hypothesis_and_negation_are_explicit_technical_abstentions(self):
        for flag in ('hypothesis','negated'):
            with self.subTest(flag=flag):
                self.case['evidence']['epistemics']={flag:True};self.refresh()
                calls=[];client=self.native.NanoClient(transport=lambda p:calls.append(p))
                result=b.review(self.case,'full',client=client,model_kind='nano')
                self.assertEqual(result['status'],'abstain');self.assertEqual(result['model_requests'],0)
                self.assertIn('unrendered_epistemics_'+flag,result['qualification']['technical_reasons'])
                self.assertEqual(calls,[])

    def test_known_native_identity_conflict_abstains_without_editing_claim(self):
        with patch.object(self.Entity,'resolve',side_effect=lambda name,raw_text=None:
            self.Entity(name=name,raw_text=raw_text,canonical='Different',db='HGNC',db_id='999')):
            result=b.qualify(self.case,'full')
        self.assertFalse(result['eligible'])
        self.assertIn('native_identity_conflict_in_shared_namespace',result['technical_reasons'])
        self.assertEqual(self.case['statement'],self.statement)

    def test_unambiguous_official_xref_is_allowed_but_ambiguity_or_isoform_collapse_is_not(self):
        mapping={('HGNC','1'):[('UP','P00001')],('UP','P00001'):[('HGNC','1')]}
        self.assertEqual(b.compare_identities(('HGNC','1'),('UP','P00001'),Ontology(mapping))['status'],'official_unambiguous_xref')
        mapping[('HGNC','1')].append(('UP','P00002'))
        self.assertEqual(b.compare_identities(('HGNC','1'),('UP','P00001'),Ontology(mapping))['status'],'unresolved_ambiguous_official_xref')
        self.assertEqual(b.compare_identities(('UP','P00001-2'),('HGNC','1'),Ontology(mapping))['status'],'unresolved_specific_isoform_identity')
        self.assertEqual(b.compare_identities(('UP','P00001'),('CHEBI','CHEBI:1'),Ontology())['status'],'unresolved_cross_namespace_identity')
        self.assertFalse(b.compare_identities(('UP','P00001'),('CHEBI','CHEBI:1'),Ontology())['conflict'])

    def test_no_native_grounding_is_unknown_not_an_error_filter(self):
        for key in ('subj','obj'):self.case['statement'][key]['db_refs']={}
        self.case['statement_payload_sha256']=b.digest(self.case['statement'])
        result=b.qualify(self.case,'full')
        self.assertTrue(result['eligible']);self.assertEqual(result['technical_reasons'],[])
        self.assertTrue(all(row['status']=='native_identity_unavailable_not_contradicted' for row in result['identities']))

    def test_missing_full_evidence_retains_source_case_and_partial_view(self):
        self.case.update(evidence_available=False,evidence=None,original_evidence_object_sha256=None)
        full=b.qualify(self.case,'full');partial=b.qualify(self.case,'partial')
        self.assertEqual(full['technical_reasons'],['original_curated_evidence_unavailable'])
        self.assertTrue(partial['eligible']);self.assertEqual(full['input_sha256'],b.digest(self.case))

    def test_changed_native_payload_or_null_raw_role_cannot_silently_qualify(self):
        self.case['evidence']['annotations']['agents']['raw_text']=[None,'InventedB'];self.refresh()
        self.assertIn('raw_mention_role_alignment_unproven',b.qualify(self.case,'full')['technical_reasons'])
        self.case['statement']['subj']['name']='Changed'
        with self.assertRaises(ValueError):b.qualify(self.case,'full')


if __name__=='__main__':unittest.main(verbosity=2)
