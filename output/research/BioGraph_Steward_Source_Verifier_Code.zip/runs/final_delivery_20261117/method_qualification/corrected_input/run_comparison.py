"""Private fixed consumed-reference input-completeness/model diagnostic.

Preflight is generation-free. Execution requires a separately ROOT-frozen
protocol, all preflight seals and an exclusive one-pass start marker. No labels,
retries, response repair, model calibration, new source retrieval or graph edits.
"""
from collections import Counter
from copy import deepcopy
import argparse
import hashlib
import json
import os
from pathlib import Path
import random
import sys
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
sys.path.insert(0,str(HERE.parent/'adapter'))
import run_pair_comparison as old
import bridge
q=bridge.q
encoded,digest=bridge.encoded,bridge.digest
write_new,journal,raw_pin,stamp=old.write_new,old.journal,old.raw_pin,old.stamp
FORMAT='biograph-steward.original-evidence-diagnostic.v1'
ARMS={'nano_partial_cached':('nano','partial'),'nano_full':('nano','full'),
      'qwen_partial':('qwen','partial'),'qwen_full':('qwen','full')}
PIN_NAMES=('source_cases','partial_cases','full_admission_manifest','cached_nano_partial',
    'cached_completion','cached_protocol','cached_order','native_ontology_cache',
    'native_dependencies','readiness','upstream_manifest','bridge','runner','nano_adapter',
    'original_runner','qwen_client','qwen_readiness')


def load_protocol(path,expected_sha,*,generation=False):
    path=Path(path).resolve()
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected_sha or len(expected_sha)!=64:
        raise ValueError('Explicit reviewed raw protocol SHA is required.')
    p=json.loads(path.read_text())
    accepted={'ROOT_REVIEW_REQUIRED','ROOT_FROZEN_CORRECTED_INPUT_DIAGNOSTIC'}
    if p.get('format')!=FORMAT or p.get('status') not in accepted:
        raise ValueError('Unknown bounded diagnostic protocol.')
    if generation and p['status']!='ROOT_FROZEN_CORRECTED_INPUT_DIAGNOSTIC':
        raise ValueError('Reference generation requires ROOT-frozen protocol GO.')
    pins={key:old.resolve_pin(p[key]) for key in PIN_NAMES}
    for pin in p.get('code_files',[]):old.resolve_pin(pin)
    if pins['runner']!=Path(__file__).resolve() or pins['bridge']!=HERE/'bridge.py':
        raise ValueError('Invoked diagnostic code differs from its pin.')
    if pins['qwen_client']!=Path(q.__file__).resolve() or pins['original_runner']!=Path(old.__file__).resolve():
        raise ValueError('Existing transport/native helper differs from protocol.')
    pars=p['parameters']
    expected={'temperature':.1,'max_output_tokens':1024,'seed':20261117,
        'nano_endpoint':'http://127.0.0.1:18117/v1/chat/completions',
        'qwen_model_id':q.MODEL,'qwen_region':q.REGION,'qwen_profile':q.PROFILE,
        'nano_model_id':'nvidia/Llama-3.1-Nemotron-Nano-8B-v1',
        'nano_model_revision':'54641c1611fcff44fa4865626462445e0a153fc7',
        'nano_context_tokens':16384,'qwen_request_byte_limit':65536,
        'qwen_context_tokens':262144,'qwen_max_requests':290,'max_model_requests':435,
        'qwen_spend_cap_usd':'10.00','max_wall_seconds':10800}
    if any(pars.get(key)!=value for key,value in expected.items()) or p.get('expected_case_count')!=145:
        raise ValueError('Qualified task, provider or fixed budget differs.')
    if p.get('arms')!=list(ARMS) or p.get('author_variant')!='':
        raise ValueError('Only unchanged officialBASE with fixed four diagnostic arms is qualified.')
    # Verify complete byte/code/resource inventory before native imports.
    old.verify_native_dependencies(p,pins)
    cases=[json.loads(line) for line in pins['source_cases'].read_text().splitlines() if line]
    partial=[json.loads(line) for line in pins['partial_cases'].read_text().splitlines() if line]
    if len(cases)!=145 or len(partial)!=145 or len({c['case_id'] for c in cases})!=145:
        raise ValueError('Common145-frame identities differ.')
    if [c['case_id'] for c in cases]!=[c['case_id'] for c in partial]:
        raise ValueError('Original and corrected source order/caseIDs differ.')
    for case,original in zip(cases,partial):
        if case.get('original_partial_case_sha256')!=digest(original) or case['statement']!=original['statement']:
            raise ValueError('Original source case/native claim binding differs.')
        provenance=case['input_provenance_pin']
        old.resolve_pin({**provenance,'path':str(pins['source_cases'].parent/provenance['path'])})
        bridge.selected_evidence(case,'partial');bridge.selected_evidence(case,'full')
    cached=json.loads(pins['cached_nano_partial'].read_text());body=deepcopy(cached)
    seal=body.pop('content_sha256',None)
    if digest(body)!=seal or cached['arm_id']!='base' or cached['protocol_sha256']!=p['cached_protocol']['sha256']:
        raise ValueError('Original NanoBASE output seal/protocol differs.')
    if cached['source_cases_sha256']!=p['partial_cases']['sha256'] or len(cached['rows'])!=145:
        raise ValueError('Original NanoBASE frame differs.')
    if [r['case_id'] for r in cached['rows']]!=[c['case_id'] for c in cases]:
        raise ValueError('Original cached row order differs.')
    for row,original in zip(cached['rows'],partial):
        if row['input_sha256']!=digest(original) or row['result']['source_case_sha256']!=digest(original):
            raise ValueError('Cached outcome input differs from original source.')
    completion=json.loads(pins['cached_completion'].read_text());unsealed=deepcopy(completion)
    complete_seal=unsealed.pop('content_sha256',None)
    if digest(unsealed)!=complete_seal or completion['status']!='completed_sealed_before_scoring':
        raise ValueError('Original full-frame completion seal required.')
    if raw_pin(pins['cached_nano_partial'].parent/'preflight.json')!=completion['preflight_receipt']:
        raise ValueError('Original actual tokenizer receipt differs from completed source run.')
    if not any(x['sha256']==p['cached_nano_partial']['sha256'] and x['bytes']==p['cached_nano_partial']['bytes']
               for x in completion['outputs']):raise ValueError('Original completion does not bind cachedBASE.')
    readiness=json.loads(pins['readiness'].read_text())
    if readiness['model_id']!=pars['nano_model_id'] or readiness['model_revision']!=pars['nano_model_revision'] or readiness['max_model_len']!=16384:
        raise ValueError('Native Nano runtime readiness differs.')
    q.load_native()  # Existing optional-runtime/version/upstream/resource verifier.
    pins['protocol']=path
    return p,pins,cases,cached


def plan_rows(cases):
    rng=random.Random(20261117);rows=[]
    for index,case in enumerate(cases):
        names=list(ARMS);rng.shuffle(names)
        rows.extend({'index':index,'case_id':case['case_id'],'arm_id':arm,
            'stem':f'{index:04d}_{arm}','input_sha256':digest(case)} for arm in names)
    return rows


def cached_packet(pins,index):
    path=pins['cached_nano_partial'].parent/'preflight'/f'{index:04d}_base.json'
    previous=json.loads((pins['cached_nano_partial'].parent/'preflight.json').read_text())
    pin=next((x for x in previous['preflight_inventory'] if Path(x['path'])==path),None)
    if pin is None or raw_pin(path)!=pin:raise ValueError('Original actual tokenizer packet pin differs.')
    return json.loads(path.read_text())


def render(case,view,model,qualification):
    requests=[]
    class RenderOnly(Exception):pass
    def capture(payload):requests.append(deepcopy(payload));raise RenderOnly('Generation-free native rendering.')
    client=(q.QwenConverseClient(spend=q.QwenSpendCap('.20',2),executor=capture) if model=='qwen'
        else q.load_native().NanoClient(transport=capture,max_tokens=1024))
    result=bridge.review(case,view,client=client,model_kind=model,qualification=qualification)
    if len(requests)>1:raise ValueError('NativeBASE attempted more than one request.')
    if requests:return {'kind':'callable','request':requests[0],'request_sha256':digest(requests[0])}
    if not qualification['eligible']:
        return {'kind':'technical_abstention','result':result}
    if result['status']=='completed' and result['verdict'] in {'correct','incorrect'}:
        return {'kind':'deterministic_native_decision','result':result}
    raise ValueError('Unexpected author-native render failure: '+str(result.get('reason')))


def nano_tokenize(packet,p):
    native=q.load_native();request=packet['request']
    if request['model']!=native.MODEL or request['temperature']!=.1 or request['max_tokens']!=1024:
        raise ValueError('Exact Nano wire parameters differ.')
    token_body={'model':native.MODEL,'messages':request['messages'],'add_generation_prompt':True}
    response=old.http_json(p['parameters']['nano_endpoint'].replace('/v1/chat/completions','/tokenize'),token_body)
    count=response['body'].get('count')
    if (response['status']!=200 or type(count)is not int or count<=0 or
        response['body'].get('max_model_len')!=16384 or len(response['body'].get('tokens',[]))!=count):
        raise ValueError('Actual complete Nano tokenizer preflight failed.')
    packet.update(tokenize_request=token_body,tokenize_response=response)
    if count+1024>16384:packet.update(kind='context_abstention',technical_reason='full_prompt_over_context_no_truncation')


def preflight(out,p,sha,pins,cases,cached):
    out.mkdir(exist_ok=False);(out/'preflight').mkdir()
    rows=plan_rows(cases);write_new(out/'order.json',{'protocol_sha256':sha,'rows':rows,'ordering_seed_only':20261117})
    metadata=old.http_json(p['parameters']['nano_endpoint'].replace('/chat/completions','/models'))
    write_new(out/'model_metadata.json',metadata)
    if metadata['status']!=200 or not any(m.get('id')==p['parameters']['nano_model_id'] for m in metadata['body'].get('data',[])):
        raise ValueError('Actual Nano server identity differs.')
    counts=Counter();packets={};qualifications={};inventory=[]
    for row in rows:
        case=cases[row['index']];model,view=ARMS[row['arm_id']]
        key=(case['case_id'],view)
        if key not in qualifications:qualifications[key]=bridge.qualify(case,view)
        qualification=qualifications[key]
        packet={**row,'qualification':qualification,**render(case,view,model,qualification)}
        if row['arm_id']=='nano_partial_cached':
            original=cached_packet(pins,row['index']);packet['original_packet_pin']=raw_pin(
                pins['cached_nano_partial'].parent/'preflight'/f"{row['index']:04d}_base.json")
            packet['original_preflight_kind']=original['kind']
            if packet['kind']=='callable':
                if original['kind'] not in {'callable','context_abstention'} or packet['request']!=original['request']:
                    raise ValueError('Current partial render differs from the preserved original Nano request.')
                packet.update(tokenize_request=original['tokenize_request'],tokenize_response=original['tokenize_response'])
                if original['kind']=='context_abstention':packet['kind']='context_abstention'
        elif packet['kind']=='callable' and model=='nano':nano_tokenize(packet,p)
        elif packet['kind']=='callable':
            # Native provider packing fits conservative UTF8 byte upper bound;
            # exact actual token usage is retained after each request, no crop.
            if len(encoded(packet['request']))>65536:raise ValueError('Full Qwen request exceeds qualified bytebound.')
            bytebound=len(encoded(packet['request']));overhead=4096
            if bytebound+overhead+1024>=262144:raise ValueError('Conservative full-context upper bound exceeded.')
            packet['context_preflight']={'method':'full_UTF8_bytes_plus4096_chat_overhead_plus1024_output',
                'request_bytes':bytebound,'conservative_chat_overhead_tokens':overhead,
                'context_token_upper_bound':bytebound+overhead+1024,
                'context_limit':262144,'exact_provider_tokenizer_used':False}
        packet['actual_generation_requests']=0
        path=out/'preflight'/(row['stem']+'.json');write_new(path,packet);inventory.append(raw_pin(path))
        packets[(case['case_id'],row['arm_id'])]=packet;counts[row['arm_id']+':'+packet['kind']]+=1
    masks=[];equivalence=[]
    for case in cases:
        selected={arm:packets[(case['case_id'],arm)] for arm in ARMS}
        eligible={arm:packet['qualification']['eligible'] and packet['kind']!='context_abstention' and
            (arm!='nano_partial_cached' or packet['original_preflight_kind'] not in {'technical_abstention','context_abstention'})
            for arm,packet in selected.items()}
        masks.append({'case_id':case['case_id'],'input_sha256':digest(case),'eligible':eligible,
            'joint_eligible':all(eligible.values()),'technical_reasons':{arm:packet['qualification']['technical_reasons']+
                ([packet.get('technical_reason','context_abstention')] if packet['kind']=='context_abstention' else [])
                for arm,packet in selected.items()},'cached_original_preflight_kind':selected['nano_partial_cached']['original_preflight_kind']})
        for model,left,right in [('nano','nano_partial_cached','nano_full'),('qwen','qwen_partial','qwen_full')]:
            a,b=selected[left],selected[right]
            status=('identical' if a.get('request')==b.get('request') else 'changed') if all(
                x['kind']=='callable' for x in (a,b)) else 'noncallable'
            equivalence.append({'case_id':case['case_id'],'model':model,'status':status,
                'partial_request_sha256':a.get('request_sha256'),'full_request_sha256':b.get('request_sha256')})
    with (out/'technical_mask.jsonl').open('xb') as stream:
        for row in masks:stream.write(encoded(row)+b'\n')
        stream.flush();os.fsync(stream.fileno())
    audit={'scope':'payloads/generationparams only, no outcome comparison','rows':equivalence,
        'counts':dict(Counter(x['model']+':'+x['status'] for x in equivalence))}
    write_new(out/'payload_equivalence.json',audit)
    load_protocol(pins['protocol'],sha)
    summary={'status':'passed','protocol_sha256':sha,'source_cases_sha256':p['source_cases']['sha256'],
        'source_rows':145,'counts':dict(counts),'all_four_joint_eligible':sum(x['joint_eligible'] for x in masks),
        'actual_generation_requests':0,'preflight_inventory':inventory,'order':raw_pin(out/'order.json'),
        'technical_mask':raw_pin(out/'technical_mask.jsonl'),'payload_equivalence':raw_pin(out/'payload_equivalence.json')}
    summary['content_sha256']=digest(summary);write_new(out/'preflight.json',summary);return summary


def execute(out,p,sha,pins,cases,cached):
    pre=json.loads((out/'preflight.json').read_text());plain=deepcopy(pre);seal=plain.pop('content_sha256',None)
    if digest(plain)!=seal or pre['status']!='passed' or pre['protocol_sha256']!=sha:
        raise ValueError('Full successful preflight for the ROOT-frozen protocol required.')
    for pin in [*pre['preflight_inventory'],pre['order'],pre['technical_mask'],pre['payload_equivalence']]:
        if raw_pin(pin['path'])!=pin:raise ValueError('A pre-generation packet changed.')
    order=json.loads((out/'order.json').read_text())['rows']
    if order!=plan_rows(cases):raise ValueError('Frozen ordering differs.')
    write_new(out/'run_started.json',{'at':stamp(),'protocol_sha256':sha,'one_pass_no_retry_or_resume':True})
    (out/'results').mkdir(exist_ok=False);actual={arm:[] for arm in ARMS};calls=0;started=time.monotonic()
    metadata=old.http_json(p['parameters']['nano_endpoint'].replace('/chat/completions','/models'))
    write_new(out/'execution_model_metadata.json',metadata)
    if metadata['status']!=200 or not any(m.get('id')==p['parameters']['nano_model_id'] for m in metadata['body'].get('data',[])):
        raise ValueError('Actual Nano execution identity differs before generation.')
    spend=q.QwenSpendCap(p['parameters']['qwen_spend_cap_usd'],290)
    for row in order:
        case=cases[row['index']];arm=row['arm_id'];model,view=ARMS[arm]
        packet=json.loads((out/'preflight'/(row['stem']+'.json')).read_text());drift=[]
        journal(out/'execution_events.jsonl',{'at':stamp(),'kind':'row_intent',**row})
        if arm=='nano_partial_cached':
            original=deepcopy(cached['rows'][row['index']])
            normalized={'case_id':case['case_id'],'input_sha256':digest(case),'source_case_sha256':digest(case),
                'arm_id':arm,'proposal':original['proposal'],'status':original['status'],
                'cached_original_row':original,'cached_original_row_sha256':digest(original),
                'original_partial_case_sha256':case['original_partial_case_sha256'],
                'new_model_requests':0,'qualification':packet['qualification']}
        else:
            if packet['kind'] in {'technical_abstention','deterministic_native_decision'}:result=packet['result']
            elif packet['kind']=='context_abstention':
                result={'status':'abstain','verdict':None,'reason':'full_prompt_over_context_no_truncation',
                    'model_requests':0,'source_case_sha256':digest(case),'qualification':packet['qualification'],
                    'original_case_unchanged':True,'new_graph_decision':False}
            else:
                def event(value):
                    nonlocal calls
                    if value['status']=='request_intent':
                        if value['request_sha256']!=packet['request_sha256'] or value['request']!=packet['request']:
                            drift.append('payload');raise ValueError('Prepared complete provider request drifted.')
                        if calls>=435:drift.append('budget');raise ValueError('Frozen request budget exhausted.')
                        calls+=1
                    journal(out/'execution_events.jsonl',{'at':stamp(),'stem':row['stem'],'event':value})
                if model=='nano':
                    def counter(payload):
                        if digest(payload)!=packet['request_sha256']:drift.append('tokens');raise ValueError('Nano request drift.')
                        return packet['tokenize_response']['body']['count']
                    client=q.load_native().NanoClient(endpoint=p['parameters']['nano_endpoint'],allow_live=True,
                        max_tokens=1024,token_counter=counter,event_callback=event)
                else:client=q.QwenConverseClient(spend=spend,allow_live=True,event_callback=event)
                result=bridge.review(case,view,client=client,model_kind=model,qualification=packet['qualification'])
                if drift:write_new(out/'results'/(row['stem']+'.failed.json'),result);raise ValueError('Payload integrity failed; never retry.')
            if result['source_case_sha256']!=digest(case) or not result['original_case_unchanged']:
                raise ValueError('Original case changed or rebound.')
            normalized={'case_id':case['case_id'],'input_sha256':digest(case),'source_case_sha256':digest(case),
                'arm_id':arm,'proposal':{'correct':'support','incorrect':'reject'}.get(result.get('verdict'),'abstain'),
                'status':result['status'],'result':result}
        write_new(out/'results'/(row['stem']+'.json'),normalized);actual[arm].append(normalized)
    load_protocol(pins['protocol'],sha,generation=True)
    positions={c['case_id']:i for i,c in enumerate(cases)};outputs=[]
    for arm,rows in actual.items():
        rows.sort(key=lambda r:positions[r['case_id']])
        if len(rows)!=145:raise ValueError('Incomplete common frame cannot seal.')
        envelope={'format':'biograph-steward.original-evidence-predictions.v1','arm_id':arm,
            'protocol_sha256':sha,'source_cases_sha256':p['source_cases']['sha256'],'rows':rows}
        envelope['content_sha256']=digest(envelope);path=out/(arm+'.json');write_new(path,envelope);outputs.append(raw_pin(path))
    receipt={'status':'completed_sealed_before_scoring','protocol_sha256':sha,
        'source_cases_sha256':p['source_cases']['sha256'],'source_rows':145,
        'all_model_arm_rows_present':True,'completed_arm_rows':{a:len(r) for a,r in actual.items()},
        'new_model_requests':calls,'max_model_requests':435,'qwen_spend':spend.snapshot(),
        'elapsed_execution_seconds':round(time.monotonic()-started,3),'outputs':outputs,
        'labels_accessed':False,'retries':0,'repairs':0,'resumed':False,'live_graph_changes':False,
        'preflight':raw_pin(out/'preflight.json'),'cached_original_output':p['cached_nano_partial']}
    receipt['content_sha256']=digest(receipt);write_new(out/'completion.json',receipt);return receipt


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('protocol','protocol-sha256','output','phase'):parser.add_argument('--'+key,required=True)
    args=parser.parse_args()
    if args.phase not in {'preflight','run'}:parser.error('phase must be preflight or run')
    os.umask(0o077)
    os.environ['PYSTOW_HOME']=str(ROOT/'runs/indra_grounding_runtime_20261113/resources')
    p,pins,cases,cached=load_protocol(args.protocol,args.protocol_sha256,generation=args.phase=='run')
    out=Path(args.output).resolve();out.relative_to(ROOT/'runs/final_delivery_20261117')
    with old.wall_limit(p['parameters']['max_wall_seconds']):
        try:result=(preflight if args.phase=='preflight' else execute)(out,p,args.protocol_sha256,pins,cases,cached)
        except BaseException as error:
            if out.is_dir():journal(out/'failures.jsonl',{'at':stamp(),'phase':args.phase,
                'error_type':type(error).__name__,'message':str(error),'automatic_retry_allowed':False})
            raise
    print(json.dumps({k:result[k] for k in ('status','source_rows','actual_generation_requests','new_model_requests',
        'counts','all_four_joint_eligible','content_sha256') if k in result}))


if __name__=='__main__':main()
