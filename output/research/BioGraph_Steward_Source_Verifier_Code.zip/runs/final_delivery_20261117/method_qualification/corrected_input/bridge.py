"""Private original-Evidence bridge around the unchanged author BASE method.

No prompt/native-ID mutation, new biological filter, calibration or graph edit.
Qualification is view-specific technical fidelity, never a correctness label.
"""
from copy import deepcopy
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE.parent/'larger_model'))
import qwen_converse as q

encoded,digest=q.encoded,q.digest
VIEWS={'partial','full'}


def selected_evidence(case,view):
    if view not in VIEWS:raise ValueError('Exactly partial/full input views are supported.')
    if not isinstance(case,dict) or not isinstance(case.get('statement'),dict):
        raise ValueError('An unchanged full-frame source case is required.')
    if set(case)&{'gold','label','curator_label','native_tag'} or 'belief' in case['statement']:
        raise ValueError('No labels or released belief may enter the method.')
    if digest(case['statement'])!=case.get('statement_payload_sha256'):
        raise ValueError('Original native Statement binding differs.')
    if view=='full':
        if case.get('evidence_available') is False:
            if case.get('evidence') is not None:raise ValueError('Unavailable Evidence cannot carry a replacement payload.')
            return None
        if case.get('evidence_available') is not True or not isinstance(case.get('evidence'),dict):
            raise ValueError('Original Evidence availability must be explicit.')
        evidence=deepcopy(case['evidence'])
        if digest(evidence)!=case.get('original_evidence_object_sha256'):
            raise ValueError('Original curated Evidence binding differs.')
        return evidence
    evidence=case.get('released_evidence_fields')
    if not isinstance(evidence,dict) or set(evidence)-{'text','source_api','pmid','original_source_hash'}:
        raise ValueError('Original flattened Evidence bridge fields differ.')
    if evidence.get('original_source_hash')!=case.get('source_hash'):
        raise ValueError('Opaque original source identities disagree.')
    return {k:deepcopy(v) for k,v in evidence.items() if k!='original_source_hash'}


def compare_identities(claimed,resolved,ontology):
    """Exact/shared-namespace identity proof; never infer from missing mappings.

    Avoid standardize_db_refs' isoform stripping and first-of-many mapping. No
    namespace translation, family equivalence or name-based identity is inferred.
    """
    claimed,resolved=tuple(claimed),tuple(resolved)
    if claimed==resolved:return {'status':'exact_native_identity','conflict':False}
    if claimed[0]==resolved[0]:
        return {'status':'different_shared_namespace_identity','conflict':True,
            'proof':{'namespace':claimed[0],'native':claimed[1],'author':resolved[1]}}
    if any(ns=='UP' and '-' in str(identifier) for ns,identifier in (claimed,resolved)):
        return {'status':'unresolved_specific_isoform_identity','conflict':False}
    forward={str(i) for ns,i in ontology.get_mappings(*claimed) if ns==resolved[0]}
    reverse={str(i) for ns,i in ontology.get_mappings(*resolved) if ns==claimed[0]}
    if len(forward)>1 or len(reverse)>1:
        return {'status':'unresolved_ambiguous_official_xref','conflict':False}
    if forward and str(resolved[1]) not in forward:
        return {'status':'different_shared_namespace_identity','conflict':True,
            'proof':{'namespace':resolved[0],'native':next(iter(forward)),'author':resolved[1]}}
    if reverse and str(claimed[1]) not in reverse:
        return {'status':'different_shared_namespace_identity','conflict':True,
            'proof':{'namespace':claimed[0],'native':claimed[1],'author':next(iter(reverse))}}
    if forward or reverse:return {'status':'official_unambiguous_xref','conflict':False}
    return {'status':'unresolved_cross_namespace_identity','conflict':False}


def qualify(case,view):
    """Read original inputs and established renderer; no model client is used."""
    native=q.load_native()
    from indra.statements import Evidence,SelfModification,stmt_from_json
    from indra.ontology.bio import bio_ontology
    from indra_belief.data.scoring_record import ScoringRecord
    evidence_json=selected_evidence(case,view)
    output={'view':view,'input_sha256':digest(case),'eligible':False,'technical_reasons':[],
        'identities':[],'model_requests':0,'biological_error_inferred':False,
        'context_preserved_but_not_rendered':False,'unrendered_epistemic_keys':[]}
    if evidence_json is None:
        output['technical_reasons']=['original_curated_evidence_unavailable'];return output
    statement=stmt_from_json(deepcopy(case['statement']))
    evidence=Evidence._from_json(deepcopy(evidence_json))
    if not isinstance(evidence.text,str) or not evidence.text.strip():
        output['technical_reasons'].append('no_published_source_sentence')
    output['technical_reasons'].extend(native.unsupported_claim_state(statement))
    for flag in ('hypothesis','negated'):
        if evidence.epistemics.get(flag) is True:
            output['technical_reasons'].append('unrendered_epistemics_'+flag)
    # direct=False, hedgings, section metadata and context are NOT new filters.
    output['unrendered_epistemic_keys']=sorted(evidence.epistemics)
    output['context_preserved_but_not_rendered']=bool(evidence_json.get('context'))
    raw=(evidence.annotations.get('agents') or {}).get('raw_text')
    agents=statement.agent_list()
    if raw and (any(item is None for item in raw) or agents!=statement.agent_list(deep_sorted=True)):
        output['technical_reasons'].append('raw_mention_role_alignment_unproven')
    # Do not ask the author resolver to misalign a known null/reordered span.
    if 'raw_mention_role_alignment_unproven' not in output['technical_reasons']:
        record=ScoringRecord(statement=statement,evidence=evidence)
        role_agents=[agents[0] if agents else None,
            agents[0] if isinstance(statement,SelfModification) and agents else (agents[1] if len(agents)>1 else None)]
        for role,agent,entity in zip(('subject','object'),role_agents,(record.subject_entity,record.object_entity)):
            if agent is None:continue
            claimed=agent.get_grounding()
            resolved=(entity.db,entity.db_id) if entity is not None else (None,None)
            if not all(claimed):status='native_identity_unavailable_not_contradicted'
            elif not all(resolved):status='author_identity_unavailable_no_replacement'
            else:
                comparison=compare_identities(claimed,resolved,bio_ontology)
                status=comparison['status']
                if comparison['conflict']:output['technical_reasons'].append('native_identity_conflict_in_shared_namespace')
            identity={'role':role,'native_name':agent.name,
                'native_grounding':list(claimed),'author_added_grounding':list(resolved),'status':status}
            if all(claimed) and all(resolved) and 'proof' in comparison:identity['proof']=comparison['proof']
            output['identities'].append(identity)
    output['technical_reasons']=list(dict.fromkeys(output['technical_reasons']))
    output['eligible']=not output['technical_reasons']
    output['selected_evidence_sha256']=digest(evidence_json)
    output['original_cached_evidence_source_hash']=deepcopy(evidence_json.get('source_hash'))
    # Compute on a separate copy. Never overwrite rounded original JSON fields.
    refreshed=Evidence._from_json(deepcopy(evidence_json)).get_source_hash(refresh=True)
    output['refreshed_native_source_hash']=str(refreshed)
    output['refreshed_hash_matches_curation_identity']=str(refreshed)==str(case.get('source_hash'))
    return output


def review(case,view,*,client,model_kind,qualification=None):
    """All facts and verdicts flow through unchanged public score_evidence BASE."""
    if model_kind not in {'nano','qwen'}:raise ValueError('Unknown frozen model arm.')
    original=digest(case);qualified=qualify(case,view)
    if qualification is not None and qualified!=qualification:
        raise ValueError('Original-input/native-identity qualification drifted.')
    result={'status':'abstain','verdict':None,'case_id':case['case_id'],
        'source_case_sha256':original,'source_view':view,'qualification':qualified,
        'model_requests':0,'probability':None,'native_result':None,
        'reason':None,'new_graph_decision':False,'call_log':[]}
    if not qualified['eligible']:
        result['reason']='technical_input_or_renderer_abstention'
    else:
        native=q.load_native();evidence=selected_evidence(case,view)
        result=native.review_pair(deepcopy(case['statement']),evidence,client=client,
            case_id=case['case_id'],source_identity={'matches_hash':case.get('matches_hash'),
                'original_source_hash':case.get('source_hash'),
                'original_cached_evidence_source_hash':deepcopy(evidence.get('source_hash'))},
            source_view='curated_original_evidence' if view=='full' else 'released_native_claim_and_sentence',
            variant_name='')
        result.update(source_case_sha256=original,qualification=qualified,
            source_view=view,probability=None,
            original_evidence_object_preserved=(digest(evidence)==qualified['selected_evidence_sha256']),
            original_cached_source_hash_preserved=(evidence.get('source_hash')==qualified['original_cached_evidence_source_hash']))
        # The prior bridge's unconditional False described flattened Evidence.
        # Keep exact cached and recomputed curation identities distinct here.
        result.pop('native_evidence_runtime_hash_is_released_identity',None)
    result.update(model_kind=model_kind,method='official_BASE_original_Evidence_diagnostic',
        provider_model_id=q.MODEL if model_kind=='qwen' else q.load_native().MODEL,
        endpoint_scope='consumed_reference_source_claim_agreement_not_biological_truth',
        original_case_unchanged=digest(case)==original)
    return result
