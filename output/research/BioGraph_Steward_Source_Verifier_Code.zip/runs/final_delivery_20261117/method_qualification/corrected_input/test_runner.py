"""Invented runner-boundary fixtures; no model, reference rows or label IO."""
from copy import deepcopy
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_comparison as r


class RunnerTests(unittest.TestCase):
    def test_generation_is_blocked_before_any_pin_native_or_network_load_on_draft(self):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'protocol.json'
            body={'format':r.FORMAT,'status':'ROOT_REVIEW_REQUIRED'}
            path.write_bytes(r.encoded(body))
            with patch.object(r.old,'resolve_pin',side_effect=AssertionError('No pinned input open')):
                with self.assertRaisesRegex(ValueError,'ROOT-frozen'):
                    r.load_protocol(path,r.digest(body),generation=True)

    def test_order_seed_affects_only_arm_order_and_keeps_every_source_row(self):
        cases=[{'case_id':'INVENTED_A'},{'case_id':'INVENTED_B'}]
        before=deepcopy(cases);rows=r.plan_rows(cases)
        self.assertEqual(cases,before);self.assertEqual(rows,r.plan_rows(cases))
        self.assertEqual([x['case_id'] for x in rows],['INVENTED_A']*4+['INVENTED_B']*4)
        for index in range(2):
            self.assertEqual({x['arm_id'] for x in rows[index*4:index*4+4]},set(r.ARMS))
        self.assertTrue(all('seed' not in x and 'request' not in x for x in rows))

    def test_cached_actual_tokenizer_packet_requires_original_inventory_hash(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder);(base/'preflight').mkdir();path=base/'preflight/0000_base.json'
            path.write_bytes(r.encoded({'kind':'callable','request':{'INVENTED':'ONLY'}}))
            pin=r.raw_pin(path);(base/'preflight.json').write_bytes(r.encoded({'preflight_inventory':[pin]}))
            self.assertEqual(r.cached_packet({'cached_nano_partial':base/'base.json'},0)['kind'],'callable')
            path.write_bytes(r.encoded({'kind':'technical_abstention'}))
            with self.assertRaisesRegex(ValueError,'tokenizer packet pin'):
                r.cached_packet({'cached_nano_partial':base/'base.json'},0)

    def test_render_requires_one_native_request_and_never_repairs_unknown_failure(self):
        case={'case_id':'INVENTED_ONLY'};qual={'eligible':True}
        with patch.object(r.bridge,'review',return_value={'status':'abstain','reason':'unexpected_native_error'}):
            with self.assertRaisesRegex(ValueError,'Unexpected author-native'):
                r.render(case,'full','qwen',qual)
        with patch.object(r.bridge,'review',return_value={'status':'abstain','reason':'guard'}):
            result=r.render(case,'full','qwen',{'eligible':False})
            self.assertEqual(result['kind'],'technical_abstention')

    def test_nano_tokenizer_is_exact_and_context_overflow_preserves_full_request(self):
        packet={'request':{'model':'nvidia/Llama-3.1-Nemotron-Nano-8B-v1',
            'temperature':.1,'max_tokens':1024,'messages':[{'role':'user','content':'INVENTED ONLY'}]}}
        original=deepcopy(packet['request'])
        response={'status':200,'body':{'count':16000,'max_model_len':16384,'tokens':[0]*16000}}
        with patch.object(r.q,'load_native',return_value=type('N',(),{'MODEL':packet['request']['model']})),patch.object(r.old,'http_json',return_value=response):
            r.nano_tokenize(packet,{'parameters':{'nano_endpoint':'http://127.0.0.1:18117/v1/chat/completions'}})
        self.assertEqual(packet['kind'],'context_abstention');self.assertEqual(packet['request'],original)
        self.assertEqual(packet['tokenize_response'],response)


if __name__=='__main__':unittest.main(verbosity=2)
