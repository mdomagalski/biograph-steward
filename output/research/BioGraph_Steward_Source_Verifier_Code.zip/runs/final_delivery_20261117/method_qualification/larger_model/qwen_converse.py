"""Private author-BASE adapter using existing AWSCLI login and native Converse.

No service access occurs on import. No credential is exported or returned. The
old Nano adapter and prior protocols remain byte-identical; only its native
preparation/source/state guards are reused, never its model-specific wire.
"""
from copy import deepcopy
from decimal import Decimal
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[3]
MODEL='qwen.qwen3-235b-a22b-2507-v1:0'
REGION='us-east-2'
PROFILE='biograph'
AWS='/Users/42573/.local/bin/aws'
ENDPOINT='https://bedrock-runtime.us-east-2.amazonaws.com'
CONTEXT_MAX=262144
COMPLETION_MAX=1024
INPUT_PER_TOKEN=Decimal('0.00000022')
OUTPUT_PER_TOKEN=Decimal('0.00000088')
WORST_REQUEST_USD=CONTEXT_MAX*INPUT_PER_TOKEN+COMPLETION_MAX*OUTPUT_PER_TOKEN
WIRE='official_author_system_and_messages_native_converse_v1'
NATIVE=None


def encoded(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def load_native():
    """Reuse the already qualified byte-bound native bootstrap, no new fetches."""
    global NATIVE
    if NATIVE is not None:return NATIVE
    adapter=HERE.parent/'adapter'
    for name,expected in {'nano_disconfirm.py':'7c32763ceec2157539a0d3fa3f464d1a504eab7e5a82f473c71a4c920645796f',
        'run_pair_comparison.py':'d7071b9e40e0a612fca99b616d25cfe95cd4e339a2ef2562123b049be02c5113'}.items():
        if hashlib.sha256((adapter/name).read_bytes()).hexdigest()!=expected:
            raise ValueError('Original native helper differs from its qualified pin.')
    os.environ['PYSTOW_HOME']=str(ROOT/'runs/indra_grounding_runtime_20261113/resources')
    sys.path.insert(0,str(adapter));sys.path.insert(0,str(ROOT))
    guard=importlib.import_module('run_pair_comparison')
    path=ROOT/'runs/final_delivery_20261117/protocols/primary_v2.json'
    if hashlib.sha256(path.read_bytes()).hexdigest()!='3d1c616d60ca4fea32aefc4a3490879f0a0368b3141e34834ae978989b4cd461':
        raise ValueError('Existing native bootstrap protocol differs.')
    p=json.loads(path.read_text())
    pins={key:guard.resolve_pin(p[key]) for key in ('native_ontology_cache','native_dependencies')}
    guard.verify_native_dependencies(p,pins)
    NATIVE=importlib.import_module('nano_disconfirm')
    NATIVE.verify_upstream();NATIVE.verify_grounding_resources()
    return NATIVE


class QwenSpendCap:
    """One-model sequential ledger; unknown failed calls keep their full reserve."""
    def __init__(self,usd_cap,max_requests):
        self.cap=Decimal(str(usd_cap));self.max_requests=max_requests
        if not Decimal('0')<self.cap<=Decimal('10') or type(max_requests)is not int or not 1<=max_requests<=527:
            raise ValueError('A bounded explicit provider spend/request cap is required.')
        self.requests=0;self.known_usd=Decimal('0');self.uncertain_usd=Decimal('0')
    def reserve(self):
        if self.requests>=self.max_requests or self.known_usd+self.uncertain_usd+WORST_REQUEST_USD>self.cap:
            raise ValueError('Frozen provider spend/request ceiling prevents dispatch.')
        self.requests+=1;self.uncertain_usd+=WORST_REQUEST_USD
    def settle(self,usage):
        i,o=usage.get('inputTokens'),usage.get('outputTokens')
        if type(i)is not int or type(o)is not int or not 0<=i<=CONTEXT_MAX or not 0<=o<=COMPLETION_MAX:
            raise ValueError('Actual usage is missing or exceeds the qualified provider bounds.')
        cost=i*INPUT_PER_TOKEN+o*OUTPUT_PER_TOKEN
        self.uncertain_usd-=WORST_REQUEST_USD;self.known_usd+=cost
        return str(cost)
    def snapshot(self):
        return {'usd_cap':str(self.cap),'requests_reserved':self.requests,
            'known_token_charge_usd':str(self.known_usd),'unknown_charge_reserve_usd':str(self.uncertain_usd),
            'full_context_reserve_per_request_usd':str(WORST_REQUEST_USD)}


class QwenConverseClient:
    def __init__(self,*,spend,allow_live=False,executor=None,event_callback=None):
        self.spend=spend;self.allow_live=allow_live;self.executor=executor
        self.event_callback=event_callback;self.request_count=0;self.call_log=[]
        self.model_name='biograph_qwen235_bedrock_converse_unfitted'
        self.backend='aws_cli_converse'
        self.config={'model_id':MODEL,'max_tokens':COMPLETION_MAX,'timeout':150,'supports_logprobs':False}
        # Compatibility with the unchanged source/state preparation helper.
        self.transport=None if executor is None else executor
    def pop_call_log(self):
        rows,self.call_log=self.call_log,[];return rows
    def prepare(self,system,messages,max_tokens=None,temperature=.1,response_format=None,
                reasoning_effort=None,kind='unknown',top_logprobs=None):
        if not isinstance(system,str) or not system or not isinstance(messages,list) or not messages:
            raise ValueError('The exact author policy and ordered messages are required.')
        if response_format is not None or reasoning_effort is not None or top_logprobs is not None:
            raise ValueError('No extra schema/reasoning/probe settings are qualified.')
        if temperature!=.1 or (max_tokens is not None and max_tokens!=COMPLETION_MAX):
            raise ValueError('Only the frozen author temperature and completion cap are qualified.')
        for index,message in enumerate(messages):
            if (not isinstance(message,dict) or set(message)!={'role','content'}
                    or message['role']!=('user' if index%2==0 else 'assistant')
                    or not isinstance(message['content'],str)):
                raise ValueError('Unsupported original author message shape/order.')
        body={'modelId':MODEL,'system':[{'text':system}],
            'messages':[{'role':m['role'],'content':[{'text':m['content']}]} for m in messages],
            'inferenceConfig':{'temperature':.1,'maxTokens':COMPLETION_MAX}}
        if len(encoded(body))>65536:
            raise ValueError('Full native request exceeds the fixed conservative64KiB input bound; never truncate.')
        return body
    def call(self,system,messages,max_tokens=None,temperature=.1,response_format=None,
             reasoning_effort=None,kind='unknown',top_logprobs=None):
        native=load_native()
        body=self.prepare(system,messages,max_tokens,temperature,response_format,reasoning_effort,kind,top_logprobs)
        if self.executor is None and not self.allow_live:
            raise ValueError('Actual Bedrock inference requires separate explicit GO.')
        self.spend.reserve()
        trace={'provider_kind':'injected_test_model' if self.executor else 'live_bedrock',
            'model_id':MODEL,'region':REGION,'wire_profile':WIRE,'kind':kind,
            'author_system':system,'author_messages':deepcopy(messages),'request':body,
            'request_sha256':digest(body),'status':'request_intent','retries':0,'repairs':0,
            'reserved_worst_case_usd':str(WORST_REQUEST_USD)}
        if self.event_callback:self.event_callback(deepcopy(trace))
        self.request_count+=1;started=time.monotonic()
        try:
            if self.executor:
                raw=self.executor(deepcopy(body))
            else:
                environment=dict(os.environ)
                environment.update(AWS_MAX_ATTEMPTS='1',AWS_RETRY_MODE='standard',AWS_PAGER='',AWS_CLI_AUTO_PROMPT='off')
                # Explicit profile login, not a bearer key or exported key pair.
                for key in ('AWS_BEARER_TOKEN_BEDROCK','AWS_ACCESS_KEY_ID','AWS_SECRET_ACCESS_KEY','AWS_SESSION_TOKEN'):
                    environment.pop(key,None)
                # AWSCLI2.40 does not support cli-input-json stdin (#5982).
                # Its documented file:// path preserves exact request bytes.
                owned=HERE/'transport_inputs';owned.mkdir(mode=0o700,exist_ok=True)
                if owned.is_symlink() or not owned.is_dir():raise ValueError('Owned transport directory is required.')
                descriptor,temporary=tempfile.mkstemp(prefix='converse-',suffix='.json',dir=owned)
                request_path=Path(temporary)
                try:
                    with os.fdopen(descriptor,'wb') as stream:
                        stream.write(encoded(body));stream.flush();os.fsync(stream.fileno())
                    trace['transport_input']={'kind':'documented_file_url','mode':'0600',
                        'sha256':hashlib.sha256(request_path.read_bytes()).hexdigest(),'bytes':request_path.stat().st_size}
                    command=[AWS,'--profile',PROFILE,'--region',REGION,'--no-cli-pager','--no-cli-auto-prompt','--output','json',
                        '--cli-connect-timeout','10','--cli-read-timeout','120','--endpoint-url',ENDPOINT,
                        'bedrock-runtime','converse','--cli-input-json','file://'+str(request_path)]
                    result=subprocess.run(command,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                        env=environment,timeout=150,check=False)
                finally:
                    request_path.unlink()
                    if 'transport_input' in trace:trace['transport_input']['temporary_file_removed']=True
                if result.returncode:
                    # Error classification/bytehash only: no credential material
                    # or untrusted stderr text enters stdout or saved receipts.
                    match=re.search(rb'\(([A-Za-z][A-Za-z0-9]+(?:Exception|Error))\)',result.stderr)
                    trace.update(cli_returncode=result.returncode,stderr_bytes=len(result.stderr),
                        stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
                        aws_error_class=match.group(1).decode() if match else 'unclassified_cli_error')
                    raise RuntimeError('AWSCLI Converse failed; no retry is permitted.')
                if len(result.stdout)>1_000_000:raise ValueError('Bounded provider response exceeded one megabyte.')
                raw=json.loads(result.stdout)
            trace.update(response=deepcopy(raw),response_sha256=digest(raw),
                         latency_ms=round((time.monotonic()-started)*1000,3))
            if not isinstance(raw,dict):raise ValueError('Expected one actual AWS response object.')
            trace['actual_token_charge_usd']=self.spend.settle(raw.get('usage') or {})
            if raw.get('stopReason')!='end_turn':raise ValueError('Only end_turn qualifies; truncation/filtering abstains.')
            message=raw.get('output',{}).get('message',{})
            blocks=message.get('content')
            if message.get('role')!='assistant' or not isinstance(blocks,list) or not blocks:
                raise ValueError('Expected native assistant text blocks.')
            if any(not isinstance(b,dict) or set(b)!={'text'} or not isinstance(b['text'],str) for b in blocks):
                raise ValueError('Unsupported non-text model output; never discard or repair it.')
            content='\n'.join(b['text'] for b in blocks)
            trace.update(status='response_received',spend=self.spend.snapshot())
            self.call_log.append(trace)
            if self.event_callback:self.event_callback(deepcopy(trace))
            return native.ModelResponse(content=content,reasoning='',raw_text=content,
                tokens=raw['usage']['outputTokens'],prompt_tokens=raw['usage']['inputTokens'],finish_reason='stop')
        except Exception as error:
            trace.update(status='model_error',error_type=type(error).__name__,
                latency_ms=round((time.monotonic()-started)*1000,3),spend=self.spend.snapshot())
            self.call_log.append(trace)
            if self.event_callback:self.event_callback(deepcopy(trace))
            raise


def review_released_case(case,*,client):
    """Reuse unchanged source/state/native-author BASE path; truthful model label."""
    native=load_native()
    result=native.review_released_case(case,client=client,variant_name='')
    result.update(method='official_base_unfitted_qwen235_bedrock_converse',model_id=MODEL,
        provider_kind='injected_test_model' if client.executor else 'live_bedrock',
        wire_profile=WIRE,probability=None,comparison_scope='consumed_reference_diagnostic_under_partial_Evidence')
    return result
