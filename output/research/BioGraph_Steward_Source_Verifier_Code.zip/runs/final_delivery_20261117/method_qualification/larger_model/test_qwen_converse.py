"""Invented-only CLI/native-parser fixtures. No model/network calls."""
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parent))
import qwen_converse as q


def reply(stop='end_turn'):
    return {'output':{'message':{'role':'assistant','content':[{'text':
        '{"verdict":"correct","confidence":"medium"}'}]}},'stopReason':stop,
        'usage':{'inputTokens':2345,'outputTokens':22,'totalTokens':2367},
        'ResponseMetadata':{'RequestId':'INVENTED_REQUEST_ID_ONLY'}}


class QwenTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.native=q.load_native()
        from indra.statements import Activation,Agent
        cls.claim=Activation(Agent('InventedP1'),Agent('InventedP2')).to_json()
        cls.claim.pop('belief',None)
        from indra_belief.data.entity import GroundedEntity
        cls.Entity=GroundedEntity

    def setUp(self):
        self.network=patch('socket.create_connection',side_effect=AssertionError('No network in fixtures'))
        self.network.start()
        self.grounding=patch.object(self.Entity,'resolve',side_effect=lambda name,raw_text=None:
            self.Entity(name=name,raw_text=raw_text,canonical=name));self.grounding.start()
        self.case={'case_id':'invented-qwen-fixture','statement':deepcopy(self.claim),
            'matches_hash':'INVENTED_MATCH','source_hash':'INVENTED_SOURCE',
            'evidence':{'text':'InventedP1 activates InventedP2.','source_api':'invented',
                        'pmid':'00000000','original_source_hash':'INVENTED_SOURCE'}}
    def tearDown(self):self.grounding.stop();self.network.stop()

    def client(self,**kwargs):
        return q.QwenConverseClient(spend=q.QwenSpendCap('.20',2),**kwargs)

    def test_native_author_base_all14_examples_and_original_system_preserved(self):
        captured=[]
        def execute(body):captured.append(body);return reply()
        result=q.review_released_case(self.case,client=self.client(executor=execute))
        self.assertEqual(result['status'],'completed');self.assertEqual(result['verdict'],'correct')
        self.assertEqual(result['source_case_sha256'],q.digest(self.case))
        self.assertEqual(result['model_id'],q.MODEL);self.assertNotIn('nano8b',result['method'])
        self.assertIsNone(result['native_result']['score'])
        self.assertIsNone(result['native_result']['weight_of_evidence'])
        trace=result['call_log'][0];body=captured[0]
        self.assertEqual(body['system'],[{'text':self.native.VARIANTS[''].system_prompt}])
        self.assertEqual(body['messages'],[{'role':m['role'],'content':[{'text':m['content']}]} for m in trace['author_messages']])
        self.assertEqual(len(body['messages']),29)
        self.assertEqual(len(result['native_result']['selected_example_ids']),14)
        self.assertNotIn('detailed thinking off',json.dumps(body))
        self.assertEqual(body['inferenceConfig'],{'temperature':.1,'maxTokens':1024})
        self.assertTrue(result['original_case_unchanged'])

    def test_fixed_cli_private_file_auth_no_retries_and_intent_precedes_dispatch(self):
        events=[];raw=reply();temporary=[]
        def execute(command,**kwargs):
            self.assertEqual(events[0]['status'],'request_intent')
            self.assertIn('--no-cli-auto-prompt',command)
            self.assertEqual(command[-2],'--cli-input-json')
            self.assertTrue(command[-1].startswith('file://'))
            path=Path(command[-1][7:]);temporary.append(path)
            self.assertEqual(path.stat().st_mode&0o777,0o600)
            self.assertEqual(path.parent,q.HERE/'transport_inputs')
            self.assertEqual(kwargs['stdin'],subprocess.DEVNULL)
            self.assertEqual(kwargs['env']['AWS_MAX_ATTEMPTS'],'1')
            self.assertEqual(kwargs['env']['AWS_CLI_AUTO_PROMPT'],'off')
            self.assertNotIn('AWS_BEARER_TOKEN_BEDROCK',kwargs['env'])
            self.assertNotIn('AWS_ACCESS_KEY_ID',kwargs['env'])
            self.assertEqual(json.loads(path.read_bytes())['modelId'],q.MODEL)
            return SimpleNamespace(returncode=0,stdout=json.dumps(raw).encode(),stderr=b'')
        client=self.client(allow_live=True,event_callback=events.append)
        with patch('qwen_converse.subprocess.run',side_effect=execute):
            result=q.review_released_case(self.case,client=client)
        self.assertEqual(result['status'],'completed');self.assertEqual(client.request_count,1)
        self.assertEqual(events[-1]['response'],raw)
        self.assertEqual(events[-1]['status'],'response_received')
        self.assertFalse(temporary[0].exists())
        self.assertTrue(events[-1]['transport_input']['temporary_file_removed'])
        self.assertLess(float(client.spend.snapshot()['known_token_charge_usd']),.20)

    def test_truncation_and_missing_usage_abstain_without_response_repair(self):
        for raw in [reply('max_tokens'),{**reply(),'usage':{}}]:
            with self.subTest(stop=raw['stopReason']):
                client=self.client(executor=lambda body:raw)
                result=q.review_released_case(self.case,client=client)
                self.assertEqual(result['status'],'abstain');self.assertIsNone(result['verdict'])
                self.assertEqual(client.request_count,1)
                self.assertEqual(result['call_log'][0]['response'],raw)
                self.assertEqual(result['call_log'][0]['status'],'model_error')

    def test_credential_error_has_only_error_hash_and_class_not_secret_stderr(self):
        client=self.client(allow_live=True)
        with patch('qwen_converse.subprocess.run',return_value=SimpleNamespace(
                returncode=255,stdout=b'',stderr=b'An error (AccessDeniedException) DUMMY_NEVER_SAVE_SECRET')):
            result=q.review_released_case(self.case,client=client)
        self.assertEqual(result['status'],'abstain');self.assertEqual(client.request_count,1)
        self.assertNotIn('DUMMY_NEVER_SAVE_SECRET',json.dumps(result))
        self.assertEqual(result['call_log'][0]['aws_error_class'],'AccessDeniedException')
        self.assertEqual(client.spend.uncertain_usd,q.WORST_REQUEST_USD)

    def test_budget_conservative_unknown_reserve_and_live_default_disabled(self):
        cap=q.QwenSpendCap('.10',2);cap.reserve()
        with self.assertRaises(ValueError):cap.reserve()
        client=self.client()
        with patch('qwen_converse.subprocess.run') as process:
            result=q.review_released_case(self.case,client=client)
        self.assertEqual(result['status'],'abstain');self.assertEqual(client.request_count,0)
        process.assert_not_called()

    def test_unsupported_native_condition_retained_with_zero_calls(self):
        from indra.statements import Activation,Agent,ModCondition
        st=Activation(Agent('InventedP1',mods=[ModCondition('phosphorylation')]),Agent('InventedP2')).to_json();st.pop('belief',None)
        self.case['statement']=st;calls=[]
        client=self.client(executor=lambda b:calls.append(b))
        result=q.review_released_case(self.case,client=client)
        self.assertEqual(result['status'],'abstain');self.assertEqual(result['model_requests'],0)
        self.assertEqual(calls,[]);self.assertEqual(result['source_case_sha256'],q.digest(self.case))

if __name__=='__main__':unittest.main(verbosity=2)
