"""Invented, stdlib-only orchestration fixtures; no model/network/labels."""
from copy import deepcopy
import importlib.util
import json
import os
from pathlib import Path
import signal
import tempfile
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pair_runner',HERE/'run_pair_comparison.py')
r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)

class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(dir=HERE,prefix='invented_runner_')
        self.root=Path(self.tmp.name)
        self.cases=[{'case_id':'invented-'+str(n),'statement':{'type':'Activation'},
            'evidence':{'text':'Invented sentence '+str(n)}} for n in range(2)]
        self.protocol={'source_cases':{'sha256':'f'*64},'parameters':{
            'seed':20261117,'max_model_requests':4,'endpoint':'http://127.0.0.1:18117/v1/chat/completions'}}
        self.adapter=SimpleNamespace(MODEL='invented_model',verify_grounding_resources=lambda:[])
        self.calls=[]
        def client(**kwargs):
            return SimpleNamespace(**kwargs)
        def review(case,*,client,variant_name):
            payload={'temperature':.1,'max_tokens':1024,'messages':[
                {'role':'system','content':'invented'}]+[{'role':'user','content':'invented'}]*29}
            result={'source_case_sha256':r.digest(case),'original_case_unchanged':True,
                    'status':'abstain','verdict':None,'reason':None,'model_requests':0}
            if getattr(client,'token_counter',None) and client.token_counter(payload)+1024>16384:
                return {**result,'reason':'method_or_transport_error'}
            if getattr(client,'transport',None):
                try:client.transport(payload)
                except Exception:pass
                return result
            self.assertEqual(client.token_counter(payload),20)
            client.event_callback({'status':'request_intent','request':payload})
            # Full durable request intent must already be in the on-disk log.
            log=(self.output/'execution_events.jsonl').read_text()
            self.assertIn('request_intent',log)
            self.calls.append((case['case_id'],variant_name))
            client.event_callback({'status':'response_received','response':{'invented':True}})
            return {**result,'status':'completed','verdict':'correct','model_requests':1}
        self.adapter.NanoClient=client;self.adapter.review_released_case=review
        self.output=self.root/'output'
        self.http=patch.object(r,'http_json',return_value={'status':200,'body':{
            'count':20,'max_model_len':16384,'tokens':list(range(20))}})
        self.model=patch.object(r,'model_preflight',return_value=[])
        self.load=patch.object(r,'load_protocol',return_value=(self.protocol,{},self.cases))
        for obj in (self.http,self.model,self.load):obj.start()

    def tearDown(self):
        for obj in (self.load,self.model,self.http):obj.stop()
        self.tmp.cleanup()

    def prepare(self):
        return r.preflight(self.output,self.protocol,'a'*64,{'protocol':self.root/'protocol'},self.cases,self.adapter)

    def test_seed_only_interleaves_arms_preserving_original_case_order(self):
        first=r.plan_rows(self.cases,20261117)
        self.assertEqual(first,r.plan_rows(self.cases,20261117))
        self.assertEqual([x['case_id'] for x in first],['invented-0']*2+['invented-1']*2)
        for offset in (0,2):
            self.assertEqual({x['arm_id'] for x in first[offset:offset+2]},{'base','disconfirm'})

    def test_preflight_has_no_generation_and_execute_seals_allarms_after_durable_intents(self):
        summary=self.prepare()
        self.assertEqual(self.calls,[])
        self.assertEqual(summary['counts']['tokenized'],4)
        self.assertEqual(summary['counts']['actual_generation_requests'],0)
        receipt=r.execute(self.output,self.protocol,'a'*64,{'protocol':self.root/'protocol'},self.cases,self.adapter)
        self.assertEqual(receipt['model_requests'],4)
        for name in ('base','disconfirm','retain_all'):
            obj=json.loads((self.output/(name+'.json')).read_text());seal=obj.pop('content_sha256')
            self.assertEqual(r.digest(obj),seal)
            self.assertEqual(len(obj['rows']),2)
            for row,case in zip(obj['rows'],self.cases):
                self.assertEqual(row['input_sha256'],r.digest(case))
                self.assertEqual(row['proposal'],'support')
        with self.assertRaises(FileExistsError):
            r.execute(self.output,self.protocol,'a'*64,{'protocol':self.root/'protocol'},self.cases,self.adapter)
        self.assertEqual(len(self.calls),4)

    def test_modified_preflight_packet_cannot_authorize_generation(self):
        self.prepare()
        p=next((self.output/'preflight').glob('*.json'));p.write_text(p.read_text()+' ')
        with self.assertRaises(ValueError):
            r.execute(self.output,self.protocol,'a'*64,{'protocol':self.root/'protocol'},self.cases,self.adapter)
        self.assertEqual(self.calls,[])
        self.assertFalse((self.output/'run_started.json').exists())

    def test_unknown_interrupted_run_is_never_retried(self):
        self.prepare()
        r.write_new(self.output/'run_started.json',{'at':'invented-interrupted','request_status':'unknown'})
        with self.assertRaises(FileExistsError):
            r.execute(self.output,self.protocol,'a'*64,{'protocol':self.root/'protocol'},self.cases,self.adapter)
        self.assertEqual(self.calls,[])

    def test_full_overcontext_requests_remain_in_allarm_denominators_without_generation(self):
        with patch.object(r,'http_json',return_value={'status':200,'body':{
                'count':16300,'max_model_len':16384,'tokens':list(range(16300))}}):
            summary=self.prepare()
        self.assertEqual(summary['counts']['context_abstentions'],4)
        self.assertEqual(summary['counts']['actual_generation_requests'],0)
        receipt=r.execute(self.output,self.protocol,'a'*64,{'protocol':self.root/'protocol'},self.cases,self.adapter)
        self.assertEqual(receipt['model_requests'],0)
        self.assertEqual(self.calls,[])
        for arm in ('base','disconfirm'):
            rows=json.loads((self.output/(arm+'.json')).read_text())['rows']
            self.assertEqual(len(rows),len(self.cases))
            self.assertTrue(all(row['proposal']=='abstain' for row in rows))

    def test_deadline_escapes_ordinary_adapter_exception_to_abstain_boundary(self):
        with self.assertRaises(BaseException) as raised:
            with r.wall_limit(1):
                try:time.sleep(2)
                except Exception:self.fail('Whole-run deadline must not become one row abstention.')
        self.assertNotIsInstance(raised.exception,Exception)

    def native_fixture(self):
        base=self.root/'native_resources';cache=base/'bio_ontology/1.34/bio_ontology.pkl'
        cache.parent.mkdir(parents=True);cache.write_bytes(b'invented native cache, never unpickled')
        member=self.root/'invented_dependency.py';member.write_text('# invented fixed resource\n')
        inventory={'INDRA_version':'1.24.0','BioOntology_version':'1.34',
            'ProtMapper_version':'0.0.29','Gilda_version':'1.6.1',**{name:[r.raw_pin(member)] for name in
            ('installed_INDRA_resources','installed_native_python','ProtMapper_dependency_resources','third_party_notices')}}
        path=self.root/'inventory.json';r.write_new(path,inventory)
        protocol={'parameters':{'indra_resources':str(base.relative_to(r.ROOT))},
            'native_ontology_cache':r.raw_pin(cache),'native_dependencies':r.raw_pin(path)}
        return base,cache,member,protocol,{'native_ontology_cache':cache,'native_dependencies':path}

    def test_native_cache_and_resource_byte_tampering_fail_before_import_or_network(self):
        base,cache,member,protocol,pins=self.native_fixture()
        with patch.object(r,'NATIVE_RESOURCE_RELATIVE',str(base.relative_to(r.ROOT))),patch.dict(os.environ):
            os.environ.pop('INDRA_RESOURCES',None)
            self.assertEqual(r.verify_native_dependencies(protocol,pins),base)
            self.assertEqual(os.environ['INDRA_RESOURCES'],str(base))
            old=member.stat();member.write_text('# changed fixed resource\n');os.utime(member,ns=(old.st_atime_ns,old.st_mtime_ns))
            with self.assertRaises(ValueError):r.verify_native_dependencies(protocol,pins)
            member.write_text('# invented fixed resource\n')
            cache.write_bytes(b'changed cache')
            with self.assertRaises(ValueError):r.verify_native_dependencies(protocol,pins)
        self.assertEqual(self.calls,[])

    def test_missing_native_cache_or_conflicting_environment_cannot_bootstrap(self):
        base,cache,member,protocol,pins=self.native_fixture()
        with patch.object(r,'NATIVE_RESOURCE_RELATIVE',str(base.relative_to(r.ROOT))),patch.dict(os.environ):
            os.environ['INDRA_RESOURCES']=str(self.root/'incorrect_native_cache')
            with self.assertRaises(ValueError):r.verify_native_dependencies(protocol,pins)
            os.environ.pop('INDRA_RESOURCES')
            cache.unlink()
            with self.assertRaises(ValueError):r.verify_native_dependencies(protocol,pins)
            self.assertNotIn('INDRA_RESOURCES',os.environ)
        self.assertEqual(self.calls,[])

if __name__=='__main__':
    unittest.main(verbosity=2)
