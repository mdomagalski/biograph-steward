"""Private frozen paired runner. No labels interface, retries, repair or resumption.

Preflight executes native rendering with an injected transport that always stops
before generation, then measures the exact messages at the real /tokenize route.
A separate explicit --phase run is required after every row is preflighted.
"""
from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import random
import signal
import sys
import time
from urllib.error import HTTPError
from urllib.request import Request, ProxyHandler, build_opener

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
FORMAT = 'biograph-steward.official-pair-comparison.v1'
ARM_VARIANTS = {'base': '', 'disconfirm': 'disconfirm'}
NATIVE_RESOURCE_RELATIVE = 'runs/indra_grounding_runtime_20261113/native_ontology_20261117'


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def raw_pin(path):
    path = Path(path)
    if path.is_symlink() or not path.is_file():
        raise ValueError('Expected a nonsymlink regular pinned file.')
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def stamp():
    return datetime.now(timezone.utc).isoformat()


def sync_directory(path):
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_new(path, value):
    path = Path(path)
    with path.open('xb') as stream:
        stream.write(encoded(value) + b'\n');stream.flush();os.fsync(stream.fileno())
    sync_directory(path.parent)


def journal(path, value):
    descriptor = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    with os.fdopen(descriptor, 'ab') as stream:
        stream.write(encoded(value) + b'\n');stream.flush();os.fsync(stream.fileno())
    sync_directory(Path(path).parent)


def resolve_pin(pin):
    if not isinstance(pin, dict) or set(pin) != {'path', 'bytes', 'sha256'}:
        raise ValueError('Expected explicit path/bytes/rawSHA256 protocol pin.')
    path = Path(pin['path'])
    if not path.is_absolute():
        path = ROOT / path
    path = path.absolute()
    relative = path.relative_to(ROOT)
    if any(part.is_symlink() for part in [path, *list(path.parents)[:len(relative.parts)]]):
        raise ValueError('Pinned inputs may not traverse symbolic links.')
    path = path.resolve();path.relative_to(ROOT)
    actual = raw_pin(path)
    if actual['bytes'] != pin['bytes'] or actual['sha256'] != pin['sha256']:
        raise ValueError('Frozen input/code pin differs: ' + str(path.relative_to(ROOT)))
    return path


def verify_native_dependencies(protocol, pins):
    """Verify native resources before any INDRA import can trigger bootstrap."""
    for key in ('native_ontology_cache', 'native_dependencies'):
        if resolve_pin(protocol[key]) != pins[key]:
            raise ValueError('Imported native dependency path differs from its frozen pin.')
    relative = protocol['parameters'].get('indra_resources')
    if relative != NATIVE_RESOURCE_RELATIVE:
        raise ValueError('Use the exact separately qualified owned INDRA resource base.')
    base = ROOT / relative
    if not base.is_dir() or any(p.is_symlink() for p in [base, *list(base.parents)[:len(Path(relative).parts)]]):
        raise ValueError('The native resource base must exist without symbolic links.')
    if pins['native_ontology_cache'] != base / 'bio_ontology/1.34/bio_ontology.pkl':
        raise ValueError('Native cache pin does not match the configured BioOntology1.34 path.')
    inventory = json.loads(pins['native_dependencies'].read_text())
    for key, value in {'INDRA_version': '1.24.0', 'BioOntology_version': '1.34',
                       'ProtMapper_version': '0.0.29', 'Gilda_version': '1.6.1'}.items():
        if inventory.get(key) != value:
            raise ValueError('Native dependency inventory version differs: ' + key)
    for category in ('installed_INDRA_resources', 'installed_native_python',
                     'ProtMapper_dependency_resources', 'third_party_notices'):
        if not inventory.get(category):
            raise ValueError('Native dependency inventory category is missing: ' + category)
        for member in inventory[category]:
            resolve_pin({key: member[key] for key in ('path', 'bytes', 'sha256')})
    configured = os.environ.get('INDRA_RESOURCES')
    if configured is not None and configured != str(base):
        raise ValueError('Existing INDRA_RESOURCES conflicts with the frozen owned native cache.')
    os.environ['INDRA_RESOURCES'] = str(base)
    return base


def load_protocol(path, expected_sha):
    if len(expected_sha) != 64 or any(c not in '0123456789abcdef' for c in expected_sha):
        raise ValueError('An explicit lowercase raw protocol SHA256 is required.')
    raw = Path(path).read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha:
        raise ValueError('Root-frozen raw protocol hash differs.')
    protocol = json.loads(raw)
    if protocol.get('format') != FORMAT:
        raise ValueError('Unknown fixed comparison protocol.')
    pins = {key: resolve_pin(protocol[key]) for key in
            ('source_cases', 'adapter', 'runner', 'upstream_manifest', 'readiness',
             'native_ontology_cache', 'native_dependencies')}
    for pin in protocol.get('code_files', []):
        resolve_pin(pin)
    if pins['adapter'] != HERE / 'nano_disconfirm.py' or pins['runner'] != Path(__file__).resolve():
        raise ValueError('The invoked runner/adapter is not the protocol-pinned code.')
    if pins['upstream_manifest'] != HERE / 'upstream_manifest.json':
        raise ValueError('The imported upstream manifest differs from the frozen pin.')
    parameters = protocol['parameters']
    required = {'model_id': 'nvidia/Llama-3.1-Nemotron-Nano-8B-v1',
        'model_revision': '54641c1611fcff44fa4865626462445e0a153fc7',
        'wire_profile': 'author_policy_prefixed_to_first_user_nano8b_v2',
        'temperature': .1, 'max_output_tokens': 1024, 'max_context_tokens': 16384,
        'seed': 20261117, 'endpoint': 'http://127.0.0.1:18117/v1/chat/completions'}
    for key, value in required.items():
        if parameters.get(key) != value or (isinstance(value, int) and type(parameters.get(key)) is not int):
            raise ValueError('Frozen parameter differs from qualified method: ' + key)
    count = protocol['expected_case_count']
    if type(count) is not int or not 1 <= count <= 382:
        raise ValueError('Unexpected bounded source-frame size.')
    if type(parameters.get('max_model_requests')) is not int or parameters['max_model_requests'] != 2 * count:
        raise ValueError('Exactly one request maximum per source row and author arm is required.')
    if type(parameters.get('max_wall_seconds')) is not int or not 1 <= parameters['max_wall_seconds'] <= 10800:
        raise ValueError('Whole-run wall budget must be at most three hours.')
    if protocol['arms'] != [{'arm_id': name, 'variant_name': value} for name, value in ARM_VARIANTS.items()]:
        raise ValueError('Only the frozen official base/disconfirm arms are accepted.')
    cases = [json.loads(line) for line in pins['source_cases'].read_text().splitlines() if line.strip()]
    if len(cases) != count or len({case['case_id'] for case in cases}) != count:
        raise ValueError('Source-frame count/unique identities differ from protocol.')
    if any(not isinstance(case.get('case_id'), str) or not case['case_id']
           or set(case) & {'gold', 'label', 'curator_label', 'target', 'native_tag'} for case in cases):
        raise ValueError('Use the label-free unique case frame, never a label file.')
    readiness = json.loads(pins['readiness'].read_text())
    if (readiness['model_id'] != required['model_id']
            or readiness['model_revision'] != required['model_revision']
            or readiness['tokenizer_revision'] != required['model_revision']
            or readiness['vllm_version'] != '0.8.5'
            or readiness['max_model_len'] != required['max_context_tokens']):
        raise ValueError('Runtime readiness does not bind the qualified actual model.')
    for name, expected in {'indra': '1.24.0', 'gilda': '1.6.1'}.items():
        if importlib.metadata.version(name) != expected:
            raise ValueError('Optional native dependency version differs: ' + name)
    verify_native_dependencies(protocol, pins)
    return protocol, pins, cases


def plan_rows(cases, seed):
    # Original source case order remains stable; only which arm is first within
    # each pair is randomized. No seed is added to the original model payload.
    rng = random.Random(seed); rows = []
    for index, case in enumerate(cases):
        arms = list(ARM_VARIANTS);rng.shuffle(arms)
        rows.extend({'index': index, 'case_id': case['case_id'], 'arm_id': arm,
                     'variant_name': ARM_VARIANTS[arm], 'input_sha256': digest(case),
                     'stem': f'{index:04d}_{arm}'} for arm in arms)
    return rows


@contextmanager
def wall_limit(seconds):
    class RunDeadline(BaseException):
        pass
    def expired(signum, frame):
        # Adapter row errors deliberately abstain. Deadline cancellation must
        # escape that Exception boundary and terminate the whole one-pass run.
        raise RunDeadline('Frozen whole-run wall budget expired; never retry unresolved requests.')
    old = signal.signal(signal.SIGALRM, expired);signal.alarm(seconds)
    try:
        yield
    finally:
        signal.alarm(0);signal.signal(signal.SIGALRM, old)


def http_json(endpoint, body=None, timeout=60):
    from biograph_steward.model_transport import _NoRedirect
    request = Request(endpoint, data=None if body is None else encoded(body),
                      headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
    try:
        with build_opener(_NoRedirect(), ProxyHandler({})).open(request, timeout=timeout) as response:
            status = response.status; raw = response.read(1_000_001)
    except HTTPError as error:
        status = error.code; raw = error.read(1_000_001);error.close()
    if len(raw) > 1_000_000:
        raise ValueError('Bounded model metadata/tokenizer response exceeded one megabyte.')
    return {'status': status, 'body': json.loads(raw)}


def model_preflight(out, phase, protocol, adapter):
    result = http_json(protocol['parameters']['endpoint'].replace('/chat/completions', '/models'))
    write_new(out / (phase + '_model_metadata.json'), result)
    if result['status'] != 200 or not any(
            model.get('id') == adapter.MODEL for model in result['body'].get('data', [])):
        raise ValueError('Actual loopback server does not advertise the frozen model.')
    return adapter.verify_grounding_resources()


def preflight(out, protocol, protocol_sha, pins, cases, adapter):
    out.mkdir(exist_ok=False)
    (out / 'preflight').mkdir()
    sync_directory(out.parent);sync_directory(out)
    rows = plan_rows(cases, protocol['parameters']['seed'])
    order = {'protocol_sha256': protocol_sha, 'source_cases_sha256': protocol['source_cases']['sha256'],
             'ordering_seed_only': protocol['parameters']['seed'], 'case_order': 'unchanged source-file order', 'rows': rows}
    write_new(out / 'order.json', order)
    counts = {'tokenized': 0, 'technical_abstentions': 0, 'context_abstentions': 0,
              'deterministic_native_decisions': 0,
              'source_rows': len(cases), 'arm_rows': len(rows), 'actual_generation_requests': 0}
    resources = model_preflight(out, 'preflight', protocol, adapter)
    max_prompt = 0
    class RenderOnly(Exception):
        pass
    for row in rows:
        case = cases[row['index']];captured = []
        def stop(payload):
            captured.append(deepcopy(payload));raise RenderOnly('Native rendering only; generation is disabled.')
        client = adapter.NanoClient(transport=stop, max_tokens=1024)
        result = adapter.review_released_case(case, client=client, variant_name=row['variant_name'])
        packet = {**row, 'protocol_sha256': protocol_sha, 'source_case_sha256': digest(case),
                  'actual_generation_requests': 0}
        if captured:
            if len(captured) != 1:
                raise ValueError('Author arm attempted more than one scoring request.')
            payload = captured[0]
            if payload['temperature'] != .1 or payload['max_tokens'] != 1024 or len(payload['messages']) != 30:
                raise ValueError('Rendered native method differs from the frozen qualified wire.')
            token_body = {'model': adapter.MODEL, 'messages': payload['messages'], 'add_generation_prompt': True}
            journal(out / 'preflight_events.jsonl', {'at': stamp(), 'kind': 'tokenize_intent',
                'stem': row['stem'], 'request_sha256': digest(token_body), 'actual_generation_requests': 0})
            tokenized = http_json(protocol['parameters']['endpoint'].replace('/v1/chat/completions', '/tokenize'), token_body)
            packet.update(request=payload, request_sha256=digest(payload), tokenize_request=token_body,
                          tokenize_response=tokenized, kind='callable')
            count = tokenized['body'].get('count')
            if (tokenized['status'] != 200 or type(count) is not int or count <= 0
                    or tokenized['body'].get('max_model_len') != 16384
                    or len(tokenized['body'].get('tokens', [])) != count):
                write_new(out / 'preflight' / (row['stem'] + '.json'), packet)
                raise ValueError('The complete author messages fail actual-server context preflight.')
            if count + 1024 > 16384:
                packet.update(kind='context_abstention',
                              technical_reason='full_native_prompt_exceeds_context_no_truncation')
                counts['context_abstentions'] += 1;counts['technical_abstentions'] += 1
            write_new(out / 'preflight' / (row['stem'] + '.json'), packet)
            max_prompt = max(max_prompt, count);counts['tokenized'] += 1
        else:
            if result['status'] == 'completed' and result['verdict'] in {'correct', 'incorrect'}:
                packet.update(kind='deterministic_native_decision', native_result=result)
                counts['deterministic_native_decisions'] += 1
            elif result.get('reason') in {'author_renderer_cannot_express_all_conditions',
                    'no_published_source_sentence', 'raw_mention_role_alignment_unproven'}:
                packet.update(kind='technical_abstention', native_result=result)
                counts['technical_abstentions'] += 1
            else:
                write_new(out / 'preflight' / (row['stem'] + '.json'), {**packet, 'render_failure': result})
                raise ValueError('Unexpected native rendering failure; no generation is authorized.')
            write_new(out / 'preflight' / (row['stem'] + '.json'), packet)
    # Reverify complete frozen inputs after all rendering, before enabling run.
    load_protocol(pins['protocol'], protocol_sha)
    summary = {'status': 'passed', 'protocol_sha256': protocol_sha,
        'source_cases_sha256': protocol['source_cases']['sha256'], 'order_sha256': digest(order),
        'counts': counts, 'max_prompt_tokens': max_prompt, 'max_output_tokens': 1024,
        'context_limit': 16384, 'grounding_resources': resources, 'finished_at': stamp(),
        'preflight_inventory': [raw_pin(out / 'preflight' / (row['stem'] + '.json')) for row in rows]}
    summary['content_sha256'] = digest(summary);write_new(out / 'preflight.json', summary)
    return summary


def execute(out, protocol, protocol_sha, pins, cases, adapter):
    summary = json.loads((out / 'preflight.json').read_text())
    seal = summary.pop('content_sha256')
    if digest(summary) != seal or summary['status'] != 'passed' or summary['protocol_sha256'] != protocol_sha:
        raise ValueError('Complete successful preflight seal for this protocol is required.')
    for pin in summary['preflight_inventory']:
        path = Path(pin['path']);actual = raw_pin(path)
        if actual != pin:
            raise ValueError('A complete preflight packet changed.')
    order = json.loads((out / 'order.json').read_text())
    if digest(order) != summary['order_sha256'] or order['rows'] != plan_rows(cases, 20261117):
        raise ValueError('Interleaved source/arm ordering differs from preflight.')
    # Exclusive marker intentionally forbids all automatic resume/rerun. A crash
    # after an fsynced request intent leaves an unknown request, never a retry.
    write_new(out / 'run_started.json', {'at': stamp(), 'protocol_sha256': protocol_sha,
        'policy': 'one pass; no automatic retries or resumption including interrupted unknown requests'})
    (out / 'results').mkdir(exist_ok=False)
    sync_directory(out)
    resources = model_preflight(out, 'execution', protocol, adapter)
    calls = 0;actual_rows = {arm: [] for arm in ARM_VARIANTS}
    started = time.monotonic()
    for row in order['rows']:
        case = cases[row['index']]
        packet = json.loads((out / 'preflight' / (row['stem'] + '.json')).read_text())
        drift = []
        journal(out / 'execution_events.jsonl', {'at': stamp(), 'kind': 'row_intent', **row})
        if packet['kind'] in {'callable', 'context_abstention'}:
            def token_counter(payload):
                if digest(payload) != packet['request_sha256'] or payload != packet['request']:
                    drift.append('request');raise ValueError('Actual generation payload differs from exact preflight.')
                return packet['tokenize_response']['body']['count']
            def event(value):
                nonlocal calls
                if value['status'] == 'request_intent':
                    if calls >= protocol['parameters']['max_model_requests']:
                        drift.append('budget');raise ValueError('Global frozen request budget exhausted.')
                    calls += 1
                journal(out / 'execution_events.jsonl', {'at': stamp(), 'stem': row['stem'], 'event': value})
            client = adapter.NanoClient(endpoint=protocol['parameters']['endpoint'], allow_live=True,
                token_counter=token_counter, max_tokens=1024, event_callback=event)
            result = adapter.review_released_case(case, client=client, variant_name=row['variant_name'])
            if packet['kind'] == 'context_abstention':
                if result.get('model_requests') != 0 or result['status'] != 'abstain':
                    raise ValueError('The frozen native client context guard did not abstain before generation.')
                result['technical_reason'] = packet['technical_reason']
            if drift:
                write_new(out / 'results' / (row['stem'] + '.failed.json'), result)
                raise ValueError('Frozen request integrity changed; stop without retry.')
        else:
            result = packet['native_result']
        if result['source_case_sha256'] != digest(case) or not result['original_case_unchanged']:
            raise ValueError('Native execution changed or rebound the original source input.')
        normalized = {'case_id': case['case_id'], 'input_sha256': digest(case), 'arm_id': row['arm_id'],
            'proposal': {'correct': 'support', 'incorrect': 'reject'}.get(result.get('verdict'), 'abstain'),
            'status': result['status'], 'result': result}
        write_new(out / 'results' / (row['stem'] + '.json'), normalized)
        actual_rows[row['arm_id']].append(normalized)
    load_protocol(pins['protocol'], protocol_sha)
    by_id = {case['case_id']: index for index, case in enumerate(cases)}
    actual_rows['retain_all'] = [{'case_id': case['case_id'], 'input_sha256': digest(case),
        'arm_id': 'retain_all', 'proposal': 'support', 'status': 'constant_baseline',
        'model_requests': 0} for case in cases]
    outputs = []
    for arm, rows in actual_rows.items():
        rows.sort(key=lambda row: by_id[row['case_id']])
        if len(rows) != len(cases):
            raise ValueError('Never seal an incomplete common-denominator arm.')
        envelope = {'format': 'biograph-steward.official-pair-predictions.v1', 'arm_id': arm,
            'protocol_sha256': protocol_sha, 'source_cases_sha256': protocol['source_cases']['sha256'],
            'rows': rows}
        envelope['content_sha256'] = digest(envelope)
        path = out / (arm + '.json');write_new(path, envelope);outputs.append(raw_pin(path))
    receipt = {'status': 'completed_sealed_before_scoring', 'protocol_sha256': protocol_sha,
        'source_cases_sha256': protocol['source_cases']['sha256'], 'source_rows': len(cases),
        'all_model_arm_rows_present': True,
        'completed_arm_rows': {name: len(rows) for name, rows in actual_rows.items()},
        'model_requests': calls, 'max_model_requests': protocol['parameters']['max_model_requests'],
        'max_output_tokens_per_request': 1024, 'elapsed_execution_seconds': round(time.monotonic() - started, 3),
        'labels_accessed': False, 'retries': 0, 'repairs': 0, 'resumed': False,
        'grounding_resources': resources, 'outputs': outputs, 'finished_at': stamp(),
        'preflight_receipt': raw_pin(out / 'preflight.json'),
        'run_started': raw_pin(out / 'run_started.json'),
        'execution_events': raw_pin(out / 'execution_events.jsonl')}
    receipt['content_sha256'] = digest(receipt);write_new(out / 'completion.json', receipt)
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--protocol', required=True, type=Path)
    parser.add_argument('--protocol-sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--phase', required=True, choices=['preflight', 'run'])
    args = parser.parse_args()
    os.umask(0o077)
    os.environ['PYSTOW_HOME'] = str(ROOT / 'runs/indra_grounding_runtime_20261113/resources')
    sys.path.insert(0, str(HERE));sys.path.insert(0, str(ROOT))
    protocol, pins, cases = load_protocol(args.protocol, args.protocol_sha256)
    pins['protocol'] = args.protocol.resolve()
    import nano_disconfirm as adapter
    adapter.verify_upstream();adapter.verify_grounding_resources()
    with wall_limit(protocol['parameters']['max_wall_seconds']):
        try:
            result = (preflight if args.phase == 'preflight' else execute)(
                args.output.resolve(), protocol, args.protocol_sha256, pins, cases, adapter)
        except BaseException as error:
            if args.output.is_dir():
                journal(args.output / 'failures.jsonl', {'at': stamp(), 'phase': args.phase,
                    'error_type': type(error).__name__, 'message': str(error),
                    'automatic_retry_allowed': False})
            raise
    print(json.dumps({key: result[key] for key in result if key in
        {'status', 'source_rows', 'model_requests', 'counts', 'max_prompt_tokens', 'content_sha256'}}, indent=2))


if __name__ == '__main__':
    main()
