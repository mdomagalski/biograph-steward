"""Invented fixtures only: no source corpus, new gold labels or model endpoint."""
from copy import deepcopy
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent))
import nano_disconfirm as adapter
from indra.statements import (Activation, ActivityCondition, Agent, BoundCondition,
    Complex, Evidence, ModCondition, MutCondition, Phosphorylation, Translocation)
from indra_belief.data.entity import GroundedEntity
from indra_belief.scorers.monolithic.scorer import (_RAW_BANK, _select_examples,
                                                  VARIANTS)


def reply(content=None, **extra):
    return {'model': adapter.MODEL, 'choices': [{'message': {
        'role': 'assistant', 'content': content if content is not None else json.dumps({
        'support': 'InventedP1 activates InventedP2.', 'objection': None,
        'verdict': 'correct', 'confidence': 'medium'})}, 'finish_reason': 'stop'}],
        'usage': {'prompt_tokens': 1234, 'completion_tokens': 44}, **extra}


class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.network = patch('socket.create_connection', side_effect=AssertionError('No network in fixtures'))
        self.network.start()
        # Invented identifiers require no actual entity index. Keep all native
        # typed renderers/example selection/parser code active and unmodified.
        self.entities = patch.object(GroundedEntity, 'resolve', side_effect=lambda name, raw_text=None:
            GroundedEntity(name=name, raw_text=raw_text, canonical=name))
        self.entities.start()
        self.claim = Activation(Agent('InventedP1'), Agent('InventedP2')).to_json()
        self.claim.pop('belief', None)
        self.evidence = {'text': 'InventedP1 activates InventedP2.',
                         'source_api': 'invented_reader', 'pmid': '12345678'}

    def tearDown(self):
        self.entities.stop();self.network.stop()

    def run_pair(self, claim=None, evidence=None, transport=None, **kw):
        client = adapter.NanoClient(transport=transport or (lambda payload: reply()))
        result = adapter.review_pair(claim or self.claim, evidence or self.evidence,
                                     client=client, **kw)
        return result, client

    def test_actual_adaptive_examples_all_preserved_with_vendor_wire_adjustment(self):
        self.assertTrue(_RAW_BANK)
        self.assertIsNone(VARIANTS['disconfirm'].resolve_relation_nature)
        result, client = self.run_pair()
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(result['model_requests'], 1)
        self.assertEqual(len(result['native_result']['selected_example_ids']), 14)
        trace = result['call_log'][0];messages = trace['request']['messages']
        self.assertEqual(messages[0], {'role': 'system', 'content': 'detailed thinking off'})
        expected = []
        for example in _select_examples('Activation'):
            user, answer = VARIANTS['disconfirm'].render_example(example)
            expected.extend([{'role': 'user', 'content': user},
                             {'role': 'assistant', 'content': answer}])
        self.assertEqual(trace['author_messages'][:-1], expected)
        self.assertEqual(messages[1], {'role': 'user', 'content':
            VARIANTS['disconfirm'].system_prompt + '\n\n' + expected[0]['content']})
        self.assertEqual(messages[2:], trace['author_messages'][1:])
        self.assertEqual(len(messages), 30)  #14 examples=28turns +input +system; policy prefix.
        self.assertNotIn('guided_json', trace['request'])
        self.assertNotIn('reasoning_effort', trace['request'])
        self.assertEqual(trace['request']['temperature'], .1)
        self.assertIsNone(result['native_result']['score'])
        self.assertIsNone(result['native_result']['weight_of_evidence'])

    def test_official_base_is_task_matched_without_rf_or_relation_filter(self):
        claim = Complex([Agent('InventedP1'), Agent('InventedP2')]).to_json()
        claim.pop('belief', None)
        result, client = self.run_pair(claim=claim, variant_name='')
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(result['variant_name'], '')
        self.assertEqual(result['method'], 'official_base_unfitted_nano8b')
        self.assertIsNone(VARIANTS[''].resolve_relation_nature)
        self.assertEqual(client.request_count, 1)
        trace = result['call_log'][0]
        self.assertEqual(trace['author_system'], VARIANTS[''].system_prompt)
        expected = []
        for example in _select_examples('Complex'):
            user, answer = VARIANTS[''].render_example(example)
            expected.extend([{'role': 'user', 'content': user},
                             {'role': 'assistant', 'content': answer}])
        self.assertEqual(trace['author_messages'][:-1], expected)
        disconfirm, _ = self.run_pair(claim=claim)
        self.assertEqual(result['native_result']['selected_example_ids'],
                         disconfirm['native_result']['selected_example_ids'])
        self.assertNotEqual(trace['author_system'],
                            disconfirm['call_log'][0]['author_system'])
        with self.assertRaises(ValueError):
            self.run_pair(variant_name='disconfirm_relnature_rf')

    def test_native_modification_site_mutation_activity_and_binding_are_preserved(self):
        subject = Agent('InventedP1', mutations=[MutCondition('600', 'V', 'E')],
                        activity=ActivityCondition('kinase', False),
                        bound_conditions=[BoundCondition(Agent('InventedP3'), True)])
        claim = Phosphorylation(subject, Agent('InventedP2'), 'S', '51').to_json()
        claim.pop('belief', None)
        pristine = deepcopy(claim)
        result, _ = self.run_pair(claim=claim)
        self.assertEqual(result['status'], 'completed')
        body = result['call_log'][0]['author_messages'][-1]['content']
        for field in ('V600E', 'kinase, False', 'bound to InventedP3', '@S51'):
            self.assertIn(field, body)
        self.assertEqual(claim, pristine)
        self.assertTrue(result['original_input_dictionaries_unchanged'])

    def test_original_selected_evidence_and_other_statement_evidence_not_rewritten(self):
        evidence = Evidence(source_api='invented_reader', text=self.evidence['text'],
            pmid='12345678', annotations={'original_reader_field': ['all', 'retained']},
            epistemics={'direct': False}).to_json()
        evidence.pop('source_hash', None)
        claim = deepcopy(self.claim);claim['evidence'] = [deepcopy(evidence), {
            'text': 'A different original evidence remains in the native object.',
            'source_api': 'invented_reader'}]
        originals = adapter.encoded({'statement': claim, 'evidence': evidence})
        capture = []
        real = adapter.score_evidence
        def inspect(statement, selected, client, **kwargs):
            capture.append((statement, selected.to_json()))
            return real(statement, selected, client, **kwargs)
        with patch.object(adapter, 'score_evidence', side_effect=inspect):
            result, _ = self.run_pair(claim=claim, evidence=evidence,
                                     source_view='available_native_evidence')
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(len(capture[0][0].evidence), 2)
        self.assertEqual(capture[0][1]['annotations'], evidence['annotations'])
        self.assertEqual(capture[0][1]['epistemics'], evidence['epistemics'])
        self.assertEqual(adapter.encoded({'statement': claim, 'evidence': evidence}), originals)

    def test_unexpressible_states_abstain_without_dropping_or_flattening(self):
        conditions = [
            Activation(Agent('InventedP1', mods=[ModCondition('phosphorylation', 'S', '2')]), Agent('InventedP2')),
            Activation(Agent('InventedP1', location='nucleus'), Agent('InventedP2')),
            Activation(Agent('InventedP1', bound_conditions=[BoundCondition(Agent('InventedP3'), False)]), Agent('InventedP2')),
            Complex([Agent('InventedP1', mutations=[MutCondition('2', 'V', 'E')]), Agent('InventedP2')]),
        ]
        for index, native in enumerate(conditions):
            with self.subTest(index=index):
                claim = native.to_json();claim.pop('belief', None);pristine = deepcopy(claim)
                result, client = self.run_pair(claim=claim, case_id='fixture-'+str(index))
                self.assertEqual(result['status'], 'abstain')
                self.assertEqual(result['case_id'], 'fixture-'+str(index))
                self.assertEqual(result['reason'], 'author_renderer_cannot_express_all_conditions')
                self.assertTrue(result['unsupported_fields'])
                self.assertEqual(client.request_count, 0)
                self.assertEqual(claim, pristine)

    def test_plain_complex_does_not_run_direct_binding_second_call(self):
        claim = Complex([Agent('InventedP1'), Agent('InventedP2')]).to_json()
        claim.pop('belief', None)
        result, client = self.run_pair(claim=claim)
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(client.request_count, 1)
        self.assertEqual(result['call_log'][0]['author_system'], VARIANTS['disconfirm'].system_prompt)
        self.assertNotIn('relation-nature', result['call_log'][0]['author_messages'][-1]['content'])

    def test_native_translocation_endpoints_are_not_collapsed_to_two_names(self):
        claim = Translocation(Agent('InventedP1'), 'cytoplasm', 'nucleus').to_json()
        claim.pop('belief', None)
        result, _ = self.run_pair(claim=claim)
        self.assertEqual(result['status'], 'completed')
        body = result['call_log'][0]['author_messages'][-1]['content']
        self.assertIn('from cytoplasm to nucleus', body)

    def test_released_opaque_identity_stays_sidecar_without_invented_annotations(self):
        identity = {'released_source_hash': 'OPAQUE_RELEASE_NOT_REGENERATED',
                    'raw_source_line_sha256': 'a'*64}
        result, _ = self.run_pair(source_identity=identity)
        self.assertEqual(result['source_identity'], identity)
        self.assertFalse(result['original_reader_annotations_available'])
        self.assertFalse(result['original_epistemics_available'])
        self.assertFalse(result['native_evidence_runtime_hash_is_released_identity'])
        self.assertNotIn('OPAQUE_RELEASE_NOT_REGENERATED',
                         json.dumps(result['call_log'][0]['request']))

    def test_released_frame_bridge_binds_all_original_fields_and_no_opaque_hash_as_native(self):
        case = {'case_id': 'invented-pair', 'matches_hash': 'OPAQUE_MATCH',
                'source_hash': 'OPAQUE_SOURCE', 'statement': self.claim,
                'evidence': {**self.evidence, 'original_source_hash': 'OPAQUE_SOURCE'},
                'original_annotations_available': False,
                'provenance': {'release_line': 17, 'unmodified_source_sha256': 'f'*64}}
        pristine = deepcopy(case)
        client = adapter.NanoClient(transport=lambda payload: reply())
        result = adapter.review_released_case(case, client=client, variant_name='')
        self.assertEqual(result['status'], 'completed')
        self.assertEqual(result['source_case_sha256'], adapter.digest(pristine))
        self.assertEqual(result['released_evidence_sha256'], adapter.digest(pristine['evidence']))
        self.assertEqual(result['source_identity'], {
            'matches_hash': 'OPAQUE_MATCH', 'source_hash': 'OPAQUE_SOURCE',
            'original_source_hash': 'OPAQUE_SOURCE'})
        self.assertNotIn('OPAQUE_SOURCE', json.dumps(result['call_log'][0]['request']))
        self.assertTrue(result['original_case_unchanged'])
        self.assertEqual(case, pristine)
        case['evidence']['original_source_hash'] = 'DIFFERENT'
        with self.assertRaises(ValueError):
            adapter.review_released_case(case, client=client)
        case = deepcopy(pristine);case['evidence']['context'] = {'species': 'human'}
        with self.assertRaises(ValueError):
            adapter.review_released_case(case, client=client)
        self.assertEqual(client.request_count, 1)

    def test_no_text_abstains_instead_of_upstream_correct_by_default(self):
        evidence = {**self.evidence, 'text': ' '}
        result, client = self.run_pair(evidence=evidence)
        self.assertEqual(result['reason'], 'no_published_source_sentence')
        self.assertEqual(result['status'], 'abstain')
        self.assertEqual(client.request_count, 0)

    def test_transport_failure_and_unreadable_author_output_are_abstentions(self):
        def failure(payload):
            raise TimeoutError('invented timeout')
        result, client = self.run_pair(transport=failure)
        self.assertEqual(result['status'], 'abstain')
        self.assertEqual(result['model_requests'], 1)
        self.assertEqual(result['call_log'][0]['status'], 'model_error')
        self.assertEqual(client.request_count, 1)
        result, _ = self.run_pair(transport=lambda payload: reply('not a verdict'))
        self.assertEqual(result['status'], 'abstain')
        self.assertEqual(result['reason'], 'author_parser_abstained')

    def test_upstream_grounding_failure_is_not_qualified_as_a_source_verdict(self):
        with patch('indra_belief.data.entity.gilda_failure_counts',
                   side_effect=[{'ground': 0, 'get_names': 0},
                                {'ground': 1, 'get_names': 0}]):
            result, client = self.run_pair()
        self.assertEqual(result['status'], 'abstain')
        self.assertIsNone(result['verdict'])
        self.assertEqual(result['reason'], 'method_or_transport_error')
        self.assertEqual(result['native_result']['verdict'], 'correct')
        self.assertEqual(client.request_count, 1)
        self.assertEqual(len(result['call_log']), 1)

    def test_nonstop_response_abstains_even_if_truncated_text_is_parseable_json(self):
        raw=reply();raw['choices'][0]['finish_reason']='length'
        result,client=self.run_pair(transport=lambda payload:deepcopy(raw))
        self.assertEqual(result['status'],'abstain')
        self.assertIsNone(result['verdict'])
        self.assertEqual(result['reason'],'method_or_transport_error')
        self.assertEqual(client.request_count,1)
        self.assertEqual(result['call_log'][0]['response'],raw)
        self.assertEqual(result['call_log'][0]['status'],'model_error')

    def test_live_disabled_and_over_context_fail_before_network(self):
        client = adapter.NanoClient()
        result = adapter.review_pair(self.claim, self.evidence, client=client)
        self.assertEqual(result['status'], 'abstain')
        self.assertEqual(result['model_requests'], 0)
        client = adapter.NanoClient(allow_live=True,
            token_counter=lambda payload: adapter.CONTEXT_LIMIT)
        result = adapter.review_pair(self.claim, self.evidence, client=client)
        self.assertEqual(result['status'], 'abstain')
        self.assertEqual(result['model_requests'], 0)

    def test_explicit_schema_is_preserved_and_not_replaced(self):
        client = adapter.NanoClient(transport=lambda payload: reply())
        schema = {'type': 'json_object'}
        original = deepcopy(schema)
        payload = client.prepare('Original author instructions.',
                                 [{'role': 'user', 'content': 'Original input.'}],
                                 response_format=schema)
        self.assertEqual(payload['response_format'], original)
        self.assertEqual(schema, original)


if __name__ == '__main__':
    unittest.main(verbosity=2)
