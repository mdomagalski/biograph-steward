# Private upstream source provenance

The files in `upstream/` are unmodified captures from
https://github.com/gyorilab/indra-belief-model at commit
`74e0ffe9ea21f6f11e906cee89a2091f45be2f7d`. Their complete raw-file SHA256 and original
URLs are recorded in `upstream_manifest.json`. The published adaptive example bank
is part of the method, not held-out evaluation data.

The pinned author's `pyproject.toml` declares `license = {text = "MIT"}`. The pinned
tree contains no standalone LICENSE file and GitHub did not classify a license.
This capture preserves original notices, README, source docstrings and that exact
project declaration. It neither fabricates a copyright holder/year nor supplies an
invented upstream license text. This private qualification is not a public
redistribution of the upstream package. Resolve an explicit upstream notice before
any later public vendoring if required.

Local adapters/fixtures are newly authored project code. Installed INDRA1.24.0 and
Gilda1.6.1 use their own BSD2-Clause license notices in the existing optional
runtime; neither dependency's source was modified. No OpenAI/Anthropic SDK or new
dependency was installed. The released reference frame is separately qualified
and its data licensing is not changed by this source capture.
