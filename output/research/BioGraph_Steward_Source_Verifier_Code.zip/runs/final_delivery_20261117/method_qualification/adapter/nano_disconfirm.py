"""Private qualification adapter for the unmodified author INDRA scorer.

No production import or default changes. No model call occurs unless an injected
transport is supplied, or live execution and an exact tokenizer counter are
explicitly enabled. The upstream categorical parser and example bank are kept.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import ssl
import sys
import time
from urllib.error import HTTPError
from urllib.parse import urlparse
from urllib.request import HTTPSHandler, ProxyHandler, Request, build_opener

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'upstream/src'))
sys.path.insert(0, str(HERE.parents[3]))
from biograph_steward.model_transport import _NoRedirect
from indra.statements import Evidence, stmt_from_json
from indra_belief import score_evidence
from indra_belief.model_client import ModelResponse
from indra_belief.scorers.monolithic.scorer import VARIANTS

UPSTREAM_COMMIT = '74e0ffe9ea21f6f11e906cee89a2091f45be2f7d'
MODEL = 'nvidia/Llama-3.1-Nemotron-Nano-8B-v1'
MODEL_REVISION = '54641c1611fcff44fa4865626462445e0a153fc7'
WIRE_PROFILE = 'author_policy_prefixed_to_first_user_nano8b_v2'
CONTEXT_LIMIT = 16384
GROUNDING_RESOURCE_PINS = {
    'grounding_terms.tsv.gz': 'b53169c4735d049c0443ab04830b26372dcfeba47845c1fe97392b64f08f2bb8',
    'gilda_models.json.gz': '62c888eeabe4afb484d17d90cf3e8304c9c3a8f1c97b5b3fb7ab41a458340e1f',
}


def encoded(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(',', ':'), allow_nan=False).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def verify_upstream():
    manifest = json.loads((HERE / 'upstream_manifest.json').read_text())
    if manifest['commit'] != UPSTREAM_COMMIT or not manifest['method_example_bank_captured']:
        raise ValueError('Pinned complete author method is required.')
    for pin in manifest['files']:
        path = HERE / 'upstream' / pin['path']
        if (path.is_symlink() or not path.is_file()
                or hashlib.sha256(path.read_bytes()).hexdigest() != pin['sha256']):
            raise ValueError('Unmodified author source/example-bank pin differs.')
    return digest(manifest)


def verify_grounding_resources():
    """No downloader: verify the actual configured Gilda resource directory.

    Set PYSTOW_HOME before importing this adapter, using the already captured
    optional runtime's resources directory. A missing index must not silently
    turn the author's grounding layer into an empty resolver.
    """
    from gilda.resources import resource_dir
    pins = []
    for name, expected in GROUNDING_RESOURCE_PINS.items():
        path = Path(resource_dir) / name
        if path.is_symlink() or not path.is_file():
            raise ValueError('The complete pinned local Gilda resources are required.')
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            raise ValueError('Configured Gilda resource differs from the captured artifact.')
        pins.append({'file': name, 'sha256': actual, 'bytes': path.stat().st_size})
    return pins


class NanoClient:
    """Author ModelClient.call interface over standard local chat completions.

    The only message adaptation is inserting the NVIDIA thinking-off system
    switch and prefixing unchanged author system text plus two newlines to the
    first example user turn. Its tokenizer requires alternating user/assistant
    roles. Every original example/input content remains intact and in order.
    These are fixed fewshots, not history from other cases. No Gemma options,
    learned calibration, logprob probes, retries or output repair are enabled.
    """
    def __init__(self, endpoint='http://127.0.0.1:18117/v1/chat/completions', *,
                 transport=None, allow_live=False, token_counter=None,
                 max_tokens=1024, timeout=180, event_callback=None):
        parsed = urlparse(endpoint)
        if (parsed.scheme not in ('http', 'https') or parsed.hostname not in
                {'localhost', '127.0.0.1', '::1'} or parsed.username or parsed.password
                or parsed.query or parsed.fragment or parsed.path != '/v1/chat/completions'):
            raise ValueError('Use an explicit loopback model endpoint without credentials.')
        if type(max_tokens) is not int or not 128 <= max_tokens <= 1024:
            raise ValueError('Bound the output budget to128–1024tokens.')
        self.endpoint, self.transport, self.allow_live = endpoint, transport, allow_live
        self.token_counter, self.event_callback = token_counter, event_callback
        self.model_name = 'biograph_nano8b_unfitted_disconfirm'
        self.backend = 'project_loopback_chat'
        self.config = {'model_id': MODEL, 'max_tokens': max_tokens,
                       'timeout': timeout, 'supports_logprobs': False}
        self.call_log = []
        self.request_count = 0

    def pop_call_log(self):
        rows, self.call_log = self.call_log, []
        return rows

    def prepare(self, system, messages, max_tokens=None, temperature=.1,
                response_format=None, reasoning_effort=None, kind='unknown',
                top_logprobs=None):
        if not isinstance(system, str) or not system or not isinstance(messages, list):
            raise ValueError('Keep the complete author policy and ordered messages.')
        if (not messages or any(not isinstance(m, dict) or set(m) != {'role', 'content'}
                or m['role'] != ('user' if index % 2 == 0 else 'assistant')
                or not isinstance(m['content'], str) for index, m in enumerate(messages))):
            raise ValueError('Author example/input messages have an unsupported shape.')
        if reasoning_effort is not None or top_logprobs is not None:
            raise ValueError('No Gemma reasoning parameters, margins or fitted probes.')
        budget = self.config['max_tokens'] if max_tokens is None else max_tokens
        if type(budget) is not int or not 128 <= budget <= self.config['max_tokens']:
            raise ValueError('Author call exceeds the frozen completion budget.')
        wire_messages = deepcopy(messages)
        wire_messages[0]['content'] = system + '\n\n' + wire_messages[0]['content']
        payload = {'model': MODEL, 'stream': False, 'temperature': temperature,
                   'max_tokens': budget, 'messages': [
                       {'role': 'system', 'content': 'detailed thinking off'},
                       *wire_messages]}
        if response_format is not None:
            payload['response_format'] = deepcopy(response_format)
        return payload

    def call(self, system, messages, max_tokens=None, temperature=.1,
             response_format=None, reasoning_effort=None, kind='unknown', top_logprobs=None):
        payload = self.prepare(system, messages, max_tokens, temperature,
                               response_format, reasoning_effort, kind, top_logprobs)
        prompt_tokens = self.token_counter(deepcopy(payload)) if self.token_counter else None
        if prompt_tokens is not None and (type(prompt_tokens) is not int or prompt_tokens <= 0
                or prompt_tokens + payload['max_tokens'] > CONTEXT_LIMIT):
            raise ValueError('Complete author prompt and output do not fit the actual server.')
        if self.transport is None and (not self.allow_live or prompt_tokens is None):
            raise ValueError('Live calls require separate GO and exact tokenizer preflight.')
        trace = {'kind': kind, 'model_id': MODEL, 'model_revision': MODEL_REVISION,
                 'provider_kind': 'injected_test_model' if self.transport else 'live_vllm',
                 'wire_profile': WIRE_PROFILE, 'author_system': system,
                 'author_messages': deepcopy(messages), 'request': deepcopy(payload),
                 'request_sha256': digest(payload), 'prompt_tokens': prompt_tokens,
                 'status': 'request_intent', 'retries': 0, 'repairs': 0}
        if self.event_callback:
            self.event_callback(deepcopy(trace))
        started = time.perf_counter()
        self.request_count += 1
        try:
            if self.transport:
                raw = self.transport(deepcopy(payload))
            else:
                request = Request(self.endpoint, data=encoded(payload),
                                  headers={'Content-Type': 'application/json', 'Accept': 'application/json'})
                opener = build_opener(_NoRedirect(), ProxyHandler({}),
                                      HTTPSHandler(context=ssl.create_default_context()))
                with opener.open(request, timeout=self.config['timeout']) as response:
                    body = response.read(1_000_001)
                if len(body) > 1_000_000:
                    raise ValueError('Model response exceeds its byte bound.')
                raw = json.loads(body)
            if isinstance(raw, dict):
                trace.update(response=deepcopy(raw), response_sha256=digest(raw))
            if not isinstance(raw, dict) or raw.get('model') != MODEL:
                raise ValueError('Returned model identity differs from the frozen reader.')
            choices = raw.get('choices')
            if not isinstance(choices, list) or len(choices) != 1:
                raise ValueError('One actual assistant response is required.')
            choice = choices[0];message = choice.get('message', {})
            if choice.get('finish_reason') != 'stop':
                raise ValueError('A truncated or otherwise non-stop response cannot qualify a source verdict.')
            content = message.get('content')
            if message.get('role') != 'assistant' or not isinstance(content, str):
                raise ValueError('Missing final assistant content.')
            if message.get('tool_calls') or message.get('function_call') or message.get('refusal'):
                raise ValueError('Only an author-scored text response is supported.')
            usage = raw.get('usage') or {}
            trace.update(status='response_received', response=deepcopy(raw),
                         response_sha256=digest(raw), latency_ms=round((time.perf_counter()-started)*1000, 3))
            self.call_log.append(trace)
            if self.event_callback:
                self.event_callback(deepcopy(trace))
            return ModelResponse(content=content, reasoning='', raw_text=content,
                tokens=usage.get('completion_tokens', -1), prompt_tokens=usage.get('prompt_tokens', -1),
                finish_reason=choice.get('finish_reason', 'unknown'))
        except Exception as exc:
            if isinstance(exc, HTTPError):
                exc.close()
            trace.update(status='model_error', error_type=type(exc).__name__,
                         latency_ms=round((time.perf_counter()-started)*1000, 3))
            self.call_log.append(trace)
            if self.event_callback:
                self.event_callback(deepcopy(trace))
            raise


def unsupported_claim_state(statement):
    """Technical expressibility guard, not a biological-correctness rule.

    These fields have no faithful slot in the pinned author's execution_body.
    Retain every row in the evaluation denominator as a method abstention.
    """
    from indra.statements import Complex, ActiveForm, Conversion
    issues = []
    if isinstance(statement, (ActiveForm, Conversion)):
        issues.append('statement_type_specific_fields_not_rendered')
    if getattr(statement, 'obj_activity', 'activity') != 'activity':
        issues.append('statement.obj_activity_not_rendered')
    for index, agent in enumerate(statement.agent_list()):
        if not agent:
            continue
        prefix = f'agent[{index}]'
        if agent.mods:
            issues.append(prefix + '.mods_not_rendered')
        if agent.location:
            issues.append(prefix + '.location_not_rendered')
        if isinstance(statement, Complex) and any((agent.activity, agent.mutations, agent.bound_conditions)):
            issues.append(prefix + '.complex_member_state_not_rendered')
        for condition in agent.bound_conditions:
            if not condition.is_bound:
                issues.append(prefix + '.negative_bound_condition_not_rendered')
            bound = condition.agent
            if bound and any((bound.mods, bound.mutations, bound.activity, bound.location, bound.bound_conditions)):
                issues.append(prefix + '.nested_bound_agent_state_not_rendered')
    return issues


def review_pair(statement_json, evidence_json, *, client, case_id=None,
                source_identity=None, source_view='released_native_claim_and_sentence',
                variant_name='disconfirm'):
    """Use original native objects; never replace them with two entity strings.

    In the released403 view, absent original reader spans/epistemics stay unknown.
    An opaque released source hash belongs in source_identity, not Evidence JSON.
    No whole-Statement or graph-deletion decision is returned by this adapter.
    """
    verify_upstream()
    if variant_name not in {'', 'disconfirm'}:
        raise ValueError('Only the unmodified author base and disconfirm profiles are qualified.')
    original = {'statement': deepcopy(statement_json), 'evidence': deepcopy(evidence_json)}
    result = {'status': 'abstain', 'verdict': None, 'case_id': case_id,
              'input_sha256': digest(original), 'source_identity': deepcopy(source_identity),
              'source_view': source_view,
              'method': 'official_' + (variant_name or 'base') + '_unfitted_nano8b',
              'variant_name': variant_name,
              'upstream_commit': UPSTREAM_COMMIT, 'probability': None,
              'reason': None, 'native_result': None, 'new_graph_decision': False}
    before = client.request_count
    try:
        if not isinstance(statement_json, dict) or not isinstance(evidence_json, dict):
            raise ValueError('Use full source claim/evidence dictionaries.')
        if 'belief' in statement_json:
            raise ValueError('Released belief is not an input feature.')
        if source_view == 'released_native_claim_and_sentence' and 'source_hash' in evidence_json:
            raise ValueError('Keep the opaque released hash in a source sidecar.')
        if not isinstance(evidence_json.get('text'), str) or not evidence_json['text'].strip():
            result['reason'] = 'no_published_source_sentence';return result
        statement = stmt_from_json(deepcopy(statement_json))
        evidence = Evidence._from_json(deepcopy(evidence_json))
        issues = unsupported_claim_state(statement)
        if issues:
            result.update(reason='author_renderer_cannot_express_all_conditions', unsupported_fields=issues)
            return result
        # Original preassembly mentions are deep-sorted; the author resolver
        # consumes sequential non-null mentions. Do not invent a remapping.
        raw = (evidence.annotations.get('agents') or {}).get('raw_text')
        if raw and (any(item is None for item in raw) or statement.agent_list() != statement.agent_list(deep_sorted=True)):
            result['reason'] = 'raw_mention_role_alignment_unproven';return result
        if client.transport is None and client.allow_live:
            result['grounding_resources'] = verify_grounding_resources()
        from indra_belief.data.entity import gilda_failure_counts
        grounding_failures = gilda_failure_counts()
        native = score_evidence(statement, evidence, client, variant=VARIANTS[variant_name])
        result['native_result'] = native
        if gilda_failure_counts() != grounding_failures:
            raise ValueError('Upstream grounding failed; do not qualify a degraded source verdict.')
        if native.get('score') is not None:
            raise ValueError('No reader calibration is qualified for this Nano8B adapter.')
        result['native_evidence_runtime_hash_is_released_identity'] = False
        result['available_evidence_fields'] = sorted(evidence_json)
        result['original_reader_annotations_available'] = 'annotations' in evidence_json
        result['original_epistemics_available'] = 'epistemics' in evidence_json
        if native.get('verdict') in {'correct', 'incorrect'}:
            result.update(status='completed', verdict=native['verdict'], reason=None)
        else:
            result['reason'] = 'author_parser_abstained'
    except Exception as exc:
        result.update(reason='method_or_transport_error', error_type=type(exc).__name__)
    finally:
        result['model_requests'] = client.request_count - before
        result['call_log'] = (result['native_result'].get('call_log', [])
                              if result['native_result'] else client.pop_call_log())
        result['original_input_dictionaries_unchanged'] = digest(
            {'statement': statement_json, 'evidence': evidence_json}) == result['input_sha256']
    return result


def review_released_case(case, *, client, variant_name='disconfirm'):
    """Bridge the released pair frame, retaining original identities separately.

    The release's opaque source_hash is not a native Evidence serialization.
    Only its published sentence/source/PMID fields are available to both methods.
    Full original case bytes remain the runner's immutable input artifact; its
    canonical digest binds every original field, including availability flags.
    """
    if not isinstance(case, dict) or not isinstance(case.get('evidence'), dict):
        raise ValueError('An unchanged released pair case is required.')
    evidence = case['evidence']
    if set(evidence) - {'text', 'source_api', 'pmid', 'original_source_hash'}:
        raise ValueError('Unexpected source fields require explicit qualification, not silent omission.')
    if ('original_source_hash' in evidence and 'source_hash' in case
            and evidence['original_source_hash'] != case['source_hash']):
        raise ValueError('Released original source identities disagree.')
    before = digest(case)
    selected = {key: deepcopy(value) for key, value in evidence.items()
                if key != 'original_source_hash'}
    identity = {key: deepcopy(case[key]) for key in ('matches_hash', 'source_hash') if key in case}
    identity['original_source_hash'] = deepcopy(evidence.get('original_source_hash'))
    result = review_pair(deepcopy(case['statement']), selected, client=client,
                         case_id=case.get('case_id'), source_identity=identity,
                         variant_name=variant_name)
    result.update(source_case_sha256=before,
                  released_evidence_sha256=digest(evidence),
                  original_case_unchanged=digest(case) == before)
    return result
