# BioGraph Steward

An agent workbench for inspecting evidence from Pharos and qualified source
profiles. For the real challenge demonstration, open the protected reviewer app:

https://bi-3a117d5e2b3942678dc518fce65ab5d2.ecs.us-east-2.on.aws/

Use the workspace token supplied separately. You need only a browser to replay
saved work. Hosted availability has a separate deployment receipt; this local
software check does not establish which revision is currently hosted.

## Review the real research workflow

1. In **Start here → Agent workflow**, open the designated recorded model run.
   It replays genuine NVIDIA Nemotron work without making a new model request.
2. **Question & plan** shows the research question, exact protein, source tool,
   requested evidence view and caller limits. The app validates these before
   tool execution. Model rationale is not verified scientific evidence.
3. **Evidence graph** shows the complete returned cited answer and its focused
   graph. The primary KRAS agent run displays eight of 14 matching proteins
   under its frozen cap. The older manual question displays all 14 under a
   different cap. Six matches outside the agent display cap are explicit.
4. **Source inspection** opens every original source assertion under a selected
   citation. **Review proposals** separates retain-candidate/needs-review
   proposals from applied decisions. A proposal accepts no claim and edits no
   graph. All returned answer evidence remains available.
5. **What changed** distinguishes the separate TP53 graph's 298 obsolete-GO-ID
   exclusions from positive location-label recovery. Pharos recovers 41/51 labels
   and the qualified native source 44/51 among 31 matching proteins. Coverage,
   source reuse and prior reference exposure limit the biological conclusion.
6. Download the verified agent record for its saved model/tool work. The
   focused answer ZIP and complete workspace ZIP have different scopes. The
   retained TP53 workspace also preserves its original baseline, retained graph
   and every keep/prune/abstain decision. Abstentions retain the record.

The protected reviewer site blocks live inference, new source retrieval, review
edits and new graph-decision package creation. Existing saved inspection and
downloads remain available. The actual model development comparison completed
five supported queries with exact deterministic result parity and three
preflight guard rejections. This is source fidelity, not a new prediction gain.

## This portable software

Code revision: `ee3c61c23262e57669090a7608658c16517d87cb`. Prepared November 16, 2026 (America/New_York).

This MIT core requires Python 3.10+ and no pip installation. Upstream notices
remain under `biograph_steward/_vendor/`. It includes the agent controller,
saved-job verifier and four-step reviewer interface, native source inspectors,
graph construction, scientific-assessment reader and source-preserving exports.
The full repository separately supplies evaluation tools, optional research
dependencies, deployment operators and detailed source terms.

This ZIP contains no real workspace, source packet, reference labels, model
weights, credentials or Git history. MIT licensing covers project software;
it does not relicense upstream records. A fresh checkout cannot silently
reconstruct the real saved research example without its authorized source data.

## Optional invented portability fixture

The local fixture is intentionally invented and visibly labelled. It verifies
software operation and supplies no biological result. In the extracted folder:

```sh
python3 app.py demo --out runs/synthetic_demo
python3 app.py serve --runs-dir runs --host 127.0.0.1 --port 8765 --no-browser
```

Open `http://127.0.0.1:8765/?run=synthetic_demo`. Keep the terminal running;
Ctrl+C stops it. Choose another unused port if 8765 is occupied. The fixture
has no native physical, location or archived source tools, so it does not
demonstrate the real source agent. Check this without creating a model client:

```sh
python3 app.py source-agent-catalogue --run runs/synthetic_demo
```

The fixture still exercises cited questions, graph construction and local
graph-decision export. Its retained graph, complete undecided ledger and input
baseline preserve every invented record. Shared saved-review mode intentionally
blocks creating such a new package; it allows already prepared downloads.

## Reopening supplied real research data

Extract an authorized saved workspace ZIP and its question ZIP beside one
another under `runs/`, keeping their exact top-level folder names. A saved
agent-record folder must likewise remain beside its original source workspace.
Use the supplied run, question and agent links rather than an invented fixture.

For source-agent execution or replay, inspect the existing CLI:

```sh
python3 app.py source-agent-run --help
python3 app.py source-agent-verify --help
```

New live model work requires a configured model endpoint and the complete
source workspace. Replay and source verification use CPU and make no model
request. The model proposes one bounded query, selects at most three citation
groups for complete source inspection, and chooses grounded review proposals.
It does not add source data or apply acceptance/pruning decisions.

For a shared saved reviewer installation, append `--saved-data-only` to the
serve command. This server policy blocks new inference, retrieval and edits;
it preserves source bytes without making the whole filesystem read-only.

The accompanying acceptance receipt records clean Python without site packages,
invented construction, source-agent imports/catalogue/help, saved-mode request
guards, actual export downloads, source recovery and answer replay after restart.
Those software checks do not establish independent usability or biological truth.
