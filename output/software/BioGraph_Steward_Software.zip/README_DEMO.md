# BioGraph Steward

A Pharos-based evidence workbench with an agent that plans supported source
queries, prioritizes citations for inspection and proposes grounded review
options. Source records, focused answers and applied graph decisions stay
traceable.

## Open the real-data demonstration

Open the public browser demo directly, with no sign-in:

https://bi-3a117d5e2b3942678dc518fce65ab5d2.ecs.us-east-2.on.aws/?run=native_evidence_workspace_20261115&question=native_physical_KRAS_question_v3_20261115&agent_job=source_agent_eval_dc7b597201da_S01&view=data

No AWS account, installation or running model is needed for the demonstration.
The public download is the recorded-agent JSON, with its focused graph, trace
and source inspections. Full graph and source packets are supplied separately
for final submission or authorized operator use.
The site replays actual saved NVIDIA Nemotron work; new inference, retrieval
and review edits are disabled. Hosted availability has its own deployment
receipt, separate from this portable software acceptance.

Follow the operating instructions:

https://github.com/mdomagalski/biograph-steward/blob/main/HOW_TO_USE.md

Follow **Question & plan → Evidence graph → Source inspection → Review
proposals**. Inspect E002, KRAS–CDC42BPB, to see one source-qualified association
absent from the captured Pharos baseline. The source passport preserves the
provider record, identity checks and candidate status. The complete source
query remains available even when the model prioritizes particular citations.

## Build a graph from your proteins

The Start-here construction entry opens the existing graph builder. In local
operator mode, supply 1–25 exact protein accessions and follow its source-scope
controls. The shared saved-review site explains this workflow without starting
new retrieval or a model. Building and reviewing a saved graph are separate
uses of the same application.

## What this ZIP contains

Code revision: `a83420ae2a2dbf0c5ef3756eddb1b643b22c5893`.

The MIT core runs on Python 3.10+ with no pip installation. It includes the
agent controller and saved-job verifier, four-step interface, native source
inspectors, graph construction, assessment reader and source-preserving exports.
Upstream license notices remain under `biograph_steward/_vendor/`.

This is **software only**: no real workspace, source packet, reference labels,
model weights, credentials or Git history. The full repository separately
contains developer/operator guides, evaluation tools and optional dependencies.
The software's MIT license does not relicense the upstream source data.

## Optional local software fixture

The included fixture is invented and explicitly labelled. It demonstrates
software operation, not the real biological evidence or source-agent example.
From the extracted folder:

```sh
python3 app.py demo --out runs/synthetic_demo
python3 app.py serve --runs-dir runs --host 127.0.0.1 --port 8765 --no-browser
```

Open `http://127.0.0.1:8765/?run=synthetic_demo`. Keep the terminal running;
Ctrl+C stops it. Choose another unused port if needed. The fixture has no
native physical, location or archived-pathway tools. Inspect its empty source
catalogue without creating a model client:

```sh
python3 app.py source-agent-catalogue --run runs/synthetic_demo
```

The fixture supports ordinary cited questions, graph construction and local
graph-decision export. It is separate from the frozen real-data source
workspace; a newer app installation does not automatically refresh source data.

## Reopen an authorized real workspace

Keep an authorized workspace ZIP, its question folders and the recorded agent
folder together under `runs/`, retaining their exact top-level names and all
source files. A graph JSON alone is insufficient for source verification.
Start the app as above and use the supplied run/question/agent link.

To record an evidence review in an ordinary saved workspace, launch the local
app without `--saved-data-only`. Choose **Inspect sources**, select a claim,
then **Guide me through this source → Record evidence review**. Enter Reviewer,
Decision, and Reason and evidence reviewed. **Save review in a new run** creates
a reviewed copy and preserves the earlier run and its sources. This is a local
recorded judgment, separate from a biological benchmark label. The public demo
and applied retained-graph views remain read-only.

For new agent questions or source verification, inspect the existing CLI:

```sh
python3 app.py source-agent-run --help
python3 app.py source-agent-verify --help
```

New agent execution requires a complete source workspace and an explicitly
configured model endpoint. Saved review and verification use CPU and make no
model calls. The model proposes a bounded query, selects source-citation groups
for complete assertion inspection, and chooses review proposals; it does not
automatically add source data or apply acceptance/pruning decisions.

Operator instructions:

https://github.com/mdomagalski/biograph-steward/blob/main/docs/SOURCE_AGENT.md

For a shared saved-review installation, append `--saved-data-only` to the
serve command. This blocks new inference, retrieval and edits while preserving
existing inspection and prepared downloads. Development dashboards and history
controls stay available in operator mode; shared review keeps the current graph
changes and scientific assessment. Loading indicators identify saved-source checks;
a failed saved-question load stays visible and is not reported as ready.
Local source-preserving exports
and the retained graph's decisions/original baseline have different scopes
from a focused answer ZIP; the canonical how-to explains each download.

This package is checked with clean Python, invented CLI/HTTP workflows,
export downloads, source recovery, saved-only guards and answer replay after
an actual owned-server restart. Those are software checks, separate from
biological evaluation, live model results and hosted deployment acceptance.
