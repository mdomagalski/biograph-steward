# BioGraph Steward — review Pharos evidence

For the challenge demonstration, open the protected reviewer app:
https://bi-3a117d5e2b3942678dc518fce65ab5d2.ecs.us-east-2.on.aws/

Use the workspace access token supplied separately by the team. The hosted app opens a selected real Pharos question; reviewers do not need a local installation, model, cloud account, or knowledge of internal workspace/version IDs. This code-only ZIP is the portable software, not the real-data review packet. Hosted availability and its deployed checkpoint are recorded separately from this local package check.

## Five review tasks

1. **Start here:** follow the selected real-data example. Choose **Read the cited answer** when it is ready, or **Open the real-data example**. The alternative **Review applied graph qualifications** opens the separate retained-graph example.
2. **Question & graph:** read the saved question, written answer and bounded evidence diagram. Candidate and accepted describe local review status; an empty accepted view does not mean there is no biological evidence.
3. **Inspect sources:** use **Inspect its source** on the home page or **Inspect this source claim** on a citation. Check the provider record, identifiers, conditions and source trail. Physical association can include co-complex evidence; it does not establish direct binding or disease relevance.
4. **What changed:** distinguish candidate additions from applied graph qualifications and public-reference label recovery. The displayed counts come from the opened workspace or verified assessment. Positive-label recovery is not whole-graph precision, and matched graph-learning comparisons did not establish a consistent prediction advantage.
5. **Export:** download the saved run ZIP or separate answer ZIP. The answer diagram is a selection; the workspace contains the complete saved graph. On the retained example, the saved package preserves the original baseline and every keep, prune or abstain decision. Unknowns remain retained.

Other saved work, source versions, older assessments and research methods remain available in collapsed history sections. The reviewer site blocks new source retrieval, model planning and edits. It supports saved evidence inspection and existing downloads.

## This software package

Code revision: `31123ae956bc7c99fd311d55c064e0d4e58c729f`. Prepared November 15, 2026 (America/New_York).

This MIT software subset runs the supported local workbench with Python 3.10+. No pip installation, model, API key, GPU or cloud account is needed for the invented portability fixture below. Upstream notices are preserved inside `biograph_steward/_vendor/`; the root LICENSE applies to project code. The full repository separately supplies optional research, cloud deployment, tests and evaluation instructions.

## Optional invented local portability fixture

This local example is intentionally invented and visibly labelled. It checks software operation; it is not the real-data challenge demonstration or a biological result. The code archive contains no real graph or assessment data, so a fresh local installation does not silently substitute this fixture for real Pharos evidence.

Unzip this archive into a new directory. In a terminal there, run:

```sh
python3 app.py demo --out runs/synthetic_demo
python3 app.py serve --runs-dir runs --host 127.0.0.1 --port 8765 --no-browser
```

Open `http://127.0.0.1:8765/?run=synthetic_demo` in a browser. Keep the terminal running; Ctrl+C stops this app server. Choose another unused port if 8765 is occupied.

In **Question & graph**, expand **Ask a different supported question**, select DEMO_P1 and shared pathways, then find evidence paths. Inspect its written summary, diagram and citations through **Inspect sources**. All records in this fixture are invented. In **Export**, the local full-mode app can create **Export graph with undecided ledger**. Its `retained_graph.json`, `edge_dispositions.jsonl` and `baseline_packet/source/graph.json` retain the full input and one decision per evidence record; abstentions remain in the graph. This create-export action is intentionally unavailable on the saved-data reviewer site, where existing run and answer ZIPs can be downloaded.

## Reopening a supplied real workspace

A separately authorized graph/source ZIP and its question ZIP can be extracted beside one another into `runs/`, preserving their original top-level names. Start the same server and use the run/question links supplied with that packet. This archive contains no real Pharos graph, source attachments, credentials, benchmark labels, model weights or Git history. The software license does not grant rights to separately retrieved source data.

The current core includes the guided reviewer journey, native GO location inspection, the separate native STRING physical-source profile and question flow, and the v5 scientific-assessment reader. Real source publications, source/QC files and assessment data must be supplied separately through authorized packets and operator configuration; none is included here. Native physical identity mapping requires exact reciprocal aliases and complete reference-sequence equality. It preserves functional evidence, source scores and review states.

For a shared saved-data reviewer server, add `--saved-data-only` to the serve command. This explicit server policy blocks fresh retrieval, live ranking, model planning and edits. Saved questions, source inspection and existing downloads remain available. It preserves source data and does not make the filesystem globally read-only.

This checkpoint was tested with clean Python 3.12.14 and no site packages: invented graph construction, cited answer, actual graph/decision and answer ZIP downloads, verified export, source recovery, and saved-answer replay after restarting an isolated server. These checks establish software portability and source preservation, not independent user feedback or biological correctness. The reviewer interface has separately recorded browser checks; the AWS hosted workbench has its own code/data checkpoint.
